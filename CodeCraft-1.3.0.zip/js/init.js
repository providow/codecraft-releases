/* A small ring of browser-side errors, so the diagnostics report can show what the user actually
   hit rather than only what the server noticed. Capped and truncated: this is a debugging aid, not
   a log, and it must never grow into somewhere page content accumulates. */
window.__ccErrors = [];
function noteClientError(message) {
  window.__ccErrors.unshift({ at: new Date().toISOString(), message: String(message || '').slice(0, 300) });
  if (window.__ccErrors.length > 10) window.__ccErrors.length = 10;
}
window.addEventListener('error', (e) => noteClientError(e.message));
window.addEventListener('unhandledrejection', (e) => noteClientError((e.reason && e.reason.message) || e.reason));

document.addEventListener('DOMContentLoaded', () => {
  App.initShell();
  App.businessProfile.init();
  App.strategy.init();
  App.aiFunnel.init();
  App.pages.init();
  App.account.init();
  App.persistence.loadFromLocalStorage();
  App.persistence.initAutosave();
  App.persistence.initButtons();
});
