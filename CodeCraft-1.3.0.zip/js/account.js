/* Account: the user's own Anthropic API key and which model CodeCraft spends it on.

   CodeCraft is bring-your-own-key, so this tab is where a subscriber's money actually gets
   committed. Two rules follow from that and shape everything below:

   1. The full key is never rendered. The server returns only a masked form (sk-ant-a...NwAA) and
      this module never asks for more. The <input> is for entering a NEW key, never for displaying
      the saved one -- a field pre-filled with a secret is a secret waiting to be shoulder-surfed
      or screen-shared.
   2. Cost is stated before the choice, not after. The model rows carry their real per-million
      prices so switching to Opus is an informed decision rather than a surprise on someone's
      Anthropic invoice. */
(function (App) {
  'use strict';

  const $ = (id) => document.getElementById(id);

  let state = null;   // last /api/settings payload
  let busy = false;

  async function api(path, options) {
    const res = await fetch(path, options);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  function setBusy(v) {
    busy = v;
    ['acct-key-save', 'acct-key-test', 'acct-key-clear', 'acct-usage-reset', 'acct-usage-refresh',
      'acct-lic-activate', 'acct-lic-remove', 'acct-bk-now', 'acct-bk-restore', 'acct-diag-copy'].forEach((id) => {
      const el = $(id);
      if (el) el.disabled = v;
    });
  }

  // The one line that answers "is this thing going to work, and on whose key?"
  function renderKeyStatus() {
    const dot = $('acct-key-dot');
    const text = $('acct-key-status');
    const clearBtn = $('acct-key-clear');
    if (!state || !dot || !text) return;

    let tone = 'bad';
    let message = 'No API key configured. Add one below to start generating.';

    if (state.keySource === 'account') {
      tone = 'good';
      message = 'Using the key saved here (' + state.maskedKey + ').';
    } else if (state.keySource === 'env') {
      tone = 'warn';
      message = 'Using the key from the server environment (' + state.maskedKey
        + '). A key saved here will take over.';
    }

    dot.dataset.tone = tone;
    text.textContent = message;
    if (clearBtn) clearBtn.hidden = state.keySource !== 'account';
  }

  function renderModels() {
    const list = $('acct-model-list');
    if (!list || !state) return;
    list.innerHTML = '';
    state.models.forEach((m) => {
      const row = document.createElement('label');
      row.className = 'acct-model';
      row.setAttribute('for', 'acct-model-' + m.id);

      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'acct-model';
      radio.id = 'acct-model-' + m.id;
      radio.value = m.id;
      radio.checked = m.id === state.model;
      radio.addEventListener('change', () => { if (radio.checked) saveModel(m.id); });

      const body = document.createElement('div');
      body.className = 'acct-model-body';

      const head = document.createElement('div');
      head.className = 'acct-model-head';
      const name = document.createElement('span');
      name.className = 'acct-model-name';
      name.textContent = m.label;
      const price = document.createElement('span');
      price.className = 'acct-model-price';
      price.textContent = '$' + m.inputPerM + ' in / $' + m.outputPerM + ' out per 1M tokens';
      head.appendChild(name);
      head.appendChild(price);

      const note = document.createElement('p');
      note.className = 'acct-model-note';
      note.textContent = m.note;

      body.appendChild(head);
      body.appendChild(note);
      row.appendChild(radio);
      row.appendChild(body);
      list.appendChild(row);
    });
  }

  function setResult(msg, tone) {
    const el = $('acct-key-result');
    if (!el) return;
    el.textContent = msg || '';
    el.hidden = !msg;
    el.dataset.tone = tone || '';
  }

  /* The licence card answers two questions in one line: can I still generate, and for how much
     longer. During the trial the count is the headline, because that is the number a new user is
     actually tracking. Once licensed it drops to a quiet confirmation with the buyer's name --
     which is also the mild deterrent against passing the key around. */
  function renderLicense(l) {
    const dot = $('acct-lic-dot');
    const text = $('acct-lic-status');
    const trial = $('acct-lic-trial');
    const fill = $('acct-lic-trial-fill');
    const entry = $('acct-lic-entry');
    const activate = $('acct-lic-activate');
    const remove = $('acct-lic-remove');

    if (l.licensed) {
      dot.dataset.tone = 'good';
      text.textContent = 'Licensed to ' + (l.name || l.email)
        + (l.email && l.name ? ' (' + l.email + ')' : '')
        + (l.order ? ' \u00b7 ' + l.order : '');
      trial.hidden = true;
      entry.hidden = true;
      activate.hidden = true;
      remove.hidden = false;
      return;
    }

    const left = l.trialRemaining;
    dot.dataset.tone = left > 0 ? 'warn' : 'bad';
    text.textContent = left > 0
      ? 'Free trial \u00b7 ' + left + ' of ' + l.trialLimit + ' funnel' + (left === 1 ? '' : 's') + ' left.'
      : 'Free trial used up. Everything you have already made stays editable and exportable \u2014 only new funnel generation is paused.';
    trial.hidden = false;
    fill.style.width = Math.round((Math.min(l.trialUsed, l.trialLimit) / l.trialLimit) * 100) + '%';
    fill.dataset.spent = left > 0 ? 'no' : 'yes';
    entry.hidden = false;
    activate.hidden = false;
    remove.hidden = true;
  }

  async function refreshLicense() {
    try {
      renderLicense(await api('/api/license'));
    } catch (e) {
      $('acct-lic-status').textContent = 'Could not read license status: ' + e.message;
    }
  }

  function setLicResult(msg, tone) {
    const el = $('acct-lic-result');
    if (!el) return;
    el.textContent = msg || '';
    el.hidden = !msg;
    el.dataset.tone = tone || '';
  }

  async function activateLicense() {
    const key = $('acct-lic-input').value.trim();
    if (!key) { setLicResult('Paste your license key first.', 'bad'); return; }
    try {
      setBusy(true);
      const l = await api('/api/license', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ key })
      });
      $('acct-lic-input').value = '';
      renderLicense(l);
      setLicResult('Thanks \u2014 CodeCraft is unlocked on this machine.', 'good');
      App.utils.showToast('License activated.');
    } catch (e) {
      setLicResult(e.message, 'bad');
    } finally {
      setBusy(false);
    }
  }

  async function removeLicense() {
    try {
      setBusy(true);
      const l = await api('/api/license', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ key: '' })
      });
      renderLicense(l);
      setLicResult('License removed from this machine.', '');
      App.utils.showToast('License removed.');
    } catch (e) {
      setLicResult(e.message, 'bad');
    } finally {
      setBusy(false);
    }
  }

  function renderUsage(u) {
    const fmtCost = App.utils.formatCost;
    const fmtTok = App.utils.formatTokens;
    $('acct-usage-cost').textContent = fmtCost(u.estimatedCost);
    $('acct-usage-calls').textContent = fmtTok(u.calls);
    $('acct-usage-in').textContent = fmtTok(u.inputTokens);
    $('acct-usage-out').textContent = fmtTok(u.outputTokens);
    $('acct-usage-since').textContent = u.since
      ? 'estimated spend since ' + new Date(u.since).toLocaleDateString()
      : 'estimated spend';

    const host = $('acct-usage-models');
    host.innerHTML = '';
    if (!u.byModel || !u.byModel.length) {
      const empty = document.createElement('p');
      empty.className = 'acct-hint';
      empty.textContent = 'No generations yet on this counter.';
      host.appendChild(empty);
      return;
    }
    // Most expensive first -- the line worth looking at is the one costing the most.
    u.byModel.slice().sort((a, b) => (b.cost || 0) - (a.cost || 0)).forEach((m) => {
      const row = document.createElement('div');
      row.className = 'acct-usage-row';
      const name = document.createElement('span');
      name.className = 'acct-usage-model';
      name.textContent = m.model;
      const meta = document.createElement('span');
      meta.className = 'acct-usage-meta';
      meta.textContent = m.calls + (m.calls === 1 ? ' request' : ' requests') + ' \u00b7 '
        + fmtTok(m.inputTokens + m.outputTokens) + ' tokens';
      const cost = document.createElement('span');
      cost.className = 'acct-usage-cost';
      cost.textContent = fmtCost(m.cost);
      row.appendChild(name);
      row.appendChild(meta);
      row.appendChild(cost);
      host.appendChild(row);
    });
  }

  function renderBackups(b) {
    const dot = $('acct-bk-dot');
    const text = $('acct-bk-status');
    const where = $('acct-bk-where');
    if (!dot || !text) return;
    if (!b.count) {
      dot.dataset.tone = 'bad';
      text.textContent = 'No backups yet. Your work exists only in this browser.';
    } else {
      dot.dataset.tone = 'good';
      const when = new Date(b.latest.at);
      text.textContent = b.count + ' backup' + (b.count === 1 ? '' : 's') + ' \u00b7 last saved '
        + when.toLocaleString() + ' (' + App.utils.formatTokens(Math.round(b.latest.bytes / 1024)) + ' KB)';
    }
    const restoreBtn = $('acct-bk-restore');
    if (restoreBtn) restoreBtn.hidden = !b.count;
    if (where) {
      where.textContent = b.count
        ? 'Saved in ' + b.dir + '/ (the newest ' + b.kept + ' are kept). Restore the most recent with the '
          + 'button above, or use Import in the top bar to pick a specific one.'
        : 'Backups are written to ' + b.dir + '/ on this machine.';
    }
  }

  async function refreshBackups() {
    try {
      renderBackups(await api('/api/project/backups'));
    } catch (e) {
      $('acct-bk-status').textContent = 'Could not read backup status: ' + e.message;
    }
  }

  /* Restoring replaces everything currently in the browser, so it asks first and says plainly
     what it is about to overwrite. The current state is backed up first -- an undo for the
     restore itself, since there is no other way back once localStorage is replaced. */
  async function restoreLatest() {
    let list;
    try {
      list = await api('/api/project/backups');
    } catch (e) {
      App.utils.showToast('Could not read backups: ' + e.message);
      return;
    }
    if (!list.latest) { App.utils.showToast('No backups to restore.'); return; }

    const when = new Date(list.latest.at).toLocaleString();
    const ok = window.confirm(
      'Restore the backup from ' + when + '?\n\n'
      + 'This replaces every business, funnel and saved page currently in this browser.\n'
      + 'Your current state is backed up first, so this can be undone.'
    );
    if (!ok) return;

    try {
      setBusy(true);
      await App.persistence.backupToServer();          // safety net before overwriting
      const data = await api('/api/project/backups/' + encodeURIComponent(list.latest.file));
      App.persistence.restoreProject(data);
      App.persistence.saveToLocalStorage();
      await refreshBackups();
      App.utils.showToast('Backup restored from ' + when + '.');
    } catch (e) {
      App.utils.showToast('Could not restore: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function backupNow() {
    try {
      setBusy(true);
      const ok = await App.persistence.backupToServer();
      if (ok === 'empty') {
        App.utils.showToast('Nothing to back up yet -- add a business or generate a funnel first.');
        return;
      }
      if (!ok) throw new Error('the server rejected the backup');
      await refreshBackups();
      App.utils.showToast('Project backed up.');
    } catch (e) {
      App.utils.showToast('Could not back up: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  /* The report is plain text on purpose: it has to survive being pasted into an email client
     without turning into a mangled table, and a human reading it should be able to scan it. */
  function plural(n, one, many) {
    return n + ' ' + (n === 1 ? one : (many || one + 's'));
  }

  function formatDiagnostics(d, local) {
    const lines = [];
    lines.push('CodeCraft diagnostics');
    lines.push('generated ' + new Date().toISOString());
    lines.push('');
    lines.push('App      ' + d.app.version + '  |  Node ' + d.app.node + '  |  ' + d.app.platform);
    lines.push('Model    ' + d.config.model + (d.config.mockAi ? '  (MOCK_AI on)' : ''));
    lines.push('Key      ' + d.config.keySource + (d.config.keyFingerprint ? '  fp:' + d.config.keyFingerprint : '  (none configured)'));
    lines.push('Licence  ' + (d.license.licensed ? 'licensed' : 'trial ' + d.license.trialUsed + '/' + d.license.trialLimit));
    lines.push('Usage    ' + d.usage.calls + ' calls  |  '
      + App.utils.formatTokens(d.usage.inputTokens + d.usage.outputTokens) + ' tokens  |  '
      + App.utils.formatCost(d.usage.estimatedCost) + ' est.');
    lines.push('Content  ' + plural(local.businesses, 'business', 'businesses') + '  |  '
      + plural(local.pages, 'page') + '  |  ' + plural(local.sections, 'section') + ' in the current funnel');
    lines.push('Backups  ' + d.backups);
    lines.push('');
    if (!d.recentErrors.length && !local.clientErrors.length) {
      lines.push('Recent errors: none recorded.');
    } else {
      lines.push('Recent errors (newest first):');
      d.recentErrors.forEach((e) => lines.push('  [server] ' + e.at + '  ' + e.context + '  ' + e.message));
      local.clientErrors.forEach((e) => lines.push('  [browser] ' + e.at + '  ' + e.message));
    }
    return lines.join('\n');
  }

  function localFacts() {
    const biz = (App.businessProfile.getState().businesses || []).length;
    const pages = (App.pages.getState().pages || []).length;
    const sections = ((App.aiFunnel.getState() || {}).lastSections || []).length;
    return { businesses: biz, pages, sections, clientErrors: (window.__ccErrors || []).slice(0, 5) };
  }

  async function copyDiagnostics() {
    try {
      setBusy(true);
      const d = await api('/api/diagnostics');
      const text = formatDiagnostics(d, localFacts());
      const pre = $('acct-diag-preview');
      if (pre) { pre.textContent = text; pre.hidden = false; }
      App.utils.copyText(text, 'Diagnostics');
    } catch (e) {
      App.utils.showToast('Could not gather diagnostics: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function refreshSupport() {
    try {
      const d = await api('/api/diagnostics');
      const mail = $('acct-diag-mail');
      if (mail) {
        mail.href = 'mailto:' + d.supportEmail + '?subject=' + encodeURIComponent('CodeCraft support');
        mail.textContent = 'Email ' + d.supportEmail;
      }
      /* Without this the version existed only inside the diagnostics blob, so a customer reporting
         a bug had no way to say which build they were on. */
      const ver = $('acct-version');
      if (ver) ver.textContent = 'CodeCraft v' + ((d.app && d.app.version) || 'unknown');
      refreshUpdate();
    } catch (e) { /* the copy button still works without this */ }
  }

  /* Asks the maker's site what the newest version is, when the Account tab is opened. Nothing
     about the user's businesses, pages or key is sent -- it is a plain GET for a version number,
     and the answer is signature-checked server-side before it reaches here. Failing quietly is
     deliberate: being offline is not a problem worth interrupting anyone about. */
  async function refreshUpdate() {
    const box = $('acct-update');
    const line = $('acct-update-line');
    const notes = $('acct-update-notes');
    if (!box || !line) return;
    let d;
    try {
      d = await api('/api/update/check');
    } catch (e) {
      box.hidden = true;
      return;
    }
    if (!d.checked) {
      box.hidden = false;
      box.classList.remove('is-available');
      line.textContent = d.reason || 'Could not check for updates.';
      notes.hidden = true;
      return;
    }
    box.hidden = false;
    box.classList.toggle('is-available', !!d.available);
    const btn = $('acct-update-btn');
    if (d.available) {
      line.textContent = 'Version ' + d.latest + ' is available. You have ' + d.current + '.';
      notes.textContent = d.notes || '';
      notes.hidden = !d.notes;
      if (btn) { btn.hidden = false; btn.disabled = false; btn.textContent = 'Update to ' + d.latest; }
    } else {
      line.textContent = 'This is the latest version.';
      notes.hidden = true;
      if (btn) btn.hidden = true;
    }
  }

  /* Downloading and swapping the app takes a moment and must not be started twice, so the button
     is disabled for the whole run. The server verifies the signature and the fingerprint before
     anything is written, and puts the previous version back if the swap fails, so the worst case
     here is an error message rather than a broken install. */
  async function applyUpdate() {
    const btn = $('acct-update-btn');
    const status = $('acct-update-status');
    if (!btn || btn.disabled) return;
    btn.disabled = true;
    btn.textContent = 'Downloading...';
    status.hidden = false;
    status.textContent = 'Downloading and checking the update. This can take a minute. Do not close CodeCraft.';
    try {
      const r = await api('/api/update/apply', { method: 'POST' });
      btn.hidden = true;
      status.textContent = r.message || ('Version ' + r.version + ' is installed. Stop CodeCraft and start it again.');
      $('acct-update-line').textContent = 'Version ' + r.version + ' installed.';
      $('acct-update-notes').hidden = true;
    } catch (e) {
      btn.disabled = false;
      btn.textContent = 'Try again';
      status.textContent = e.message;
    }
  }

  async function refreshUsage() {
    try {
      renderUsage(await api('/api/usage'));
    } catch (e) {
      $('acct-usage-cost').textContent = '--';
    }
  }

  async function resetUsage() {
    try {
      setBusy(true);
      await api('/api/usage/reset', { method: 'POST' });
      await refreshUsage();
      App.utils.showToast('Usage counter reset.');
    } catch (e) {
      App.utils.showToast('Could not reset usage: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  /* First-run guide. Shown only while no API key is configured, because until then nothing can
     generate -- and hidden the moment one exists rather than living on as a permanent manual.
     Deliberately does not block: a new user can still fill in Business Info, which is useful work
     that needs no key at all. */
  let setupHiddenThisSession = false;

  function renderSetup(settings, license) {
    const panel = $('setup-panel');
    if (!panel) return;
    const needsSetup = !settings.hasKey && !settings.mockAi;
    panel.hidden = !needsSetup || setupHiddenThisSession;

    const foot = $('setup-foot');
    if (foot && license) {
      // The trial is about the licence, not the key -- people will otherwise assume "3 free
      // funnels" means Anthropic is free too, and be surprised by their first bill.
      foot.textContent = license.licensed
        ? 'CodeCraft is licensed on this machine. Anthropic usage is still billed to your own key.'
        : 'Your first ' + license.trialLimit + ' funnels are free to try in CodeCraft. Anthropic usage is '
          + 'billed to your key either way — the free trial covers the software, not the generation.';
    }
  }

  async function saveSetupKey() {
    const key = $('setup-key-input').value.trim();
    const out = $('setup-result');
    const show = (msg, tone) => { out.textContent = msg; out.hidden = !msg; out.dataset.tone = tone || ''; };
    if (!key) { show('Paste your API key first.', 'bad'); return; }
    const btn = $('setup-key-save');
    btn.disabled = true;
    show('Checking the key…', '');
    try {
      // Verify before saving, so a typo never becomes the stored key.
      const check = await api('/api/settings/test', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: key })
      });
      if (!check.ok) { show(check.error, 'bad'); return; }
      await api('/api/settings', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: key })
      });
      $('setup-key-input').value = '';
      show('', '');
      await refresh();
      App.utils.showToast('You are set up — head to AI Funnel to generate your first page.');
    } catch (e) {
      show(e.message, 'bad');
    } finally {
      btn.disabled = false;
    }
  }

  async function refresh() {
    try {
      state = await api('/api/settings');
      renderKeyStatus();
      renderModels();
      const mock = $('acct-mock-note');
      if (mock) mock.hidden = !state.mockAi;
    } catch (e) {
      setResult('Could not load account settings: ' + e.message, 'bad');
    }
    refreshUsage();
    refreshLicense();
    refreshBackups();
    refreshSupport();
    if (state) {
      try {
        renderSetup(state, await api('/api/license'));
      } catch (e) {
        renderSetup(state, null);
      }
    }
  }

  async function saveModel(id) {
    try {
      setBusy(true);
      const data = await api('/api/settings', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: id })
      });
      state.model = data.model;
      App.utils.showToast('Model set to ' + data.model + '.');
    } catch (e) {
      App.utils.showToast('Could not change model: ' + e.message);
      refresh();
    } finally {
      setBusy(false);
    }
  }

  // Test works on whatever is typed, falling back to the saved key -- so a key can be checked
  // before it is committed, and a saved key can be re-checked after it stops working.
  async function testKey() {
    const typed = $('acct-key-input').value.trim();
    setResult(typed ? 'Testing the key you entered…' : 'Testing the saved key…', '');
    try {
      setBusy(true);
      const data = await api('/api/settings/test', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(typed ? { apiKey: typed } : {})
      });
      setResult(data.ok ? data.message : data.error, data.ok ? 'good' : 'bad');
    } catch (e) {
      setResult(e.message, 'bad');
    } finally {
      setBusy(false);
    }
  }

  async function saveKey() {
    const typed = $('acct-key-input').value.trim();
    if (!typed) {
      setResult('Enter a key first.', 'bad');
      return;
    }
    try {
      setBusy(true);
      await api('/api/settings', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: typed })
      });
      $('acct-key-input').value = '';
      await refresh();
      setResult('Key saved. Use Test key to confirm it works.', 'good');
      App.utils.showToast('API key saved.');
    } catch (e) {
      setResult(e.message, 'bad');
    } finally {
      setBusy(false);
    }
  }

  async function clearKey() {
    try {
      setBusy(true);
      await api('/api/settings', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: '' })
      });
      $('acct-key-input').value = '';
      await refresh();
      setResult('Saved key removed.', '');
      App.utils.showToast('API key removed.');
    } catch (e) {
      setResult(e.message, 'bad');
    } finally {
      setBusy(false);
    }
  }

  function init() {
    $('acct-key-save').addEventListener('click', saveKey);
    $('acct-key-test').addEventListener('click', testKey);
    $('acct-key-clear').addEventListener('click', clearKey);
    const setupSave = $('setup-key-save');
    if (setupSave) {
      setupSave.addEventListener('click', saveSetupKey);
      $('setup-key-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); saveSetupKey(); }
      });
      $('setup-hide').addEventListener('click', () => {
        setupHiddenThisSession = true;
        $('setup-panel').hidden = true;
        App.utils.showToast('Setup guide hidden. Your key lives in the Account tab.');
      });
    }
    $('acct-bk-now').addEventListener('click', backupNow);
    $('acct-bk-restore').addEventListener('click', restoreLatest);
    $('acct-diag-copy').addEventListener('click', copyDiagnostics);
    $('acct-update-btn').addEventListener('click', applyUpdate);
    $('acct-lic-activate').addEventListener('click', activateLicense);
    $('acct-lic-remove').addEventListener('click', removeLicense);
    $('acct-lic-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); if (!busy) activateLicense(); }
    });
    $('acct-usage-refresh').addEventListener('click', refreshUsage);
    $('acct-usage-reset').addEventListener('click', resetUsage);
    $('acct-key-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); if (!busy) saveKey(); }
    });
    refresh();
  }

  App.account = { init, refresh };
})(window.App);
