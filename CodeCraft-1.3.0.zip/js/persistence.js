/* Save/Load project: generic serializer over every tab's inputs. */
(function (App) {
  'use strict';
  const STORAGE_KEY = 'codecraft-project';
  const { debounce, downloadFile, showToast } = App.utils;

  function serializeProject() {
    const data = {};
    // #tab-account is excluded deliberately, not just for tidiness: this serializer sweeps every
    // input in a panel, and the Account tab holds the Anthropic API key field. Left in, a key
    // typed there would be written into localStorage and into every exported project JSON --
    // files users share. Account settings persist server-side via /api/settings instead.
    document.querySelectorAll('.tab-panel:not(#tab-business):not(#tab-strategy):not(#tab-pages):not(#tab-account) input[id], .tab-panel:not(#tab-business):not(#tab-strategy):not(#tab-pages):not(#tab-account) select[id], .tab-panel:not(#tab-business):not(#tab-strategy):not(#tab-pages):not(#tab-account) textarea[id]').forEach((el) => {
      if (el.type === 'file') {
        if (el.dataset.imageData) data[el.id + '__data'] = el.dataset.imageData;
        return;
      }
      data[el.id] = el.type === 'checkbox' ? el.checked : el.value;
    });
    data.__dynamicLinks = {};
    data.__dynamicSocials = {};
    Object.keys(App.generators).forEach((key) => {
      const gen = App.generators[key];
      if (typeof gen.getLinksState === 'function') data.__dynamicLinks[key] = gen.getLinksState();
      if (typeof gen.getSocialsState === 'function') data.__dynamicSocials[key] = gen.getSocialsState();
    });
    if (App.businessProfile) {
      data.__businesses = App.businessProfile.getState();
    }
    if (App.strategy) {
      data.__strategies = App.strategy.getState();
    }
    if (App.aiFunnel) {
      data.__aiFunnel = App.aiFunnel.getState();
    }
    if (App.pages) {
      data.__pages = App.pages.getState();
    }
    return data;
  }

  function restoreProject(data) {
    if (!data || typeof data !== 'object') return;

    Object.keys(data).forEach((key) => {
      if (key === '__footerLinks' || key === '__dynamicLinks' || key === '__dynamicSocials' || key === '__businesses' || key === '__strategies' || key === '__aiFunnel' || key === '__pages') return;
      // Pre-multi-business saves stored Business Info as flat bi-* keys; skip any leftover
      // ones from an old save so stale values can't leak into the new per-business form.
      if (key.startsWith('bi-')) return;
      // Account fields are never restored from a project file -- a save written before the
      // exclusion above could still carry an acct-key-input value, and importing someone else's
      // project must never populate your API key field.
      if (key.startsWith('acct-')) return;
      if (key.endsWith('__data')) {
        const el = document.getElementById(key.slice(0, -6));
        if (el) el.dataset.imageData = data[key];
        return;
      }
      const el = document.getElementById(key);
      if (!el) return;
      if (el.type === 'checkbox') el.checked = data[key];
      else el.value = data[key];
    });

    // __footerLinks is the pre-Navbar-links storage key kept for backward compatibility.
    if (data.__footerLinks && App.generators.footer && typeof App.generators.footer.setLinksState === 'function') {
      App.generators.footer.setLinksState(data.__footerLinks);
    }
    if (data.__dynamicLinks) {
      Object.keys(data.__dynamicLinks).forEach((key) => {
        const gen = App.generators[key];
        if (gen && typeof gen.setLinksState === 'function') gen.setLinksState(data.__dynamicLinks[key]);
      });
    }
    if (data.__dynamicSocials) {
      Object.keys(data.__dynamicSocials).forEach((key) => {
        const gen = App.generators[key];
        if (gen && typeof gen.setSocialsState === 'function') gen.setSocialsState(data.__dynamicSocials[key]);
      });
    }

    if (data.__businesses && App.businessProfile) {
      App.businessProfile.setState(data.__businesses);
    }
    if (data.__strategies && App.strategy) {
      App.strategy.setState(data.__strategies);
    }
    if (data.__aiFunnel && App.aiFunnel) {
      App.aiFunnel.setState(data.__aiFunnel);
    } else if (App.aiFunnel && typeof App.aiFunnel.syncBusinessSelection === 'function') {
      // Only fall back to the generic sync when there's no saved AI Funnel state to restore --
      // setState() above already resolves the business/strategy selects from the restored data
      // itself, and syncBusinessSelection() would otherwise overwrite that with whatever business
      // happens to be globally active right now.
      App.aiFunnel.syncBusinessSelection();
    }
    if (data.__pages && App.pages) {
      App.pages.setState(data.__pages);
    }
    if (App.strategy && typeof App.strategy.syncBusinessSelection === 'function') {
      App.strategy.syncBusinessSelection();
    }

    Object.values(App.generators).forEach((gen) => {
      if (typeof gen.render === 'function') gen.render();
    });
  }

  function saveToLocalStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(serializeProject()));
  }

  function loadFromLocalStorage() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return false;
      restoreProject(JSON.parse(raw));
      return true;
    } catch (e) {
      return false;
    }
  }

  function exportProject() {
    downloadFile('codecraft-project.json', JSON.stringify(serializeProject(), null, 2), 'application/json');
  }

  // The Import button takes two different things: a project JSON (restores the whole project, as it
  // always has) and an exported page HTML (becomes a new page in the Page Editor, via js/importHtml.js).
  // Sniff on content rather than the filename alone, since a project file saved as .txt or an export
  // renamed by hand should both still land in the right place.
  function looksLikeHtml(file, text) {
    if (/\.html?$/i.test(file.name || '')) return true;
    const head = text.trimStart().slice(0, 200).toLowerCase();
    return head.startsWith('<!doctype html') || head.startsWith('<html') || head.startsWith('<div class="page-content"');
  }

  function importProject(file) {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');

      if (looksLikeHtml(file, text)) {
        try {
          App.importHtml.importFromText(text);
        } catch (e) {
          showToast('Could not import that page: ' + e.message);
        }
        return;
      }

      try {
        restoreProject(JSON.parse(text));
        showToast('Project imported');
      } catch (e) {
        showToast('Could not read that file -- expected a project JSON or an exported page HTML');
      }
    };
    reader.readAsText(file);
  }

  function initAutosave() {
    const debouncedSave = debounce(saveToLocalStorage, 400);
    document.querySelectorAll('.tab-panel').forEach((panel) => {
      panel.addEventListener('input', debouncedSave);
      panel.addEventListener('change', debouncedSave);
      // Also catch button-driven mutations that don't fire input/change, e.g. add/remove
      // rows in a dynamic list (see js/generators/footer.js's link list).
      panel.addEventListener('click', (e) => {
        if (e.target.closest('button')) debouncedSave();
      });
    });
  }

  function initButtons() {
    document.getElementById('exportProject').addEventListener('click', exportProject);
    const importInput = document.getElementById('importProjectInput');
    document.getElementById('importProjectBtn').addEventListener('click', () => importInput.click());
    importInput.addEventListener('change', () => {
      const file = importInput.files[0];
      if (file) importProject(file);
      importInput.value = '';
    });
  }

  /* A copy of the whole project, written server-side. localStorage is the only home this data
     has, and one cleared-site-data wipes every business, funnel and saved page at once. Callers
     get a boolean rather than an exception: a failed backup must never interrupt whatever the
     user was actually doing. */
  // An empty project is not worth a backup slot. Without this, a fresh install (or a browser that
  // has lost its storage) would quietly write empty snapshots -- and since only the newest 20 are
  // kept, twenty of those would evict the one backup that actually held the user's work.
  function projectHasContent(data) {
    // Both businesses and strategies start life as a blank placeholder record, so their mere
    // presence means nothing -- a fresh install has one of each. Only count them once they carry
    // something a user actually typed or generated.
    const businesses = ((data.__businesses || {}).businesses) || [];
    const namedBusiness = businesses.some((b) => b && String(b.name || '').trim());

    const strategies = ((data.__strategies || {}).strategies) || [];
    const realStrategy = strategies.some((s) => s && (
      String(s.title || '').trim() ||
      String(s.idea || '').trim() ||
      String(s.productName || '').trim() ||
      (Array.isArray(s.candidates) && s.candidates.length > 0)
    ));

    const funnelSections = ((data.__aiFunnel || {}).lastSections) || [];
    const pages = ((data.__pages || {}).pages) || [];

    return namedBusiness || realStrategy || funnelSections.length > 0 || pages.length > 0;
  }

  async function backupToServer() {
    const data = serializeProject();
    if (!projectHasContent(data)) return 'empty';
    try {
      const res = await fetch('/api/project/backup', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(data)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  }

  App.persistence = {
    serializeProject,
    backupToServer,
    restoreProject,
    saveToLocalStorage,
    loadFromLocalStorage,
    exportProject,
    importProject,
    initAutosave,
    initButtons
  };
})(window.App);
