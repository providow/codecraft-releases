/* Business Info tab: a small database of saved businesses (each with a full profile + its own
   product catalog), mirroring js/generators/funnel.js's {id, state}/cloneState list pattern. */
(function (App) {
  'use strict';
  const $ = (id) => document.getElementById(id);

  const FIELD_MAP = [
    { id: 'bi-name', key: 'name' },
    { id: 'bi-industry', key: 'industry' },
    { id: 'bi-industry-other', key: 'industryOther' },
    { id: 'bi-business-type', key: 'businessType' },
    { id: 'bi-tagline', key: 'tagline' },
    { id: 'bi-logo-text', key: 'logoText' },
    { id: 'bi-sub-niche', key: 'subNiche' },
    { id: 'bi-email', key: 'email' },
    { id: 'bi-address', key: 'address' },
    { id: 'bi-hours', key: 'hours' },
    { id: 'bi-site-url', key: 'siteUrl' },
    { id: 'bi-description', key: 'description' },
    { id: 'bi-audience', key: 'audience' },
    { id: 'bi-usps', key: 'usps' },
    { id: 'bi-guarantee', key: 'guarantee' },
    { id: 'bi-credibility', key: 'credibility' },
    { id: 'bi-tone', key: 'tone' },
    { id: 'bi-visual-world', key: 'visualWorld' },
    { id: 'bi-font', key: 'font' },
    { id: 'bi-notes', key: 'notes' },
    { id: 'bi-brand-primary', key: 'brandPrimary' },
    { id: 'bi-brand-secondary', key: 'brandSecondary' }
  ];

  // Color inputs always hold a valid hex value (never truly "empty"), so they're excluded
  // from isBlank()'s "has the user typed anything" check -- otherwise a freshly-created
  // business would never count as blank and the auto-discard-if-untouched rule would break.
  const BLANK_CHECK_EXCLUDE = ['brandPrimary', 'brandSecondary'];
  /* A color input has no empty state -- it always holds a value -- so "no brand colours" used to
     be indistinguishable from "deliberately chose purple and pink". Worse, the pair it defaulted
     to (#6a5cff / #ff6ac1) is named and banned in the generation doctrine as an AI cliche, so every
     generation was handed brand colours it was simultaneously told to build around and forbidden
     to use. The checkbox is what makes "not set" expressible; these greys are only what the picker
     SHOWS before a real choice is made, deliberately hueless so the UI suggests nothing. */
  const COLOR_FALLBACKS = { brandPrimary: '#8a8a8a', brandSecondary: '#b4b4b4' };
  // The old defaults. A record still carrying exactly this pair was never actually chosen by
  // anyone, so it is read as "not set" rather than migrated -- stored data is left alone.
  const LEGACY_DEFAULTS = { brandPrimary: '#6a5cff', brandSecondary: '#ff6ac1' };

  function brandColorsAreSet(b) {
    if (!b) return false;
    const p = (b.brandPrimary || '').toLowerCase();
    const s = (b.brandSecondary || '').toLowerCase();
    if (!p && !s) return false;
    if (p === LEGACY_DEFAULTS.brandPrimary && s === LEGACY_DEFAULTS.brandSecondary) return false;
    return true;
  }

  function syncBrandColorInputs() {
    const on = $('bi-brand-enabled').checked;
    $('bi-brand-primary').disabled = !on;
    $('bi-brand-secondary').disabled = !on;
    const row = $('bi-brand-row');
    if (row) row.classList.toggle('is-off', !on);
  }

  let businesses = [];
  let activeId = null;
  let nextId = 1;

  function cloneState(s) {
    return JSON.parse(JSON.stringify(s));
  }

  /* ---------- Product catalog (per-business dynamic list) ---------- */
  const CURRENCIES = [
    { value: '', label: 'Currency…', placeholder: true },
    { value: 'USD', label: 'USD ($)' },
    { value: 'PHP', label: 'PHP (₱)' },
    { value: 'EUR', label: 'EUR (€)' },
    { value: 'GBP', label: 'GBP (£)' },
    { value: 'CAD', label: 'CAD (C$)' },
    { value: 'AUD', label: 'AUD (A$)' },
    { value: 'SGD', label: 'SGD (S$)' },
    { value: 'INR', label: 'INR (₹)' },
    { value: 'JPY', label: 'JPY (¥)' },
    { value: 'MXN', label: 'MXN ($)' },
    { value: 'Other', label: 'Other' }
  ];

  function getProducts() {
    return Array.from(document.querySelectorAll('#bi-products-list .dynamic-list-row'))
      .map((row) => ({
        name: row.querySelector('.bi-product-name').value.trim(),
        currency: row.querySelector('.bi-product-currency').value,
        price: row.querySelector('.bi-product-price').value.trim(),
        billing: row.querySelector('.bi-product-billing').value,
        description: row.querySelector('.bi-product-desc').value.trim()
      }))
      .filter((p) => p.name);
  }

  function addProductRow(item, focus) {
    const data = item || {};
    const container = $('bi-products-list');
    const row = document.createElement('div');
    row.className = 'dynamic-list-row';

    const inputs = document.createElement('div');
    inputs.className = 'dynamic-list-inputs';

    const name = document.createElement('input');
    name.type = 'text';
    name.className = 'bi-product-name';
    name.placeholder = 'Product / service name';
    name.value = data.name || '';

    const priceRow = document.createElement('div');
    priceRow.className = 'bi-product-price-row';

    const currency = document.createElement('select');
    currency.className = 'bi-product-currency';
    CURRENCIES.forEach((opt) => {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = opt.label;
      if (opt.placeholder) {
        o.disabled = true;
        o.hidden = true;
      }
      currency.appendChild(o);
    });
    currency.value = data.currency || '';

    const price = document.createElement('input');
    price.type = 'text';
    price.className = 'bi-product-price';
    price.placeholder = 'Price (optional, e.g. 45)';
    price.value = data.price || '';

    const billing = document.createElement('select');
    billing.className = 'bi-product-billing';
    [
      { value: '', label: 'Billing…', placeholder: true },
      { value: 'one-time', label: 'One-time' },
      { value: 'monthly', label: 'Monthly' },
      { value: 'annually', label: 'Annually' }
    ].forEach((opt) => {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = opt.label;
      if (opt.placeholder) {
        o.disabled = true;
        o.hidden = true;
      }
      billing.appendChild(o);
    });
    billing.value = data.billing || '';

    priceRow.append(currency, price, billing);

    const desc = document.createElement('textarea');
    desc.className = 'bi-product-desc';
    desc.rows = 2;
    desc.placeholder = 'Short description';
    desc.value = data.description || '';

    inputs.append(name, priceRow, desc);

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'dynamic-list-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove product';
    removeBtn.addEventListener('click', () => row.remove());

    row.appendChild(inputs);
    row.appendChild(removeBtn);
    container.appendChild(row);
    if (focus) name.focus();
  }

  function setProducts(items) {
    $('bi-products-list').innerHTML = '';
    (items || []).forEach((item) => addProductRow(item));
  }

  /* ---------- Phone numbers (per-business dynamic list) ---------- */
  function getPhones() {
    return Array.from(document.querySelectorAll('#bi-phones-list .dynamic-list-row'))
      .map((row) => ({
        label: row.querySelector('.bi-phone-label').value.trim(),
        number: row.querySelector('.bi-phone-number').value.trim()
      }))
      .filter((p) => p.number);
  }

  function addPhoneRow(item, focus) {
    const data = item || {};
    const container = $('bi-phones-list');
    const row = document.createElement('div');
    row.className = 'dynamic-list-row';

    const inputs = document.createElement('div');
    inputs.className = 'dynamic-list-inputs';

    const label = document.createElement('input');
    label.type = 'text';
    label.className = 'bi-phone-label';
    label.placeholder = 'Label (optional, e.g. Main, Emergency)';
    label.value = data.label || '';

    const number = document.createElement('input');
    number.type = 'text';
    number.className = 'bi-phone-number';
    number.placeholder = '(555) 123-4567';
    number.value = data.number || '';

    inputs.append(label, number);

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'dynamic-list-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove phone number';
    removeBtn.addEventListener('click', () => row.remove());

    row.appendChild(inputs);
    row.appendChild(removeBtn);
    container.appendChild(row);
    if (focus) number.focus();
  }

  function setPhones(items) {
    $('bi-phones-list').innerHTML = '';
    (items || []).forEach((item) => addPhoneRow(item));
  }

  /* ---------- Awards / certifications (per-business dynamic list) ---------- */
  function getAwards() {
    return Array.from(document.querySelectorAll('#bi-awards-list .dynamic-list-row'))
      .map((row) => ({
        name: row.querySelector('.bi-award-name').value.trim(),
        imageUrl: row.querySelector('.bi-award-image').value.trim()
      }))
      .filter((a) => a.name || a.imageUrl);
  }

  function addAwardRow(item, focus) {
    const data = item || {};
    const container = $('bi-awards-list');
    const row = document.createElement('div');
    row.className = 'dynamic-list-row';

    const inputs = document.createElement('div');
    inputs.className = 'dynamic-list-inputs';

    const name = document.createElement('input');
    name.type = 'text';
    name.className = 'bi-award-name';
    name.placeholder = 'Award / certification name';
    name.value = data.name || '';

    const imageUrl = document.createElement('input');
    imageUrl.type = 'text';
    imageUrl.className = 'bi-award-image';
    imageUrl.placeholder = 'Badge/logo image URL (optional)';
    imageUrl.value = data.imageUrl || '';

    inputs.append(name, imageUrl);

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'dynamic-list-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove award';
    removeBtn.addEventListener('click', () => row.remove());

    row.appendChild(inputs);
    row.appendChild(removeBtn);
    container.appendChild(row);
    if (focus) name.focus();
  }

  function setAwards(items) {
    $('bi-awards-list').innerHTML = '';
    (items || []).forEach((item) => addAwardRow(item));
  }

  /* ---------- Reviews / testimonials (per-business dynamic list) ---------- */
  function getReviews() {
    return Array.from(document.querySelectorAll('#bi-reviews-list .dynamic-list-row'))
      .map((row) => ({
        name: row.querySelector('.bi-review-name').value.trim(),
        role: row.querySelector('.bi-review-role').value.trim(),
        quote: row.querySelector('.bi-review-quote').value.trim(),
        photoUrl: row.querySelector('.bi-review-photo').value.trim(),
        videoUrl: row.querySelector('.bi-review-video').value.trim()
      }))
      .filter((r) => r.name || r.quote);
  }

  function addReviewRow(item, focus) {
    const data = item || {};
    const container = $('bi-reviews-list');
    const row = document.createElement('div');
    row.className = 'dynamic-list-row';

    const inputs = document.createElement('div');
    inputs.className = 'dynamic-list-inputs';

    const nameRoleRow = document.createElement('div');
    nameRoleRow.className = 'bi-product-price-row';

    const name = document.createElement('input');
    name.type = 'text';
    name.className = 'bi-review-name';
    name.placeholder = 'Customer name, e.g. Wilson S.';
    name.value = data.name || '';

    const role = document.createElement('input');
    role.type = 'text';
    role.className = 'bi-review-role';
    role.placeholder = 'Role / context, e.g. Business Owner';
    role.value = data.role || '';

    nameRoleRow.append(name, role);

    const quote = document.createElement('textarea');
    quote.className = 'bi-review-quote';
    quote.rows = 2;
    quote.placeholder = 'What they actually said';
    quote.value = data.quote || '';

    const photoUrl = document.createElement('input');
    photoUrl.type = 'text';
    photoUrl.className = 'bi-review-photo';
    photoUrl.placeholder = 'Photo URL of the customer (optional)';
    photoUrl.value = data.photoUrl || '';

    const videoUrl = document.createElement('input');
    videoUrl.type = 'text';
    videoUrl.className = 'bi-review-video';
    videoUrl.placeholder = 'Video testimonial URL (optional -- YouTube, Vimeo, or direct file)';
    videoUrl.value = data.videoUrl || '';

    inputs.append(nameRoleRow, quote, photoUrl, videoUrl);

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'dynamic-list-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove review';
    removeBtn.addEventListener('click', () => row.remove());

    row.appendChild(inputs);
    row.appendChild(removeBtn);
    container.appendChild(row);
    if (focus) name.focus();
  }

  function setReviews(items) {
    $('bi-reviews-list').innerHTML = '';
    (items || []).forEach((item) => addReviewRow(item));
  }

  /* ---------- Social media links (per-business dynamic list) ---------- */
  const SOCIAL_PLATFORMS = ['Instagram', 'Facebook', 'TikTok', 'X (Twitter)', 'LinkedIn', 'YouTube', 'Pinterest', 'Other'];

  function getSocialLinks() {
    return Array.from(document.querySelectorAll('#bi-social-list .dynamic-list-row'))
      .map((row) => ({
        platform: row.querySelector('.bi-social-platform').value,
        url: row.querySelector('.bi-social-url').value.trim()
      }))
      .filter((s) => s.url);
  }

  function addSocialLinkRow(item, focus) {
    const data = item || {};
    const container = $('bi-social-list');
    const row = document.createElement('div');
    row.className = 'dynamic-list-row';

    const inputs = document.createElement('div');
    inputs.className = 'dynamic-list-inputs';

    const platform = document.createElement('select');
    platform.className = 'bi-social-platform';
    SOCIAL_PLATFORMS.forEach((p) => {
      const o = document.createElement('option');
      o.value = p;
      o.textContent = p;
      platform.appendChild(o);
    });
    platform.value = data.platform || 'Instagram';

    const url = document.createElement('input');
    url.type = 'text';
    url.className = 'bi-social-url';
    url.placeholder = 'instagram.com/yourbusiness';
    url.value = data.url || '';

    inputs.append(platform, url);

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'dynamic-list-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove social link';
    removeBtn.addEventListener('click', () => row.remove());

    row.appendChild(inputs);
    row.appendChild(removeBtn);
    container.appendChild(row);
    if (focus) url.focus();
  }

  function setSocialLinks(items) {
    $('bi-social-list').innerHTML = '';
    (items || []).forEach((item) => addSocialLinkRow(item));
  }

  /* ---------- Business records ---------- */
  function emptyBusiness() {
    const b = { id: 'biz-' + (nextId++), products: [], phones: [], socialLinks: [], awards: [], reviews: [] };
    FIELD_MAP.forEach((f) => { b[f.key] = ''; });
    // Genuinely unset, so the generator picks a palette to fit the business instead of being
    // handed a colour nobody chose.
    b.brandPrimary = '';
    b.brandSecondary = '';
    return b;
  }

  function getById(id) {
    return businesses.find((b) => b.id === id) || null;
  }

  function readFormIntoActive() {
    const record = getById(activeId);
    if (!record) return;
    FIELD_MAP.forEach((f) => { record[f.key] = $(f.id).value; });
    /* Unticked means the business genuinely has no brand colours, so they are cleared on the
       record rather than merely hidden -- the whole profile object is serialised into the
       generation prompt, so a value left behind here would still reach the model. */
    if (!$('bi-brand-enabled').checked) {
      record.brandPrimary = '';
      record.brandSecondary = '';
    }
    record.products = getProducts();
    record.phones = getPhones();
    record.socialLinks = getSocialLinks();
    record.awards = getAwards();
    record.reviews = getReviews();
  }

  function loadIntoForm(record) {
    const b = record || emptyBusiness();
    FIELD_MAP.forEach((f) => { $(f.id).value = b[f.key] || COLOR_FALLBACKS[f.key] || ''; });
    const brandOn = brandColorsAreSet(b);
    $('bi-brand-enabled').checked = brandOn;
    if (!brandOn) {
      $('bi-brand-primary').value = COLOR_FALLBACKS.brandPrimary;
      $('bi-brand-secondary').value = COLOR_FALLBACKS.brandSecondary;
    }
    syncBrandColorInputs();
    // Pre-dropdown records stored free text directly in `industry` -- if that text doesn't match
    // any real dropdown option, the assignment above silently left the select on no option
    // selected (value === ''). Treat that as legacy data: show "Other" and preserve the original
    // text instead of discarding it.
    const industrySelect = $('bi-industry');
    if (b.industry && industrySelect.value === '') {
      industrySelect.value = 'Other';
      if (!b.industryOther) $('bi-industry-other').value = b.industry;
    }
    updateIndustryOtherVisibility();
    setProducts(b.products);
    setPhones(b.phones);
    setSocialLinks(b.socialLinks);
    setAwards(b.awards);
    setReviews(b.reviews);
  }

  function updateIndustryOtherVisibility() {
    const wrap = $('bi-industry-other-wrap');
    if (!wrap) return;
    wrap.hidden = $('bi-industry').value !== 'Other';
  }

  function industryDisplay(record) {
    if (!record) return '';
    if (record.industry === 'Other') return record.industryOther || 'Other';
    return record.industry || '';
  }

  function isBlank(record) {
    if (!record) return true;
    if (record.products && record.products.length) return false;
    if (record.phones && record.phones.length) return false;
    if (record.socialLinks && record.socialLinks.length) return false;
    if (record.awards && record.awards.length) return false;
    if (record.reviews && record.reviews.length) return false;
    return FIELD_MAP
      .filter((f) => !BLANK_CHECK_EXCLUDE.includes(f.key))
      .every((f) => !record[f.key] || !record[f.key].trim());
  }

  function showSaved() {
    const el = $('bi-save-status');
    if (!el) return;
    const time = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    el.textContent = `✓ Saved at ${time}`;
    el.classList.add('is-saved');
  }

  let flashTimer = null;
  function flashSaveButton() {
    const btn = $('bi-save-business');
    if (!btn) return;
    clearTimeout(flashTimer);
    btn.textContent = '✓ Saved';
    btn.classList.add('btn-save-flash');
    flashTimer = setTimeout(() => {
      btn.textContent = '💾 Save';
      btn.classList.remove('btn-save-flash');
    }, 1400);
  }

  function saveNow() {
    readFormIntoActive();
    showSaved();
    renderList();
    if (App.persistence && typeof App.persistence.saveToLocalStorage === 'function') {
      App.persistence.saveToLocalStorage();
    }
    flashSaveButton();
  }

  function summaryFor(record) {
    return record.name.trim() || 'Untitled Business';
  }

  function renderList() {
    const container = $('bi-business-list');
    if (!container) return;
    container.innerHTML = '';
    businesses.forEach((record) => {
      const row = document.createElement('div');
      row.className = 'funnel-row' + (record.id === activeId ? ' is-active' : '');

      const main = document.createElement('div');
      main.className = 'funnel-row-main';
      const nameEl = document.createElement('div');
      nameEl.className = 'funnel-row-type';
      nameEl.textContent = summaryFor(record);
      const summaryEl = document.createElement('div');
      summaryEl.className = 'funnel-row-summary';
      const parts = [];
      const industryText = industryDisplay(record);
      if (industryText) parts.push(industryText);
      if (record.products && record.products.length) parts.push(record.products.length + ' product' + (record.products.length === 1 ? '' : 's'));
      summaryEl.textContent = parts.join(' · ');
      main.appendChild(nameEl);
      main.appendChild(summaryEl);
      row.appendChild(main);

      const actions = document.createElement('div');
      actions.className = 'funnel-row-actions';

      const selectBtn = document.createElement('button');
      selectBtn.type = 'button';
      selectBtn.className = 'btn funnel-row-btn';
      selectBtn.textContent = 'Select';
      selectBtn.disabled = record.id === activeId;
      selectBtn.addEventListener('click', () => selectBusiness(record.id));

      const dupBtn = document.createElement('button');
      dupBtn.type = 'button';
      dupBtn.className = 'btn funnel-row-btn';
      dupBtn.textContent = 'Duplicate';
      dupBtn.addEventListener('click', () => duplicateBusiness(record.id));

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'btn funnel-row-btn';
      removeBtn.textContent = '✕';
      removeBtn.title = 'Delete business';
      removeBtn.addEventListener('click', () => deleteBusiness(record.id));

      actions.append(selectBtn, dupBtn, removeBtn);
      row.appendChild(actions);
      container.appendChild(row);
    });
  }

  function selectBusiness(id) {
    if (id === activeId) return;
    readFormIntoActive();
    const leaving = getById(activeId);
    if (leaving && isBlank(leaving)) {
      businesses = businesses.filter((b) => b.id !== leaving.id);
    }
    activeId = id;
    loadIntoForm(getById(activeId));
    renderList();
  }

  function newBusiness() {
    readFormIntoActive();
    const leaving = getById(activeId);
    if (leaving && isBlank(leaving)) {
      businesses = businesses.filter((b) => b.id !== leaving.id);
    }
    const b = emptyBusiness();
    businesses.push(b);
    activeId = b.id;
    loadIntoForm(b);
    renderList();
  }

  function duplicateBusiness(id) {
    if (id === activeId) readFormIntoActive();
    const idx = businesses.findIndex((b) => b.id === id);
    if (idx === -1) return;
    const clone = cloneState(businesses[idx]);
    clone.id = 'biz-' + (nextId++);
    clone.name = (clone.name || 'Untitled Business') + ' (Copy)';
    businesses.splice(idx + 1, 0, clone);
    renderList();
  }

  function deleteBusiness(id) {
    const idx = businesses.findIndex((b) => b.id === id);
    if (idx === -1) return;
    businesses.splice(idx, 1);
    if (id === activeId) {
      const next = businesses[idx - 1] || businesses[idx] || null;
      if (next) {
        activeId = next.id;
        loadIntoForm(next);
      } else {
        activeId = null;
        newBusiness();
        return;
      }
    }
    renderList();
  }

  /* ---------- Persistence ---------- */
  function getState() {
    readFormIntoActive();
    return { businesses: cloneState(businesses), activeId };
  }

  function setState(data) {
    if (!data || !Array.isArray(data.businesses) || !data.businesses.length) return;
    businesses = cloneState(data.businesses);
    nextId = businesses.reduce((max, b) => {
      const num = parseInt(String(b.id).replace('biz-', ''), 10);
      return isNaN(num) ? max : Math.max(max, num + 1);
    }, 1);
    activeId = data.activeId && getById(data.activeId) ? data.activeId : businesses[0].id;
    loadIntoForm(getById(activeId));
    renderList();
  }

  function list() {
    return businesses.map((b) => ({ id: b.id, name: b.name.trim() || 'Untitled Business' }));
  }

  function init() {
    if (businesses.length === 0) newBusiness();

    $('bi-products-add').addEventListener('click', () => addProductRow({}, true));
    $('bi-phones-add').addEventListener('click', () => addPhoneRow({}, true));
    $('bi-social-add').addEventListener('click', () => addSocialLinkRow({}, true));
    $('bi-awards-add').addEventListener('click', () => addAwardRow({}, true));
    $('bi-reviews-add').addEventListener('click', () => addReviewRow({}, true));
    $('bi-new-business').addEventListener('click', newBusiness);
    $('bi-save-business').addEventListener('click', saveNow);
    $('bi-industry').addEventListener('change', updateIndustryOtherVisibility);
    // The panel-wide change handler is debounced, so the enable/dim has its own immediate one.
    $('bi-brand-enabled').addEventListener('change', syncBrandColorInputs);

    const panel = document.getElementById('tab-business');
    const debouncedUpdate = App.utils.debounce(() => {
      readFormIntoActive();
      showSaved();
      renderList();
    }, 400);
    panel.addEventListener('input', debouncedUpdate);
    panel.addEventListener('change', debouncedUpdate);
    panel.addEventListener('click', (e) => {
      if (e.target.closest('button') && !e.target.closest('.funnel-row')) debouncedUpdate();
    });
  }

  App.businessProfile = {
    init,
    getState,
    setState,
    list,
    getById,
    selectBusiness,
    newBusiness,
    duplicateBusiness,
    deleteBusiness,
    getProducts,
    setProducts,
    industryDisplay
  };
})(window.App);
