/* AI Funnel: a single autonomous pass that invents section structure, a bespoke visual identity, and
   copy all at once -- no fixed Structure/Brand library involved. Self-contained: it never touches
   Build Funnel's own funnel state, it renders its own preview right here in this tab. */
(function (App) {
  'use strict';
  const $ = (id) => document.getElementById(id);

  let busy = false;
  let lastSections = [];
  let lastFonts = [];
  /* Which business the sections in lastSections were actually generated for.

     download() builds the <head> from whatever business is selected RIGHT NOW while the body
     comes from the last generation, so switching the dropdown without regenerating -- or a
     failed run that leaves an older result on screen -- produced a file carrying one client's
     name over another client's page. Keeping the owning id lets every action that exports or
     saves the result refuse when the two have drifted apart. */
  let resultBusinessId = null;
  const UNKNOWN_OWNER = '\u0000unknown';
  /* The differentiator box is one input shared by every business, so its text used to survive a
     change of client and be sent, unedited, into the next generation -- one client's brief
     quietly shaping another client's page, with nothing on screen to show it had happened.
     Keeping a brief per business id means switching clients swaps the text instead of
     inheriting it. */
  const briefs = Object.create(null);
  let briefOwnerId = null;

  /* ---------- Generation progress ----------
     Neither AI pass streams: /api/chat returns nothing at all until a whole pass has finished, so
     there is no real percentage to read while one is running. What IS real is the stage boundary --
     the generate call resolving and the revise call starting. So the bar moves for real at those
     moments, and in between eases asymptotically toward the current stage's ceiling without ever
     arriving. The user sees continuous motion (it has not frozen) without the bar ever claiming
     progress the client cannot actually know. The elapsed clock is the honest number here. */
  const PROGRESS_CEILING = 94;    // hold back the last stretch until the work genuinely completes
  const PROGRESS_TAU_MS = 70000;  // easing decay, tuned so a 2-5 minute pass still visibly creeps

  let progressTimer = null;
  let progressSteps = [];
  let progressIndex = 0;
  let progressStartedAt = 0;
  let progressStageAt = 0;
  let progressFrom = 0;

  function progressCeilingFor(i) {
    return PROGRESS_CEILING * ((i + 1) / Math.max(1, progressSteps.length));
  }

  function formatElapsed(ms) {
    const secs = Math.max(0, Math.floor(ms / 1000));
    return `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`;
  }

  function progressTick() {
    const now = Date.now();
    const elapsedEl = $('af-progress-elapsed');
    if (elapsedEl) elapsedEl.textContent = formatElapsed(now - progressStartedAt);
    const fill = $('af-progress-fill');
    if (!fill) return;
    const ceiling = progressCeilingFor(progressIndex);
    const pct = progressFrom + (ceiling - progressFrom) * (1 - Math.exp(-(now - progressStageAt) / PROGRESS_TAU_MS));
    fill.style.width = pct.toFixed(2) + '%';
    const track = $('af-progress-track');
    if (track) track.setAttribute('aria-valuenow', String(Math.round(pct)));
  }

  function renderProgressSteps() {
    const list = $('af-progress-steps');
    if (!list) return;
    list.innerHTML = '';
    progressSteps.forEach((label, i) => {
      const li = document.createElement('li');
      li.dataset.state = i < progressIndex ? 'done' : (i === progressIndex ? 'active' : 'todo');
      const dot = document.createElement('span');
      dot.className = 'af-step-dot';
      const text = document.createElement('span');
      text.textContent = label;
      li.appendChild(dot);
      li.appendChild(text);
      list.appendChild(li);
    });
    const stage = $('af-progress-stage');
    if (stage) stage.textContent = progressSteps[progressIndex] || 'Finishing up';
  }

  function progressBegin(steps, note) {
    progressSteps = steps;
    progressIndex = 0;
    progressFrom = 0;
    progressStartedAt = Date.now();
    progressStageAt = progressStartedAt;
    const fill = $('af-progress-fill');
    if (fill) fill.style.width = '0%';
    const noteEl = $('af-progress-note');
    if (noteEl) noteEl.textContent = note;
    const box = $('af-progress');
    if (box) box.hidden = false;
    // Hide the "choose a business" placeholder while running; an existing preview underneath is
    // left alone so a regeneration never blanks out the funnel the user already has.
    const placeholder = $('af-preview-placeholder');
    if (placeholder) placeholder.hidden = true;
    renderProgressSteps();
    progressTick();
    if (progressTimer) clearInterval(progressTimer);
    progressTimer = setInterval(progressTick, 250);
  }

  function progressAdvance() {
    // A real boundary: bank the finished stage's ceiling, then start easing through the next one.
    progressFrom = progressCeilingFor(progressIndex);
    progressIndex = Math.min(progressIndex + 1, progressSteps.length - 1);
    progressStageAt = Date.now();
    renderProgressSteps();
    progressTick();
  }

  function progressEnd(ok) {
    if (progressTimer) { clearInterval(progressTimer); progressTimer = null; }
    const fill = $('af-progress-fill');
    if (ok && fill) fill.style.width = '100%';
    const track = $('af-progress-track');
    if (ok && track) track.setAttribute('aria-valuenow', '100');
    progressIndex = progressSteps.length;
    renderProgressSteps();
    // Let a completed bar land visibly instead of blinking out the instant the request returns.
    setTimeout(() => {
      const box = $('af-progress');
      if (box) box.hidden = true;
      if (!lastSections.length) {
        const placeholder = $('af-preview-placeholder');
        if (placeholder) placeholder.hidden = false;
      }
    }, ok ? 900 : 0);
  }

  /* The Account tab shows lifetime spend; this shows what the run you just waited for actually
     cost. Measured as a delta around the generation rather than threaded through the response,
     so every mode is counted the same way and no response shape has to change. A failed usage
     read just means no cost is mentioned -- it must never take down a successful generation. */
  async function usageSnapshot() {
    try {
      const res = await fetch('/api/usage');
      if (!res.ok) return null;
      const data = await res.json();
      return typeof data.estimatedCost === 'number' ? data : null;
    } catch (e) {
      return null;
    }
  }

  async function costSuffixSince(before) {
    if (!before) return '';
    const after = await usageSnapshot();
    if (!after) return '';
    const spent = after.estimatedCost - before.estimatedCost;
    const tokens = (after.inputTokens + after.outputTokens) - (before.inputTokens + before.outputTokens);
    if (!(spent > 0)) return '';
    return ' This run cost about ' + App.utils.formatCost(spent)
      + ' (' + App.utils.formatTokens(tokens) + ' tokens).';
  }

  async function postChat(mode, extra) {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(Object.assign({ mode, messages: [] }, extra))
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  function strategyPayloadFor(strat) {
    return strat
      ? { title: strat.title, audience: strat.audience, offer: strat.offer, objections: strat.objections,
          traffic: strat.traffic, messaging: strat.messaging, funnelType: strat.funnelType }
      : null;
  }

  function stashCurrentBrief() {
    if (briefOwnerId) briefs[briefOwnerId] = $('af-differentiator-input').value;
  }

  function loadBriefFor(businessId) {
    briefOwnerId = businessId || null;
    $('af-differentiator-input').value = (businessId && briefs[businessId]) || '';
  }

  /* ---------- The interview ----------
     Keyed by business for exactly the reason the briefs map above is: a single shared transcript
     would carry one client's answers into the next client's page. That is the same bug class as
     the shared differentiator box, only with far more text in it. Switching business swaps the
     whole conversation rather than inheriting it. */
  const interviews = Object.create(null);

  function interviewFor(businessId) {
    if (!businessId) return null;
    if (!interviews[businessId]) {
      interviews[businessId] = { pairs: [], pending: '', done: false, started: false, busy: false, strategyId: '' };
    }
    return interviews[businessId];
  }

  function appendInterviewBubble(role, text, extraClass) {
    const el = document.createElement('div');
    el.className = 'pages-chat-bubble pages-chat-bubble-' + (role === 'user' ? 'user' : 'ai')
      + (extraClass ? ' ' + extraClass : '');
    el.textContent = text;
    $('af-iv-log').appendChild(el);
    return el;
  }

  /* Redraws the log from the record rather than appending as it goes, so a business switch cannot
     leave another client's bubbles on screen. */
  function renderInterview() {
    // Read, never create -- interviewFor() adds a record, and a record's mere existence is what
    // tells the auto-start it has already run.
    const iv = interviews[$('af-business-select').value] || null;
    const log = $('af-iv-log');
    if (!log) return;
    log.innerHTML = '';
    if (iv) {
      iv.pairs.forEach((p) => {
        appendInterviewBubble('ai', p.question);
        appendInterviewBubble('user', p.answer);
      });
      if (iv.pending) appendInterviewBubble('ai', iv.pending, iv.done ? 'af-iv-bubble-done' : '');
      if (iv.busy) appendInterviewBubble('ai', 'Typing…', 'af-iv-thinking');
    }
    log.scrollTop = log.scrollHeight;
    updateInterviewControls();
  }

  function updateInterviewControls() {
    const businessId = $('af-business-select').value;
    const iv = businessId ? (interviews[businessId] || null) : null;
    const intro = $('af-iv-intro');
    const input = $('af-iv-input');
    const send = $('af-iv-send');
    const start = $('af-iv-start');
    const restart = $('af-iv-restart');
    if (!intro || !input || !send || !start || !restart) return;

    const started = !!(iv && iv.started);
    const ivBusy = !!(iv && iv.busy);
    const canAnswer = started && !ivBusy && !iv.done && !busy;
    // Business first, then strategy, then the interview -- the strategist's opening question is
    // built from both, so letting it start on a half-made selection wastes a paid call.
    const ready = !!businessId && !!$('af-strategy-select').value;

    /* The strategist opens the conversation itself, so this button is no longer part of the normal
       flow. A record that exists but never started means the opening call failed, and that is the
       only moment a human needs a way back in. */
    start.hidden = !(ready && iv && !iv.started);
    start.disabled = busy || ivBusy;
    send.hidden = !started || !!(iv && iv.done);
    send.disabled = !canAnswer || !input.value.trim();
    input.hidden = !started || !!(iv && iv.done);
    input.disabled = !canAnswer;
    restart.hidden = !started;
    restart.disabled = ivBusy || busy;

    // The summary is the approval step, so it appears only once there is a finished brief to approve.
    const briefField = $('af-brief-field');
    if (briefField) briefField.hidden = !(iv && iv.done);

    updateGenerateButtonState();
    intro.hidden = started;
    intro.textContent = !businessId
      ? 'Pick a business above to begin.'
      : !$('af-strategy-select').value
        ? 'Now pick a strategy. The strategist reads both before it asks you anything.'
        : 'The strategist reads the business and strategy you picked, then asks what it still needs to know. Usually three to five questions, about a penny each.';
  }

  /* answer is '' for the opening turn. The businessId is captured up front and re-checked before
     anything touches the DOM: a reply that arrives after the designer has changed client must
     never write into the client now on screen. */
  async function askInterview(answer) {
    const businessId = $('af-business-select').value;
    if (!businessId || !$('af-strategy-select').value) return;
    const iv = interviewFor(businessId);
    if (!iv || iv.busy || iv.done || busy) return;

    if (answer) {
      iv.pairs.push({ question: iv.pending, answer });
      iv.pending = '';
    }
    iv.started = true;
    iv.busy = true;
    const strategyId = $('af-strategy-select').value;
    if (!iv.pairs.length) iv.strategyId = strategyId;
    renderInterview();

    try {
      const data = await postChat('funnelInterview', {
        business: App.businessProfile.getById(businessId),
        strategy: strategyPayloadFor(strategyId ? App.strategy.getById(strategyId) : null),
        transcript: iv.pairs.map((p) => ({ question: p.question, answer: p.answer }))
      });
      iv.pending = typeof data.question === 'string' ? data.question : '';
      iv.done = !!data.done;
      if (typeof data.brief === 'string' && data.brief) {
        briefs[businessId] = data.brief;
        if ($('af-business-select').value === businessId) {
          $('af-differentiator-input').value = data.brief;
        }
      }
    } catch (e) {
      iv.busy = false;
      // A failed OPENING turn leaves nothing on screen to act on, so hand the button back rather
      // than retrying by itself, which would loop on a bad key and spend money doing it.
      if (!iv.pairs.length && !iv.pending) iv.started = false;
      if ($('af-business-select').value === businessId) {
        renderInterview();
        appendInterviewBubble('ai', 'Error: ' + e.message);
      }
      return;
    }
    iv.busy = false;
    if ($('af-business-select').value === businessId) renderInterview();
  }

  /* The strategist opens the conversation as soon as there is a business and a strategy to read.
     Two guards matter. The tab must actually be on screen, because firing a paid call for a tab the
     designer is not looking at is a nasty surprise on someone else's API key. And an existing
     record is never restarted, finished or not: that is what "Start over" is for. */
  function maybeAutoStartInterview() {
    const panel = document.getElementById('tab-aifunnel');
    if (!panel || !panel.classList.contains('active')) return;
    const businessId = $('af-business-select').value;
    if (!businessId || !$('af-strategy-select').value) return;
    if (interviews[businessId] || busy) return;
    askInterview('');
  }

  function sendInterviewAnswer() {
    const input = $('af-iv-input');
    const answer = input.value.trim();
    if (!answer) return;
    input.value = '';
    askInterview(answer);
  }

  /* Clears the conversation but deliberately leaves the brief alone: it is an editable field the
     designer may have rewritten by hand, and losing that to a mis-click would be worse than a
     stale line or two they can edit. */
  function restartInterview() {
    const businessId = $('af-business-select').value;
    if (!businessId || !interviews[businessId]) return;
    if (!window.confirm('Start the interview over? Your brief text below is kept, so you can still edit it.')) return;
    delete interviews[businessId];
    $('af-iv-input').value = '';
    renderInterview();
  }

  function resultIsStale() {
    if (!lastSections.length) return false;
    if (resultBusinessId === UNKNOWN_OWNER) return false;
    const selected = $('af-business-select').value;
    return !!resultBusinessId && !!selected && resultBusinessId !== selected;
  }

  function ownerUnconfirmed() {
    if (resultBusinessId !== UNKNOWN_OWNER || !lastSections.length) return false;
    const chosen = App.businessProfile.getById($('af-business-select').value);
    const name = (chosen && chosen.name) || 'the selected business';
    const ok = window.confirm(
      'This preview was restored from an earlier session, so CodeCraft cannot tell which business '
      + 'it was generated for.\n\nContinue and it will be labelled as ' + name + '. If these '
      + 'sections belong to a different client, cancel and generate again.'
    );
    if (ok) resultBusinessId = $('af-business-select').value || null;
    return !ok;
  }

  function blockedByStaleResult() {
    if (ownerUnconfirmed()) return true;
    if (!resultIsStale()) return false;
    const owner = App.businessProfile.getById(resultBusinessId);
    const chosen = App.businessProfile.getById($('af-business-select').value);
    App.utils.showToast(
      'This preview was generated for ' + ((owner && owner.name) || 'another business') + ', but '
      + ((chosen && chosen.name) || 'a different business') + ' is selected. Generate again before '
      + 'exporting, or the file would carry the wrong name over these sections.'
    );
    return true;
  }

  function updateReviseButtonState() {
    const stale = resultIsStale();
    const usable = lastSections.length && !stale;
    [['af-revise', busy || !usable], ['af-download-html', !usable],
     ['af-download-json', !usable], ['af-save-edit', !usable]].forEach(([id, off]) => {
      const el = $(id);
      if (el) el.disabled = !!off;
    });
  }

  function setBusy(v, isRevise) {
    busy = v;
    const genBtn = $('af-generate');
    if (genBtn && !isRevise) genBtn.textContent = v ? 'Generating…' : 'Generate My Funnel';
    const revBtn = $('af-revise');
    if (revBtn && isRevise) revBtn.textContent = v ? 'Reviewing…' : '🔍 Run Self-Critique & Revise';
    updateReviseButtonState();
    updateGenerateButtonState();
    updateInterviewControls();
  }

  function refreshBusinessOptions() {
    const select = $('af-business-select');
    const current = select.value;
    select.innerHTML = '<option value="">— No business selected —</option>';
    App.businessProfile.list().forEach((b) => {
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = b.name;
      select.appendChild(opt);
    });
    if (Array.from(select.options).some((o) => o.value === current)) select.value = current;
    refreshStrategyOptions();
  }

  function refreshStrategyOptions() {
    const select = $('af-strategy-select');
    const businessId = $('af-business-select').value;
    const current = select.value;
    select.innerHTML = '<option value="">— No strategy selected —</option>';
    let strategies = [];
    if (businessId && App.strategy) {
      strategies = App.strategy.listByBusiness(businessId)
        .map((s) => App.strategy.getById(s.id))
        .filter(Boolean)
        .sort((a, b) => b.updatedAt - a.updatedAt);
      strategies.forEach((s) => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.title;
        select.appendChild(opt);
      });
    }
    // Strategy is required here, but still never force-selected: picking one for the designer
    // would silently decide the funnel's whole angle on their behalf.
    if (Array.from(select.options).some((o) => o.value === current)) select.value = current;
    updateStrategyEmptyState(businessId, strategies.length);
  }

  function updateStrategyEmptyState(businessId, strategyCount) {
    const msg = $('af-strategy-empty-msg');
    if (!msg) return;
    // This IS a blocker now, not a note: with no strategy saved there is no way forward on this
    // tab, so the message has to say where to go rather than reassure.
    msg.hidden = !(businessId && strategyCount === 0);
  }

  /* Generation is gated on a FINISHED interview, not just a non-empty brief: the strategist is
     what makes the brief specific, and a half-answered interview produces exactly the vague input
     the interview was added to prevent. Read interviews[] directly rather than through
     interviewFor(), which creates a record as a side effect -- a state read must not mutate state. */
  function updateGenerateButtonState() {
    const btn = $('af-generate');
    if (!btn) return;
    const businessId = $('af-business-select').value;
    const iv = businessId ? interviews[businessId] : null;
    const finished = !!(iv && iv.done);
    const strategyId = $('af-strategy-select').value;
    const hasStrategy = !!strategyId;
    /* A brief answered against one strategy must not quietly build a page for another. Same family
       of mistake as one client's brief reaching another client's page. */
    const stale = !!(iv && iv.strategyId && strategyId && iv.strategyId !== strategyId);
    btn.disabled = busy || !businessId || !hasStrategy || !finished || stale;
    // A dead button with no reason next to it reads as a broken app, not as a locked step.
    const hint = $('af-generate-hint');
    if (hint) {
      hint.hidden = busy || !businessId || (hasStrategy && finished && !stale);
      hint.textContent = !hasStrategy
        ? 'Pick a strategy above, then answer the strategist.'
        : stale
          ? 'This brief was answered for a different strategy. Use Start over to redo it.'
          : 'Answer the strategist above and this unlocks.';
    }
  }

  function buildSectionsFromResponse(returned) {
    return returned
      .filter((s) => s && typeof s.type === 'string' && typeof s.html === 'string' && typeof s.css === 'string')
      .map((s, i) => ({
        id: 'sec-ai-' + Date.now() + '-' + i,
        type: s.type,
        html: s.html,
        css: s.css
      }));
  }

  function buildPage(sections) {
    const sectionHtml = sections.map((s) => s.html).filter(Boolean);
    const cssParts = sections.map((s) => s.css).filter(Boolean);
    const html = `<div class="page-content">\n${sectionHtml.join('\n')}\n</div>`;
    const css = ['html, body { margin: 0; }', '.page-content { position: relative; }', ...cssParts]
      .filter(Boolean)
      .join('\n\n');
    return { html, css };
  }

  function buildExtraHead(fonts) {
    const links = Array.from(new Set((fonts || []).map((f) => App.getGoogleFontLink(f)).filter(Boolean)));
    return links.join('\n');
  }

  function getSectionsJson() {
    return JSON.stringify(lastSections, null, 2);
  }

  function renderPreview() {
    const hasResult = lastSections.length > 0;
    $('af-preview-wrap').hidden = !hasResult;
    $('af-preview-placeholder').hidden = hasResult;
    if (hasResult) {
      const { html, css } = buildPage(lastSections);
      const extraHead = buildExtraHead(lastFonts);
      $('af-preview-frame').srcdoc = App.utils.buildFullHtmlDoc('AI Funnel Preview', html, css, extraHead);
      $('af-html-code').textContent = html;
      $('af-css-code').textContent = css;
      $('af-json-code').textContent = getSectionsJson();
    }
    updateReviseButtonState();
  }

  function download() {
    if (!lastSections.length || blockedByStaleResult()) return;
    const { html, css } = buildPage(lastSections);
    // Every download used to ship <title>AI Funnel Page</title> -- the browser tab, the bookmark, the
    // search result headline, and the fallback link text for a page that names a real business.
    const business = App.businessProfile.getById($('af-business-select').value);
    const title = App.utils.pageTitleFor(business, 'AI Funnel Page');
    const extraHead = App.utils.buildPageHead(
      App.utils.metaFromBusiness(business, title, html),
      buildExtraHead(lastFonts)
    );
    const filename = App.utils.slugify(business && business.name, 'ai-funnel-page') + '.html';
    App.utils.downloadFile(filename, App.utils.buildFullHtmlDoc(title, html, css, extraHead), 'text/html');
  }

  async function reviseFunnel() {
    if (busy || !lastSections.length || blockedByStaleResult()) return;
    setBusy(true, true);
    const usageBefore = await usageSnapshot();
    progressBegin(
      ['Self-critique & revise pass'],
      'The revise pass re-reads the whole draft against the design rules before returning anything. This usually takes a few minutes. Keep this tab open.'
    );
    try {
      const businessId = $('af-business-select').value;
      const business = businessId ? App.businessProfile.getById(businessId) : null;
      const strategyId = $('af-strategy-select').value;
      const strat = strategyId ? App.strategy.getById(strategyId) : null;

      const data = await postChat('aiFunnelRevise', {
        sections: lastSections.map((s) => ({ type: s.type, html: s.html, css: s.css })),
        fonts: lastFonts,
        business,
        strategy: strategyPayloadFor(strat),
        differentiator: $('af-differentiator-input').value.trim(),
        fontOptions: App.fonts.map((f) => f.value)
      });

      const returned = Array.isArray(data.sections) ? data.sections : [];
      const built = buildSectionsFromResponse(returned);
      if (built.length < 3) {
        throw new Error(`The revise pass only returned ${built.length} usable sections -- kept the previous draft.`);
      }

      lastSections = built;
      resultBusinessId = $('af-business-select').value || resultBusinessId;
      lastFonts = Array.isArray(data.fonts) ? data.fonts.filter((f) => typeof f === 'string') : lastFonts;
      renderPreview();
      App.persistence.saveToLocalStorage();
      const summary = typeof data.changesSummary === 'string' && data.changesSummary.trim()
        ? data.changesSummary.trim()
        : 'Self-critique pass complete.';
      App.utils.showToast(summary + await costSuffixSince(usageBefore));
      progressEnd(true);
    } catch (e) {
      App.utils.showToast('Revise error: ' + e.message);
      progressEnd(false);
    } finally {
      setBusy(false, true);
    }
  }

  async function generateFunnel() {
    if (busy) return;
    const businessId = $('af-business-select').value;
    if (!businessId) {
      App.utils.showToast('Choose a Business first.');
      return;
    }
    setBusy(true);
    const usageBefore = await usageSnapshot();
    progressBegin(
      ['Deciding the visual identity', 'Inventing structure & copy', 'Self-critique & revise pass'],
      'Three AI passes run back to back, and none of them stream -- nothing arrives until each one finishes. This usually takes a few minutes. Keep this tab open.'
    );
    const genBtn = $('af-generate');
    try {
      const business = App.businessProfile.getById(businessId);
      const strategyId = $('af-strategy-select').value;
      const strat = strategyId ? App.strategy.getById(strategyId) : null;
      const strategyPayload = strategyPayloadFor(strat);
      const differentiator = $('af-differentiator-input').value.trim();
      const fontOptions = App.fonts.map((f) => f.value);

      /* Decide how the page will LOOK before anything is written. Kept as its own call on purpose:
         design choices made in passing, while also inventing structure and copy, come out as
         whatever is most familiar, which is how every page ended up looking the same. A failure
         here must not cost the user the whole run -- the page prompt treats a null commitment as
         "no contract" and generates as it did before, so we warn and carry on. */
      let commitment = null;
      try {
        commitment = await postChat('designCommitment', {
          business,
          strategy: strategyPayload,
          differentiator,
          fontOptions
        });
      } catch (commitErr) {
        // A spent trial is not a design failure and carrying on would just fail again one call
        // later with a confusing toast in between -- let the outer handler report it properly.
        if (/free trial is used up/i.test(commitErr.message)) throw commitErr;
        App.utils.showToast('Could not settle on a design direction, generating without one: ' + commitErr.message);
      }
      if (genBtn) genBtn.textContent = 'Writing the page…';
      progressAdvance();

      const data = await postChat('aiFunnel', {
        business,
        strategy: strategyPayload,
        differentiator,
        fontOptions,
        commitment
      });

      const returned = Array.isArray(data.sections) ? data.sections : [];
      const built = buildSectionsFromResponse(returned);
      if (built.length < 3) {
        throw new Error(`The AI response only produced ${built.length} usable sections -- try again.`);
      }

      let finalSections = built;
      let finalFonts = Array.isArray(data.fonts) ? data.fonts.filter((f) => typeof f === 'string') : [];

      // Every generation now runs through the same self-critique-and-revise pass the standalone
      // button triggers -- the whole point of the anti-slop doctrine is to actually apply it, not
      // just make it optional. A failure here keeps the raw generated funnel rather than losing it.
      if (genBtn) genBtn.textContent = 'Reviewing & polishing…';
      progressAdvance();
      try {
        const reviseData = await postChat('aiFunnelRevise', {
          sections: finalSections.map((s) => ({ type: s.type, html: s.html, css: s.css })),
          fonts: finalFonts,
          business,
          strategy: strategyPayload,
          differentiator,
          fontOptions,
          commitment
        });
        const revisedReturned = Array.isArray(reviseData.sections) ? reviseData.sections : [];
        const revisedBuilt = buildSectionsFromResponse(revisedReturned);
        if (revisedBuilt.length >= 3) {
          finalSections = revisedBuilt;
          finalFonts = Array.isArray(reviseData.fonts) ? reviseData.fonts.filter((f) => typeof f === 'string') : finalFonts;
        }
      } catch (reviseErr) {
        App.utils.showToast('Generated, but the self-critique pass failed: ' + reviseErr.message);
      }

      lastSections = finalSections;
      resultBusinessId = businessId || $('af-business-select').value || null;
      lastFonts = finalFonts;
      renderPreview();
      // The click-based autosave (js/persistence.js) fires on the click that started this async work,
      // well before this awaited API call resolves -- save explicitly so the result isn't silently
      // lost on reload, matching the same reasoning already used in funnelBuilder.js.
      App.persistence.saveToLocalStorage();
      // Back up right after a generation lands -- this is the moment the project contains
      // something the user paid real money for. Fire-and-forget: a failed backup must not
      // interfere with the funnel they just waited nine minutes for.
      App.persistence.backupToServer();
      App.utils.showToast('Funnel generated and reviewed.' + await costSuffixSince(usageBefore));
      progressEnd(true);
    } catch (e) {
      App.utils.showToast('Generate error: ' + e.message);
      progressEnd(false);
      // A trial-exhausted refusal is not really an error the user can fix here -- point them at
      // the one place that resolves it.
      if (/free trial is used up/i.test(e.message) && App.account) App.account.refresh();
    } finally {
      setBusy(false);
    }
  }

  function syncBusinessSelection() {
    refreshBusinessOptions();
    const state = App.businessProfile.getState();
    if (state.activeId && App.businessProfile.getById(state.activeId)) {
      $('af-business-select').value = state.activeId;
      refreshStrategyOptions();
    }
  }

  function getState() {
    return {
      businessId: $('af-business-select').value,
      strategyId: $('af-strategy-select').value,
      differentiator: $('af-differentiator-input').value,
      briefs: Object.assign({}, briefs,
        briefOwnerId ? { [briefOwnerId]: $('af-differentiator-input').value } : {}),
      interviews,
      resultBusinessId,
      lastSections,
      lastFonts
    };
  }

  function setState(data) {
    if (!data) return;
    // Old saved projects have lastSections shaped {id, type, state} (pre-pivot, generator-schema
    // shape). Drop anything that doesn't look like the new {id, type, html, css} shape rather than
    // rendering broken/empty sections -- safe fallback, never throw.
    lastSections = Array.isArray(data.lastSections)
      ? data.lastSections.filter((s) => s && typeof s.html === 'string' && typeof s.css === 'string')
      : [];
    lastFonts = Array.isArray(data.lastFonts) ? data.lastFonts.filter((f) => typeof f === 'string') : [];
    // Older projects predate this field, and the saved businessId cannot stand in for it: it
    // records what the dropdown held at save time, which is exactly what drifts. So a restored
    // result whose owner was never recorded is marked UNKNOWN and confirmed before it is
    // branded with anyone's name, rather than being quietly assumed to belong to the selection.
    resultBusinessId = typeof data.resultBusinessId === 'string' && data.resultBusinessId
      ? data.resultBusinessId
      : (lastSections.length ? UNKNOWN_OWNER : null);
    Object.keys(briefs).forEach((k) => { delete briefs[k]; });
    if (data.briefs && typeof data.briefs === 'object') {
      Object.keys(data.briefs).forEach((k) => {
        if (typeof data.briefs[k] === 'string') briefs[k] = data.briefs[k];
      });
    } else if (typeof data.differentiator === 'string' && data.differentiator && data.businessId) {
      // Pre-map projects kept one string. It belongs to whichever business was selected then,
      // and to that one only -- never to whatever gets selected next.
      briefs[data.businessId] = data.differentiator;
    }
    refreshBusinessOptions();
    if (data.businessId) {
      $('af-business-select').value = data.businessId;
      refreshStrategyOptions();
    }
    Object.keys(interviews).forEach((k) => { delete interviews[k]; });
    if (data.interviews && typeof data.interviews === 'object') {
      Object.keys(data.interviews).forEach((k) => {
        const iv = data.interviews[k];
        if (!iv || typeof iv !== 'object' || !Array.isArray(iv.pairs)) return;
        interviews[k] = {
          pairs: iv.pairs.filter((p) => p && typeof p.question === 'string' && typeof p.answer === 'string'),
          pending: typeof iv.pending === 'string' ? iv.pending : '',
          done: !!iv.done,
          started: !!iv.started,
          strategyId: typeof iv.strategyId === 'string' ? iv.strategyId : '',
          busy: false  // a run in flight at save time is long gone by the time this restores
        };
      });
    }
    loadBriefFor($('af-business-select').value);
    if (data.strategyId) $('af-strategy-select').value = data.strategyId;
    renderInterview();
    renderPreview();
  }

  function init() {
    $('af-generate').addEventListener('click', generateFunnel);
    $('af-revise').addEventListener('click', reviseFunnel);
    $('af-download-html').addEventListener('click', download);
    $('af-download-json').addEventListener('click', () => {
      if (!lastSections.length || blockedByStaleResult()) return;
      App.utils.downloadFile('ai-funnel-sections.json', getSectionsJson(), 'application/json');
    });
    $('af-save-edit').addEventListener('click', () => {
      if (!lastSections.length || !App.pages || blockedByStaleResult()) return;
      const page = App.pages.createFromSections($('af-business-select').value, lastSections, lastFonts);
      App.utils.showToast('Page saved.');
      document.querySelector('.tab-btn[data-tab="pages"]').click();
      App.pages.openEditor(page.id);
    });
    $('af-business-select').addEventListener('change', () => {
      stashCurrentBrief();
      loadBriefFor($('af-business-select').value);
      App.businessProfile.selectBusiness($('af-business-select').value);
      refreshStrategyOptions();
      updateReviseButtonState();
      renderInterview();
      maybeAutoStartInterview();
    });
    $('af-strategy-select').addEventListener('change', () => {
      updateGenerateButtonState();
      updateInterviewControls();
      updateReviseButtonState();
      maybeAutoStartInterview();
    });
    $('af-iv-start').addEventListener('click', () => askInterview(''));
    $('af-iv-send').addEventListener('click', sendInterviewAnswer);
    $('af-iv-restart').addEventListener('click', restartInterview);
    $('af-iv-input').addEventListener('input', updateInterviewControls);
    /* Enter sends, Shift+Enter makes a new line -- the convention every chat box already uses. */
    $('af-iv-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendInterviewAnswer();
      }
    });
    refreshBusinessOptions();
    const initialId = App.businessProfile.getState().activeId;
    if (initialId && App.businessProfile.getById(initialId)) {
      $('af-business-select').value = initialId;
      refreshStrategyOptions();
    }
    if (briefOwnerId !== $('af-business-select').value) loadBriefFor($('af-business-select').value);
    renderInterview();
    renderPreview();
  }

  App.aiFunnel = { init, getState, setState, refreshBusinessOptions, syncBusinessSelection,
    maybeAutoStartInterview };
})(window.App);
