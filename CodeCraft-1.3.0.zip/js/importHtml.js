/* Import a previously exported page back into the Page Editor.

   The AI Funnel's "Download HTML" (js/aiFunnel.js) and the Page Editor's own download both flatten a
   page into a single self-contained document: one <style> block holding every section's CSS, and a
   <div class="page-content"> holding every section's markup back to back. That flattening is lossy in
   exactly one way -- it forgets where each section ended and the next began -- so this module rebuilds
   those boundaries from the markup itself and hands the result to pages.createFromSections(), the same
   entry point the URL importer uses.

   Section boundaries come from the top-level children of .page-content. CSS is re-split by walking the
   stylesheet's top-level rules and matching each one against the section root class it targets, which
   works because the generator enforces one unique root class per section (see the self-scoping rule in
   server.js's system prompt) and prefixes @keyframes names with that same class. */
(function (App) {
  'use strict';

  // Re-added by pages.js's pageContentParts() on every export, so importing them back would duplicate
  // them a little more on each round trip.
  const SHELL_RULE_SELECTORS = ['html, body', '.page-content'];

  // Titles the exporters write when a page has no real name of its own. Dropping them lets
  // uniqueTitleFor() fall back to the active business name instead of importing a generic label.
  const PLACEHOLDER_TITLES = ['ai funnel page', 'ai funnel preview', 'page preview', 'page', ''];

  const FONT_HOST_RE = /fonts\.googleapis\.com|fonts\.bunny\.net|use\.typekit\.net/i;

  /* ---------- CSS splitting ---------- */

  // Splits a stylesheet into its top-level rules. Brace-counting rather than a regex so nested blocks
  // (@media, @supports) survive intact, and so a brace inside a string or comment -- e.g.
  // content:"{" or a commented-out rule -- cannot end a rule early.
  function splitTopLevelRules(css) {
    const rules = [];
    let depth = 0;
    let start = 0;
    let i = 0;
    let quote = null;

    while (i < css.length) {
      const ch = css[i];

      if (quote) {
        if (ch === '\\') { i += 2; continue; }
        if (ch === quote) quote = null;
        i++;
        continue;
      }
      if (ch === '"' || ch === "'") { quote = ch; i++; continue; }
      if (ch === '/' && css[i + 1] === '*') {
        const end = css.indexOf('*/', i + 2);
        i = end === -1 ? css.length : end + 2;
        continue;
      }
      if (ch === '{') { depth++; i++; continue; }
      if (ch === '}') {
        depth--;
        i++;
        if (depth <= 0) {
          const chunk = css.slice(start, i).trim();
          if (chunk) rules.push(chunk);
          start = i;
          depth = 0;
        }
        continue;
      }
      // A top-level statement with no block of its own, e.g. @import or @charset.
      if (ch === ';' && depth === 0) {
        const chunk = css.slice(start, i + 1).trim();
        if (chunk) rules.push(chunk);
        start = i + 1;
      }
      i++;
    }

    const tail = css.slice(start).trim();
    if (tail) rules.push(tail);
    return rules;
  }

  function selectorOf(rule) {
    const brace = rule.indexOf('{');
    return (brace === -1 ? rule : rule.slice(0, brace)).trim();
  }

  function isShellRule(rule) {
    const selector = selectorOf(rule).replace(/\s+/g, ' ').toLowerCase();
    return SHELL_RULE_SELECTORS.some((s) => selector === s);
  }

  function escapeRe(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // Matches the root class where it ends OR continues into a BEM suffix -- ".rp-hero-3a1" has to claim
  // ".rp-hero-3a1__wrap" and the "@keyframes rp-hero-3a1-fadeup" the generator prefixes for it, while
  // still refusing ".rp-hero-3a1b", which is a different class. Hence excluding only alphanumerics
  // after the name: "_" and "-" are how a suffix starts, a letter or digit is how a longer name does.
  function ruleTargets(rule, rootClass) {
    return new RegExp('[.\\s,>+~(]' + escapeRe(rootClass) + '(?![A-Za-z0-9])').test(' ' + rule);
  }

  /* ---------- Section typing ---------- */

  const TAG_TYPES = { HEADER: 'navbar', FOOTER: 'footer', NAV: 'navbar', MAIN: 'main', ASIDE: 'aside' };

  // The generator names root classes semantically with a short uniqueness suffix ("rp-hero-3a1",
  // "pricing-cta-9f3"), so the last non-suffix token is a good label. Purely cosmetic -- type only
  // drives the Navigator's row labels and the section chrome in the editor canvas.
  function inferType(el, rootClass) {
    if (rootClass) {
      const tokens = rootClass.split('-').filter(Boolean);
      // Drop a trailing uniqueness hash ("8f2", "9f3", "7k4") -- short and containing a digit.
      const last = tokens[tokens.length - 1];
      if (tokens.length > 1 && /\d/.test(last) && last.length <= 4) tokens.pop();
      const label = tokens[tokens.length - 1];
      if (label && !/^\d+$/.test(label)) return label;
    }
    return TAG_TYPES[el.tagName] || el.tagName.toLowerCase();
  }

  /* ---------- Parsing ---------- */

  // Returns { title, sections, fontLinks, orphanCount }. Throws with a message meant for a toast when
  // the document has nothing importable in it.
  function parseDoc(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    if (!doc || !doc.body) throw new Error('that file is not valid HTML');

    // .page-content is what both exporters wrap sections in; falling back to <body> lets a hand-edited
    // or externally-saved page still import, just with whatever top-level structure it happens to have.
    const container = doc.querySelector('.page-content') || doc.body;

    const sectionEls = Array.from(container.children).filter(
      (el) => !['SCRIPT', 'STYLE', 'LINK', 'TEMPLATE'].includes(el.tagName)
    );
    if (!sectionEls.length) throw new Error('no page sections found in that file');

    const css = Array.from(doc.querySelectorAll('style')).map((s) => s.textContent || '').join('\n');
    const rules = splitTopLevelRules(css).filter((r) => !isShellRule(r));

    const rootClasses = sectionEls.map((el) => el.classList[0] || '');
    const buckets = sectionEls.map(() => []);
    const orphans = [];

    // Test the longest root class first, so that if one section's class is a prefix of another's
    // (".card" and ".card-grid"), each rule lands on the more specific of the two rather than on
    // whichever section happens to come first in the document.
    const bySpecificity = rootClasses
      .map((cls, idx) => ({ cls, idx }))
      .filter((e) => e.cls)
      .sort((a, b) => b.cls.length - a.cls.length);

    rules.forEach((rule) => {
      const hit = bySpecificity.find((e) => ruleTargets(rule, e.cls));
      if (hit) buckets[hit.idx].push(rule);
      else orphans.push(rule);
    });

    // Anything that could not be traced to a section rides along on the first one rather than being
    // dropped, which keeps the page rendering as it did before export even when the stylesheet was
    // hand-edited.
    if (orphans.length) buckets[0] = orphans.concat(buckets[0]);

    const stamp = Date.now();
    const sections = sectionEls.map((el, i) => ({
      id: 'sec-html-' + stamp + '-' + i,
      type: inferType(el, rootClasses[i]),
      html: el.outerHTML,
      css: buckets[i].join('\n\n')
    }));

    const fontLinks = Array.from(doc.querySelectorAll('link[href]'))
      .map((l) => l.getAttribute('href') || '')
      .filter((href) => FONT_HOST_RE.test(href));

    const rawTitle = (doc.title || '').trim();
    const title = PLACEHOLDER_TITLES.includes(rawTitle.toLowerCase()) ? '' : rawTitle;

    return { title, sections, fontLinks: Array.from(new Set(fontLinks)), orphanCount: orphans.length };
  }

  /* ---------- Entry point ---------- */

  // Called by persistence.js's importProject() once it has sniffed the file as HTML rather than a
  // project JSON. Creates a new page (never overwrites one), reveals the Page Editor, and opens it.
  function importFromText(text) {
    const { title, sections, fontLinks, orphanCount } = parseDoc(text);

    const businessId = (App.businessProfile && App.businessProfile.getState().activeId) || null;
    const page = App.pages.createFromSections(businessId, sections, [], fontLinks);
    if (title) {
      page.title = title;
      if (App.persistence) App.persistence.saveToLocalStorage();
    }

    // Reuse the tab button's own click handler so every side effect of a tab switch still runs.
    const pagesTab = document.querySelector('.tab-btn[data-tab="pages"]');
    if (pagesTab) pagesTab.click();
    App.pages.openEditor(page.id);

    const noun = sections.length === 1 ? 'section' : 'sections';
    const orphanNote = orphanCount
      ? ` ${orphanCount} unscoped style ${orphanCount === 1 ? 'rule' : 'rules'} attached to the first section.`
      : '';
    App.utils.showToast(`Imported ${sections.length} ${noun} from HTML.${orphanNote}`);
  }

  App.importHtml = { parseDoc, importFromText };
})(window.App);
