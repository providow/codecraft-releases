/* Funnel Strategy tab: a saved library of rich funnel-strategy briefs, each tied to one business.
   Mirrors js/businessProfile.js's {id, ...}/cloneState list pattern, extended with nested-field
   binding (STRATEGY_SECTIONS + dot-path get/set) since a brief's fields aren't flat like a business
   profile's. */
(function (App) {
  'use strict';
  const $ = (id) => document.getElementById(id);

  // Shared by both the single-strategy and Strategy Set "goal" dropdowns -- a real preset value
  // is used verbatim as the saved goal string; 'not-sure' means no goal was stated (goal: '');
  // 'other' reveals a free-text field instead.
  const GOAL_PRESETS = [
    'Generate leads or inquiries',
    'Book calls or appointments',
    'Sell a product or service',
    'Collect email signups',
    'Get event or webinar registrations',
    'Get app downloads'
  ];

  function getGoalValue(prefix) {
    const select = $(prefix + '-goal-select');
    if (!select) return '';
    if (select.value === 'not-sure') return '';
    if (select.value === 'other') return $(prefix + '-goal').value.trim();
    return select.value;
  }

  function setGoalControls(prefix, goal) {
    const select = $(prefix + '-goal-select');
    const wrap = $(prefix + '-goal-other-wrap');
    const otherInput = $(prefix + '-goal');
    if (!select) return;
    if (!goal) {
      select.value = 'not-sure';
      otherInput.value = '';
    } else if (GOAL_PRESETS.includes(goal)) {
      select.value = goal;
      otherInput.value = '';
    } else {
      select.value = 'other';
      otherInput.value = goal;
    }
    if (wrap) wrap.hidden = select.value !== 'other';
  }

  function updateGoalOtherVisibility(prefix) {
    const select = $(prefix + '-goal-select');
    const wrap = $(prefix + '-goal-other-wrap');
    if (select && wrap) wrap.hidden = select.value !== 'other';
  }

  const STRATEGY_SECTIONS = [
    {
      heading: 'Target Audience & Core Insights',
      icon: '👥',
      fields: [
        { path: ['audience', 'whoTheyAre'], label: 'Who They Are', kind: 'textarea', tint: 'blue' },
        { path: ['audience', 'corePain'], label: 'Core Pain', kind: 'textarea', tint: 'red' },
        { path: ['audience', 'coreDesire'], label: 'Core Desire', kind: 'textarea', tint: 'green' }
      ]
    },
    {
      heading: 'Offer Details',
      icon: '🎯',
      fields: [
        { path: ['offer', 'description'], label: 'Offer', kind: 'textarea', tint: 'green' },
        { path: ['offer', 'price'], label: 'Price', kind: 'text' },
        { path: ['offer', 'priceTag'], label: 'Price Tag', kind: 'text' },
        { path: ['offer', 'xFactor'], label: 'X-Factor', kind: 'textarea' },
        { path: ['offer', 'conversionGoal'], label: 'Conversion Goal', kind: 'text' }
      ]
    },
    {
      heading: 'Objections & Proof',
      icon: '⚠️',
      fields: [
        { path: ['objections', 'primary'], label: 'Primary Objections', kind: 'numbered-list' },
        { path: ['objections', 'proofAssets'], label: 'Proof Assets', kind: 'checklist' }
      ]
    },
    {
      heading: 'Traffic & Trust',
      icon: '🔗',
      fields: [
        { path: ['traffic', 'source'], label: 'Traffic Source', kind: 'text' },
        { path: ['traffic', 'trustLevel'], label: 'Trust Level', kind: 'select', options: ['Low', 'Medium', 'High'] },
        { path: ['traffic', 'microWinEntryPoint'], label: 'Micro-Win Entry Point', kind: 'text' }
      ]
    },
    {
      heading: 'Messaging Strategy',
      icon: '💬',
      fields: [
        { path: ['messaging', 'angleName'], label: 'Angle Name', kind: 'text' },
        { path: ['messaging', 'angleDescription'], label: 'Description', kind: 'textarea' },
        { path: ['messaging', 'primaryAngle'], label: 'Primary Angle', kind: 'text' },
        { path: ['messaging', 'tone'], label: 'Tone', kind: 'text' },
        { path: ['messaging', 'copyApproach'], label: 'Copy Approach', kind: 'text' },
        { path: ['messaging', 'keyMessages'], label: 'Key Messages', kind: 'lines' },
        { path: ['messaging', 'copyStructure'], label: 'Copy Structure', kind: 'text' }
      ]
    },
    {
      heading: 'Recommended Funnel Type',
      icon: '🧭',
      fields: [
        { path: ['funnelType', 'type'], label: 'Funnel Type', kind: 'text' },
        { path: ['funnelType', 'reasoning'], label: 'Reasoning', kind: 'textarea' }
      ]
    }
  ];

  let strategies = [];
  let activeId = null;
  let nextId = 1;
  let busy = false;
  let reviewCandidateKey = null; // null = saved-record view; a key = read-only candidate preview
  let isEditMode = false; // saved-record view starts read-only; "Edit" unlocks it, "Save" re-locks it
  let searchQuery = '';
  let rightPanelMode = 'record'; // 'record' | 'candidate' | 'setItem' -- single source of truth for
                                   // which of the three mutually-exclusive views currently owns the
                                   // shared #fs-brief + action bar (see updateActionBar())
  let pendingSet = null; // { setId, businessId, idea, items:[{productName, brief, selected}], activeProductName }
                          // In-memory only -- an in-progress, not-yet-committed set is scratch review
                          // state, not persisted via getState()/setState(). Nothing touches
                          // strategies[]/localStorage until commitSet() runs.
  let busySet = false;
  let collapsedSets = new Set(); // session-only: which strategySetId groups are manually collapsed
                                   // in the saved-strategies list (default: all expanded)

  function cloneState(s) {
    return JSON.parse(JSON.stringify(s));
  }

  function getPath(obj, path) {
    return path.reduce((acc, key) => (acc == null ? undefined : acc[key]), obj);
  }

  function setPath(obj, path, value) {
    let cur = obj;
    for (let i = 0; i < path.length - 1; i++) {
      if (cur[path[i]] == null) cur[path[i]] = {};
      cur = cur[path[i]];
    }
    cur[path[path.length - 1]] = value;
  }

  /* ---------- Strategy records ---------- */
  function emptyStrategy() {
    const now = Date.now();
    return {
      id: 'strat-' + (nextId++),
      businessId: null,
      productName: '',
      goal: '',
      idea: '',
      candidates: [],
      recommendedKey: '',
      recommendedReason: '',
      chosenKey: '',
      strategySetId: null,
      title: '',
      audience: { whoTheyAre: '', corePain: '', coreDesire: '' },
      offer: { description: '', price: '', priceTag: '', xFactor: '', conversionGoal: '' },
      objections: { primary: [], proofAssets: [] },
      traffic: { source: '', trustLevel: 'Medium', microWinEntryPoint: '' },
      messaging: { angleName: '', angleDescription: '', primaryAngle: '', tone: '', copyApproach: '', keyMessages: [], copyStructure: '' },
      funnelType: { type: '', reasoning: '' },
      createdAt: now,
      updatedAt: now
    };
  }

  function getById(id) {
    return strategies.find((s) => s.id === id) || null;
  }

  function readFormIntoActive() {
    const record = getById(activeId);
    if (!record) return;
    record.businessId = $('fs-business-select').value || null;
    record.productName = $('fs-product-select').value || '';
    record.goal = getGoalValue('fs');
    record.idea = $('fs-idea').value;
    // Only write brief fields back when showing the editable saved-record view -- a read-only
    // candidate preview OR a not-yet-committed set-item preview must never bleed its displayed
    // content into an unrelated record via stray input/change/click autosave events.
    if (rightPanelMode === 'record') {
      readStrategyBriefIntoData($('fs-brief'), record);
    }
  }

  function refreshProductOptions(selectedName) {
    const select = $('fs-product-select');
    if (!select) return;
    const businessId = $('fs-business-select').value;
    const business = businessId && App.businessProfile ? App.businessProfile.getById(businessId) : null;
    const products = (business && business.products) || [];
    select.innerHTML = '<option value="">— Whole business (no specific product) —</option>';
    products.forEach((p) => {
      if (!p.name) return;
      const billingSuffix = p.billing === 'monthly' ? '/mo' : p.billing === 'annually' ? '/yr' : '';
      const opt = document.createElement('option');
      opt.value = p.name;
      opt.textContent = p.name + (p.price ? ' — ' + p.price + billingSuffix : '');
      select.appendChild(opt);
    });
    // Same rationale as refreshBusinessOptions(): fall back to the active record's own
    // productName rather than the DOM's current value, which may be stale from an earlier
    // refresh that ran before this select had the right options to match against.
    const record = getById(activeId);
    const want = selectedName !== undefined ? selectedName : (record ? record.productName || '' : select.value);
    select.value = Array.from(select.options).some((o) => o.value === want) ? want : '';
  }

  function loadIntoForm(record) {
    const s = record || emptyStrategy();
    $('fs-business-select').value = s.businessId || '';
    refreshProductOptions(s.productName || '');
    setGoalControls('fs', s.goal || '');
    $('fs-idea').value = s.idea || '';
    reviewCandidateKey = null;
    isEditMode = false;
    rightPanelMode = 'record';
    populateStrategyBrief($('fs-brief'), s);
    setStrategyBriefEditable($('fs-brief'), false);
    $('fs-use-strategy').hidden = true;
    renderCandidateTabs();
    updateGenerateButtonState();
    updateActionBar();
  }

  // Single dispatcher for the shared action bar around #fs-brief -- three mutually-exclusive views
  // (saved record / read-only candidate preview / read-only set-item preview) all reuse the same
  // DOM, so one function owning all their button visibility avoids each view needing to know how to
  // hide the OTHER views' buttons (the exact shape of bug that causes stale/flickering visibility).
  function updateActionBar() {
    const editBtn = $('fs-edit-brief');
    const saveBtn = $('fs-save-brief');
    const useBtn = $('fs-use-strategy');
    const regenBtn = $('fss-regenerate-item');
    const useSetBtn = $('fss-use-set');
    if (!editBtn || !saveBtn) return;
    const isRecord = rightPanelMode === 'record';
    const isCandidate = rightPanelMode === 'candidate';
    const isSetItem = rightPanelMode === 'setItem';
    editBtn.hidden = !isRecord || isEditMode;
    saveBtn.hidden = !isRecord || !isEditMode;
    if (useBtn) useBtn.hidden = !isCandidate;
    if (regenBtn) regenBtn.hidden = !isSetItem;
    if (useSetBtn) useSetBtn.hidden = !isSetItem;
  }

  function enterEditMode() {
    if (rightPanelMode !== 'record') return;
    isEditMode = true;
    setStrategyBriefEditable($('fs-brief'), true);
    updateActionBar();
  }

  function saveBriefAndExit() {
    saveNow();
    isEditMode = false;
    setStrategyBriefEditable($('fs-brief'), false);
    // Delay the Save -> Edit button swap so the "✓ Saved" flash (see flashSaveButton, ~1.4s)
    // stays visible instead of being hidden the instant it appears.
    setTimeout(updateActionBar, 1450);
  }

  function isBlank(record) {
    if (!record) return true;
    if (record.candidates && record.candidates.length) return false;
    return !record.idea.trim() && !record.title.trim() && !record.goal;
  }

  function showSaved() {
    const el = $('fs-save-status');
    if (!el) return;
    const time = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    el.textContent = `✓ Saved at ${time}`;
    el.classList.add('is-saved');
  }

  let flashTimer = null;
  function flashSaveButton() {
    const btn = $('fs-save-brief');
    if (!btn) return;
    clearTimeout(flashTimer);
    btn.textContent = '✓ Saved';
    btn.classList.add('btn-save-flash');
    flashTimer = setTimeout(() => {
      btn.textContent = '💾 Save';
      btn.classList.remove('btn-save-flash');
    }, 1400);
  }

  function saveNow() {
    readFormIntoActive();
    showSaved();
    renderList();
    if (App.persistence && typeof App.persistence.saveToLocalStorage === 'function') {
      App.persistence.saveToLocalStorage();
    }
    flashSaveButton();
  }

  function summaryFor(record) {
    return record.title.trim() || (record.idea.trim() ? record.idea.trim().slice(0, 40) : '') || record.goal || 'Untitled Strategy';
  }

  function businessNameFor(record) {
    if (!record.businessId || !App.businessProfile) return '';
    const biz = App.businessProfile.getById(record.businessId);
    return biz ? biz.name : '';
  }

  function matchesSearch(record) {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    const haystack = [summaryFor(record), businessNameFor(record), record.idea, record.offer && record.offer.description]
      .filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(q);
  }

  function renderStrategyRow(container, record) {
    const row = document.createElement('div');
    row.className = 'funnel-row' + (record.id === activeId ? ' is-active' : '');

    const main = document.createElement('div');
    main.className = 'funnel-row-main';
    const nameEl = document.createElement('div');
    nameEl.className = 'funnel-row-type';
    nameEl.textContent = summaryFor(record);
    const summaryEl = document.createElement('div');
    summaryEl.className = 'funnel-row-summary';
    const parts = [];
    const bizName = businessNameFor(record);
    if (bizName) parts.push(bizName);
    if (record.offer && record.offer.description) parts.push(record.offer.description);
    summaryEl.textContent = parts.join(' · ');
    main.appendChild(nameEl);
    main.appendChild(summaryEl);
    row.appendChild(main);

    const actions = document.createElement('div');
    actions.className = 'funnel-row-actions';

    const selectBtn = document.createElement('button');
    selectBtn.type = 'button';
    selectBtn.className = 'btn funnel-row-btn';
    selectBtn.textContent = record.id === activeId ? 'Editing' : 'Select';
    selectBtn.disabled = record.id === activeId;
    selectBtn.addEventListener('click', () => selectStrategy(record.id));

    const dupBtn = document.createElement('button');
    dupBtn.type = 'button';
    dupBtn.className = 'btn funnel-row-btn';
    dupBtn.textContent = 'Duplicate';
    dupBtn.addEventListener('click', () => duplicateStrategy(record.id));

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'btn funnel-row-btn';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Delete strategy';
    removeBtn.addEventListener('click', () => deleteStrategy(record.id));

    actions.append(selectBtn, dupBtn, removeBtn);
    row.appendChild(actions);
    container.appendChild(row);
  }

  function renderSetGroup(container, setId, members, visibleMembers) {
    const wrap = document.createElement('div');
    wrap.className = 'fs-set-group';
    const forceExpand = !!searchQuery.trim(); // an active search always wins over manual collapse
    const collapsed = !forceExpand && collapsedSets.has(setId);

    const header = document.createElement('button');
    header.type = 'button';
    header.className = 'fs-set-group-header';
    const caret = document.createElement('span');
    caret.className = 'fs-set-group-caret';
    caret.textContent = collapsed ? '▸' : '▾';
    const label = document.createElement('span');
    const bizName = businessNameFor(members[0]);
    label.textContent = (bizName ? bizName + ' — ' : '') + `Strategy Set (${members.length})`;
    header.append(caret, label);
    header.addEventListener('click', () => {
      if (collapsedSets.has(setId)) collapsedSets.delete(setId); else collapsedSets.add(setId);
      renderList();
    });
    wrap.appendChild(header);

    if (!collapsed) {
      const body = document.createElement('div');
      body.className = 'fs-set-group-body';
      visibleMembers.forEach((m) => renderStrategyRow(body, m));
      wrap.appendChild(body);
    }
    container.appendChild(wrap);
  }

  function renderList() {
    const container = $('fs-strategy-list');
    if (!container) return;
    container.innerHTML = '';
    const anyVisible = strategies.some(matchesSearch);
    if (searchQuery.trim() && !anyVisible) {
      const empty = document.createElement('div');
      empty.className = 'funnel-preview-empty-msg';
      empty.textContent = 'No saved strategies match your search.';
      container.appendChild(empty);
    }
    const renderedSets = new Set();
    strategies.forEach((record) => {
      if (record.strategySetId) {
        if (renderedSets.has(record.strategySetId)) return;
        renderedSets.add(record.strategySetId);
        const members = strategies.filter((s) => s.strategySetId === record.strategySetId);
        const visibleMembers = members.filter(matchesSearch);
        if (!visibleMembers.length) return; // whole group hidden if search matches none of its members
        renderSetGroup(container, record.strategySetId, members, visibleMembers);
      } else {
        if (!matchesSearch(record)) return;
        renderStrategyRow(container, record);
      }
    });
  }

  function selectStrategy(id) {
    if (id === activeId) return;
    readFormIntoActive();
    const leaving = getById(activeId);
    if (leaving && isBlank(leaving)) {
      strategies = strategies.filter((s) => s.id !== leaving.id);
    }
    activeId = id;
    const record = getById(activeId);
    if (record && record.businessId) App.businessProfile.selectBusiness(record.businessId);
    loadIntoForm(record);
    renderList();
  }

  function newStrategy() {
    readFormIntoActive();
    const leaving = getById(activeId);
    if (leaving && isBlank(leaving)) {
      strategies = strategies.filter((s) => s.id !== leaving.id);
    }
    const s = emptyStrategy();
    strategies.push(s);
    activeId = s.id;
    loadIntoForm(s);
    renderList();
    switchPanel('create');
  }

  function duplicateStrategy(id) {
    if (id === activeId) readFormIntoActive();
    const idx = strategies.findIndex((s) => s.id === id);
    if (idx === -1) return;
    const clone = cloneState(strategies[idx]);
    clone.id = 'strat-' + (nextId++);
    clone.title = (clone.title || 'Untitled Strategy') + ' (Copy)';
    strategies.splice(idx + 1, 0, clone);
    renderList();
  }

  function deleteStrategy(id) {
    const idx = strategies.findIndex((s) => s.id === id);
    if (idx === -1) return;
    strategies.splice(idx, 1);
    if (id === activeId) {
      const next = strategies[idx - 1] || strategies[idx] || null;
      if (next) {
        activeId = next.id;
        loadIntoForm(next);
      } else {
        activeId = null;
        newStrategy();
        return;
      }
    }
    renderList();
  }

  /* ---------- Rich brief DOM: built once, populated/toggled repeatedly ---------- */
  function autoGrow(el) {
    el.style.height = 'auto';
    el.style.height = el.scrollHeight + 'px';
  }

  function addChecklistRow(rowsContainer, item, focus) {
    const row = document.createElement('div');
    row.className = 'strategy-checklist-row';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = !!(item && item.checked);
    const text = document.createElement('input');
    text.type = 'text';
    text.value = (item && item.text) || '';
    text.placeholder = 'Proof asset';
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'strategy-checklist-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove';
    removeBtn.addEventListener('click', () => row.remove());
    row.append(checkbox, text, removeBtn);
    rowsContainer.appendChild(row);
    if (focus) text.focus();
  }

  function renumberRows(rowsContainer) {
    Array.from(rowsContainer.querySelectorAll('.strategy-numbered-row')).forEach((row, i) => {
      row.querySelector('.strategy-numbered-badge').textContent = i + 1;
    });
  }

  function addNumberedRow(rowsContainer, text, focus) {
    const row = document.createElement('div');
    row.className = 'strategy-numbered-row';
    const badge = document.createElement('span');
    badge.className = 'strategy-numbered-badge';
    const textInput = document.createElement('input');
    textInput.type = 'text';
    textInput.value = text || '';
    textInput.placeholder = 'Objection';
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'strategy-checklist-remove';
    removeBtn.textContent = '✕';
    removeBtn.title = 'Remove';
    removeBtn.addEventListener('click', () => { row.remove(); renumberRows(rowsContainer); });
    row.append(badge, textInput, removeBtn);
    rowsContainer.appendChild(row);
    renumberRows(rowsContainer);
    if (focus) textInput.focus();
  }

  function buildFieldElement(field) {
    const pathStr = field.path.join('.');
    const wrapper = document.createElement('div');
    wrapper.className = 'field strategy-field';
    if (field.tint) wrapper.classList.add('strategy-card', 'strategy-card-' + field.tint);

    const label = document.createElement('label');
    label.textContent = field.label;
    wrapper.appendChild(label);

    let input;
    if (field.kind === 'text') {
      input = document.createElement('input');
      input.type = 'text';
    } else if (field.kind === 'textarea') {
      input = document.createElement('textarea');
      input.rows = 2;
      input.addEventListener('input', () => autoGrow(input));
    } else if (field.kind === 'lines') {
      input = document.createElement('textarea');
      input.rows = 3;
      input.placeholder = 'One per line';
      input.addEventListener('input', () => autoGrow(input));
    } else if (field.kind === 'select') {
      input = document.createElement('select');
      input.className = 'strategy-badge-select';
      field.options.forEach((opt) => {
        const o = document.createElement('option');
        o.value = opt;
        o.textContent = opt;
        input.appendChild(o);
      });
      input.addEventListener('change', () => { input.dataset.value = input.value; });
    } else if (field.kind === 'checklist') {
      input = document.createElement('div');
      input.className = 'strategy-checklist';
      const rows = document.createElement('div');
      rows.className = 'strategy-checklist-rows';
      input.appendChild(rows);
      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.className = 'btn strategy-checklist-add';
      addBtn.textContent = '+ Add proof asset';
      addBtn.addEventListener('click', () => addChecklistRow(rows, { text: '', checked: false }, true));
      input.appendChild(addBtn);
    } else if (field.kind === 'numbered-list') {
      input = document.createElement('div');
      input.className = 'strategy-numbered-list';
      const rows = document.createElement('div');
      rows.className = 'strategy-numbered-rows';
      input.appendChild(rows);
      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.className = 'btn strategy-checklist-add';
      addBtn.textContent = '+ Add objection';
      addBtn.addEventListener('click', () => addNumberedRow(rows, '', true));
      input.appendChild(addBtn);
    }
    input.dataset.field = pathStr;
    input.dataset.kind = field.kind;
    wrapper.appendChild(input);
    return wrapper;
  }

  function buildStrategyBriefDOM(container) {
    container.innerHTML = '';

    const banner = document.createElement('div');
    banner.className = 'strategy-banner';
    const titleInput = document.createElement('input');
    titleInput.type = 'text';
    titleInput.className = 'strategy-title-input';
    titleInput.placeholder = 'Strategy title';
    titleInput.dataset.field = 'title';
    titleInput.dataset.kind = 'text';
    banner.appendChild(titleInput);

    const badge = document.createElement('div');
    badge.className = 'strategy-business-badge';
    banner.appendChild(badge);

    container.appendChild(banner);

    STRATEGY_SECTIONS.forEach((section) => {
      const sectionEl = document.createElement('div');
      sectionEl.className = 'strategy-section';
      const heading = document.createElement('h4');
      if (section.icon) {
        const iconEl = document.createElement('span');
        iconEl.className = 'strategy-section-icon';
        iconEl.textContent = section.icon;
        heading.appendChild(iconEl);
      }
      heading.appendChild(document.createTextNode(section.heading));
      sectionEl.appendChild(heading);

      const cardsRow = document.createElement('div');
      cardsRow.className = 'strategy-cards-row';
      section.fields.forEach((field) => {
        cardsRow.appendChild(buildFieldElement(field));
      });
      sectionEl.appendChild(cardsRow);
      container.appendChild(sectionEl);
    });
  }

  function refreshBusinessBadge() {
    const badge = $('fs-brief') && $('fs-brief').querySelector('.strategy-business-badge');
    if (!badge) return;
    const id = $('fs-business-select').value;
    const biz = id && App.businessProfile ? App.businessProfile.getById(id) : null;
    badge.textContent = biz ? `For: ${biz.name || 'Untitled Business'}` : 'No business selected';
    badge.classList.toggle('is-unset', !biz);
  }

  function populateStrategyBrief(container, data) {
    refreshBusinessBadge();
    container.querySelectorAll('[data-field]').forEach((el) => {
      const path = el.dataset.field.split('.');
      const kind = el.dataset.kind;
      const value = getPath(data, path);
      if (kind === 'text') {
        el.value = value || '';
      } else if (kind === 'textarea') {
        el.value = value || '';
        autoGrow(el);
      } else if (kind === 'lines') {
        el.value = Array.isArray(value) ? value.join('\n') : '';
        autoGrow(el);
      } else if (kind === 'select') {
        el.value = value || el.options[0].value;
        el.dataset.value = el.value;
      } else if (kind === 'checklist') {
        const rows = el.querySelector('.strategy-checklist-rows');
        rows.innerHTML = '';
        (Array.isArray(value) ? value : []).forEach((item) => addChecklistRow(rows, item, false));
      } else if (kind === 'numbered-list') {
        const rows = el.querySelector('.strategy-numbered-rows');
        rows.innerHTML = '';
        (Array.isArray(value) ? value : []).forEach((text) => addNumberedRow(rows, text, false));
      }
    });
  }

  function readStrategyBriefIntoData(container, data) {
    container.querySelectorAll('[data-field]').forEach((el) => {
      const path = el.dataset.field.split('.');
      const kind = el.dataset.kind;
      if (kind === 'text' || kind === 'textarea' || kind === 'select') {
        setPath(data, path, el.value);
      } else if (kind === 'lines') {
        setPath(data, path, el.value.split('\n').map((s) => s.trim()).filter(Boolean));
      } else if (kind === 'checklist') {
        const items = Array.from(el.querySelectorAll('.strategy-checklist-row')).map((row) => ({
          text: row.querySelector('input[type="text"]').value.trim(),
          checked: row.querySelector('input[type="checkbox"]').checked
        })).filter((item) => item.text);
        setPath(data, path, items);
      } else if (kind === 'numbered-list') {
        const items = Array.from(el.querySelectorAll('.strategy-numbered-row input[type="text"]'))
          .map((inp) => inp.value.trim())
          .filter(Boolean);
        setPath(data, path, items);
      }
    });
  }

  function setStrategyBriefEditable(container, editable) {
    container.classList.toggle('is-readonly', !editable);
    container.querySelectorAll('[data-field]').forEach((el) => {
      const kind = el.dataset.kind;
      if (kind === 'select') {
        el.disabled = !editable;
      } else if (kind === 'checklist' || kind === 'numbered-list') {
        el.querySelectorAll('input[type="checkbox"], input[type="text"]').forEach((inp) => { inp.disabled = !editable; });
        el.querySelectorAll('button').forEach((btn) => { btn.hidden = !editable; });
      } else {
        el.readOnly = !editable;
      }
    });
  }

  function refreshTextareaSizes() {
    const container = $('fs-brief');
    if (!container) return;
    container.querySelectorAll('textarea').forEach((el) => autoGrow(el));
  }

  /* ---------- Candidate review (tab switcher over the same brief DOM) ---------- */
  function renderCandidateTabs() {
    const container = $('fs-candidate-tabs');
    const heading = $('fs-candidate-heading');
    const reasonEl = $('fs-recommended-reason');
    if (!container) return;
    const record = getById(activeId);
    container.innerHTML = '';
    if (!record || !record.candidates.length) {
      container.hidden = true;
      if (heading) heading.hidden = true;
      if (reasonEl) reasonEl.hidden = true;
      return;
    }
    container.hidden = false;
    if (heading) heading.hidden = false;

    record.candidates.forEach((c) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'subtab-btn' + (reviewCandidateKey === c.key ? ' active' : '');
      if (record.recommendedKey && c.key === record.recommendedKey) {
        const badge = document.createElement('span');
        badge.className = 'strategy-recommended-badge';
        badge.textContent = '✨ AI Recommended';
        btn.appendChild(badge);
      }
      btn.appendChild(document.createTextNode(c.title));
      btn.addEventListener('click', () => previewCandidate(c.key));
      container.appendChild(btn);
    });

    const recommended = record.candidates.find((c) => c.key === record.recommendedKey);
    if (reasonEl) {
      if (recommended && record.recommendedReason) {
        reasonEl.textContent = `✨ Recommended: "${recommended.title}" — ${record.recommendedReason}`;
        reasonEl.hidden = false;
      } else {
        reasonEl.hidden = true;
      }
    }
  }

  function previewCandidate(key) {
    const record = getById(activeId);
    if (!record) return;
    reviewCandidateKey = key;
    isEditMode = false;
    rightPanelMode = key === null ? 'record' : 'candidate';
    const briefContainer = $('fs-brief');
    if (key === null) {
      populateStrategyBrief(briefContainer, record);
      setStrategyBriefEditable(briefContainer, false);
      $('fs-use-strategy').hidden = true;
    } else {
      const candidate = record.candidates.find((c) => c.key === key);
      populateStrategyBrief(briefContainer, candidate);
      setStrategyBriefEditable(briefContainer, false);
      $('fs-use-strategy').hidden = false;
    }
    renderCandidateTabs();
    updateActionBar();
  }

  function normalizeCandidate(c) {
    const clone = cloneState(c);
    if (clone.objections && Array.isArray(clone.objections.proofAssets)) {
      clone.objections.proofAssets = clone.objections.proofAssets.map((p) => ({ text: p.text, checked: false }));
    }
    return clone;
  }

  function chooseCandidate(key) {
    const record = getById(activeId);
    if (!record) return;
    const candidate = record.candidates.find((c) => c.key === key);
    if (!candidate) return;
    record.chosenKey = key;
    record.title = candidate.title;
    record.audience = cloneState(candidate.audience);
    record.offer = cloneState(candidate.offer);
    record.objections = cloneState(candidate.objections);
    record.traffic = cloneState(candidate.traffic);
    record.messaging = cloneState(candidate.messaging);
    record.funnelType = cloneState(candidate.funnelType);
    previewCandidate(null);
    saveNow();
  }

  function useReviewedCandidate() {
    if (!reviewCandidateKey) return;
    chooseCandidate(reviewCandidateKey);
  }

  function updateGenerateButtonState() {
    const btn = $('fs-generate');
    if (!btn) return;
    const hasIdea = $('fs-idea').value.trim().length > 0;
    const hasGoal = getGoalValue('fs') !== '';
    const hasBusiness = $('fs-business-select').value !== '';
    btn.disabled = busy || (!hasIdea && !hasGoal) || !hasBusiness;
    btn.textContent = busy ? 'Generating…' : (activeId && getById(activeId) && getById(activeId).candidates.length ? 'Redo Strategy Options' : 'Generate Strategy Options');
  }

  async function postChat(mode, extra) {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(Object.assign({ mode, messages: [] }, extra))
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  async function generateOptions() {
    const record = getById(activeId);
    if (!record || busy) return;
    record.businessId = $('fs-business-select').value || null;
    record.productName = $('fs-product-select').value || '';
    record.goal = getGoalValue('fs');
    record.idea = $('fs-idea').value;
    if ((!record.idea.trim() && !record.goal) || !record.businessId) return;
    busy = true;
    updateGenerateButtonState();
    try {
      const business = App.businessProfile.getById(record.businessId);
      const product = record.productName && business
        ? (business.products || []).find((p) => p.name === record.productName) || null
        : null;
      const data = await postChat('strategy', { idea: record.idea, goal: record.goal, business, product });
      record.candidates = (Array.isArray(data.candidates) ? data.candidates : []).map(normalizeCandidate);
      record.recommendedKey = typeof data.recommendedKey === 'string' ? data.recommendedKey : '';
      record.recommendedReason = typeof data.recommendedReason === 'string' ? data.recommendedReason : '';
      record.chosenKey = '';
      if (record.candidates.length) {
        previewCandidate(record.candidates[0].key);
      } else {
        renderCandidateTabs();
        App.utils.showToast('Strategy Agent did not return usable candidates -- try again.');
      }
      saveNow();
    } catch (e) {
      App.utils.showToast('Strategy error: ' + e.message);
    } finally {
      busy = false;
      updateGenerateButtonState();
    }
  }

  /* ---------- Coordinated Strategy Sets: batch-generate one brief per product, sharing a core ---------- */
  function refreshSetProductCheckboxes() {
    const container = $('fss-product-checkboxes');
    const msg = $('fss-min-products-msg');
    if (!container) return;
    const businessId = $('fss-business-select').value;
    const business = businessId && App.businessProfile ? App.businessProfile.getById(businessId) : null;
    const products = ((business && business.products) || []).filter((p) => p.name);
    container.innerHTML = '';
    products.forEach((p) => {
      const row = document.createElement('div');
      row.className = 'fss-product-row';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = true;
      cb.dataset.productName = p.name;
      cb.addEventListener('change', updateSetGenerateButtonState);
      const label = document.createElement('span');
      label.textContent = p.name + (p.price ? ' — ' + p.price : '');
      row.append(cb, label);
      container.appendChild(row);
    });
    if (msg) msg.hidden = products.length >= 2;
    updateSetGenerateButtonState();
  }

  function getCheckedSetProductNames() {
    const container = $('fss-product-checkboxes');
    if (!container) return [];
    return Array.from(container.querySelectorAll('input[type="checkbox"]:checked')).map((cb) => cb.dataset.productName);
  }

  function updateSetGenerateButtonState() {
    const btn = $('fss-generate');
    if (!btn) return;
    const hasIdea = $('fss-idea').value.trim().length > 0;
    const hasGoal = getGoalValue('fss') !== '';
    const hasBusiness = $('fss-business-select').value !== '';
    const enoughProducts = getCheckedSetProductNames().length >= 2;
    btn.disabled = busySet || (!hasIdea && !hasGoal) || !hasBusiness || !enoughProducts;
    btn.textContent = busySet ? 'Generating…' : 'Generate Strategy Set';
  }

  async function generateSet() {
    if (busySet) return;
    const businessId = $('fss-business-select').value || null;
    const idea = $('fss-idea').value.trim();
    const goal = getGoalValue('fss');
    const business = businessId ? App.businessProfile.getById(businessId) : null;
    const names = getCheckedSetProductNames();
    const products = ((business && business.products) || []).filter((p) => names.includes(p.name));
    if ((!idea && !goal) || !businessId || products.length < 2) return;
    busySet = true;
    updateSetGenerateButtonState();
    try {
      const data = await postChat('strategySet', { idea, goal, business, products });
      const items = (Array.isArray(data.items) ? data.items : [])
        .filter((it) => it && it.brief)
        .map((it) => ({ productName: it.productName, brief: normalizeCandidate(it.brief), selected: true }));
      if (!items.length) {
        App.utils.showToast('Strategy Agent did not return usable set items -- try again.');
        return;
      }
      pendingSet = { setId: 'set-' + Date.now(), businessId, idea, goal, items, activeProductName: items[0].productName };
      previewSetItem(items[0].productName);
    } catch (e) {
      App.utils.showToast('Strategy Set error: ' + e.message);
    } finally {
      busySet = false;
      updateSetGenerateButtonState();
    }
  }

  function previewSetItem(productName) {
    if (!pendingSet) return;
    const item = pendingSet.items.find((i) => i.productName === productName);
    if (!item) return;
    pendingSet.activeProductName = productName;
    rightPanelMode = 'setItem';
    const briefContainer = $('fs-brief');
    populateStrategyBrief(briefContainer, item.brief);
    setStrategyBriefEditable(briefContainer, false);
    renderSetItemTabs();
    updateActionBar();
  }

  function renderSetItemTabs() {
    const container = $('fss-item-tabs');
    const heading = $('fss-item-heading');
    if (!container || !pendingSet) return;
    container.innerHTML = '';
    container.hidden = false;
    if (heading) heading.hidden = false;
    pendingSet.items.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'fss-item-row';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = item.selected;
      checkbox.addEventListener('change', () => { item.selected = checkbox.checked; updateSetCommitButtonState(); });
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'subtab-btn' + (pendingSet.activeProductName === item.productName ? ' active' : '');
      btn.textContent = item.productName + (item.brief.title ? ' — ' + item.brief.title : '');
      btn.addEventListener('click', () => previewSetItem(item.productName));
      row.append(checkbox, btn);
      container.appendChild(row);
    });
    updateSetCommitButtonState();
  }

  function updateSetCommitButtonState() {
    const btn = $('fss-use-set');
    if (!btn || !pendingSet) return;
    const n = pendingSet.items.filter((i) => i.selected).length;
    btn.disabled = n === 0;
    btn.textContent = `Use This Set (${n} of ${pendingSet.items.length} selected)`;
  }

  async function regenerateSetItem() {
    if (!pendingSet || busySet) return;
    const productName = pendingSet.activeProductName;
    const item = pendingSet.items.find((i) => i.productName === productName);
    if (!item) return;
    const business = App.businessProfile.getById(pendingSet.businessId);
    const product = ((business && business.products) || []).find((p) => p.name === productName) || null;
    const setCore = pendingSet.items.filter((i) => i.productName !== productName).map((i) => i.brief);
    busySet = true;
    updateSetGenerateButtonState();
    try {
      const data = await postChat('strategySetItem', { idea: pendingSet.idea, goal: pendingSet.goal, business, product, setCore });
      if (data.brief) {
        item.brief = normalizeCandidate(data.brief);
        renderSetItemTabs();
        if (pendingSet.activeProductName === productName) previewSetItem(productName);
      }
    } catch (e) {
      App.utils.showToast('Regenerate error: ' + e.message);
    } finally {
      busySet = false;
      updateSetGenerateButtonState();
    }
  }

  function commitSet() {
    if (!pendingSet) return;
    const toCommit = pendingSet.items.filter((i) => i.selected);
    if (!toCommit.length) {
      App.utils.showToast('Select at least one item to save.');
      return;
    }
    const setId = pendingSet.setId;
    const businessId = pendingSet.businessId;
    const idea = pendingSet.idea;
    const goal = pendingSet.goal;
    let firstId = null;
    toCommit.forEach((item) => {
      const record = emptyStrategy();
      record.businessId = businessId;
      record.productName = item.productName;
      record.goal = goal;
      record.idea = idea;
      record.strategySetId = setId;
      record.chosenKey = item.brief.key || 'set-item';
      record.title = item.brief.title;
      record.audience = cloneState(item.brief.audience);
      record.offer = cloneState(item.brief.offer);
      record.objections = cloneState(item.brief.objections);
      record.traffic = cloneState(item.brief.traffic);
      record.messaging = cloneState(item.brief.messaging);
      record.funnelType = cloneState(item.brief.funnelType);
      strategies.push(record);
      if (!firstId) firstId = record.id;
    });
    pendingSet = null;
    activeId = firstId;
    loadIntoForm(getById(activeId)); // resets rightPanelMode -> 'record' for free
    renderList();
    if (App.persistence && typeof App.persistence.saveToLocalStorage === 'function') {
      App.persistence.saveToLocalStorage();
    }
    App.utils.showToast(`Saved ${toCommit.length} strateg${toCommit.length === 1 ? 'y' : 'ies'} as a set.`);
    switchPanel('saved');
  }

  /* ---------- Business select sync ---------- */
  function refreshBusinessOptions() {
    const select = $('fs-business-select');
    if (!select) return;
    // Prefer the active record's own businessId over "whatever the DOM currently shows" --
    // if an earlier refresh ran before App.businessProfile's data was restored, setting
    // select.value would have silently failed (no matching <option> yet existed), leaving a
    // stale/blank DOM value that must not be trusted as the source of truth.
    const record = getById(activeId);
    const want = record ? (record.businessId || '') : select.value;
    select.innerHTML = '<option value="">— No business selected —</option>';
    App.businessProfile.list().forEach((b) => {
      const opt = document.createElement('option');
      opt.value = b.id;
      opt.textContent = b.name;
      select.appendChild(opt);
    });
    if (Array.from(select.options).some((o) => o.value === want)) select.value = want;
    refreshProductOptions(record ? record.productName : undefined);
    updateGenerateButtonState();
    refreshTextareaSizes();

    const setSelect = $('fss-business-select');
    if (setSelect) {
      const setWant = setSelect.value;
      setSelect.innerHTML = '<option value="">— No business selected —</option>';
      App.businessProfile.list().forEach((b) => {
        const opt = document.createElement('option');
        opt.value = b.id;
        opt.textContent = b.name;
        setSelect.appendChild(opt);
      });
      if (Array.from(setSelect.options).some((o) => o.value === setWant)) setSelect.value = setWant;
      refreshSetProductCheckboxes();
    }
  }

  function syncBusinessSelection() {
    refreshBusinessOptions();
    renderList();
  }

  /* ---------- Persistence ---------- */
  function getState() {
    readFormIntoActive();
    return { strategies: cloneState(strategies), activeId };
  }

  function setState(data) {
    if (!data || !Array.isArray(data.strategies) || !data.strategies.length) return;
    strategies = cloneState(data.strategies);
    nextId = strategies.reduce((max, s) => {
      const num = parseInt(String(s.id).replace('strat-', ''), 10);
      return isNaN(num) ? max : Math.max(max, num + 1);
    }, 1);
    activeId = data.activeId && getById(data.activeId) ? data.activeId : strategies[0].id;
    loadIntoForm(getById(activeId));
    renderList();
  }

  function list() {
    return strategies.map((s) => ({ id: s.id, name: summaryFor(s) }));
  }

  function listByBusiness(businessId) {
    return strategies
      .filter((s) => s.businessId === businessId && s.chosenKey && s.title.trim())
      .map((s) => ({ id: s.id, title: s.title, offer: cloneState(s.offer) }));
  }

  function switchPanel(which) {
    $('fs-panel-saved').hidden = which !== 'saved';
    $('fs-panel-create').hidden = which !== 'create';
    $('fs-panel-create-set').hidden = which !== 'create-set';
    $('fs-panel-tab-saved').classList.toggle('active', which === 'saved');
    $('fs-panel-tab-create').classList.toggle('active', which === 'create');
    $('fs-panel-tab-create-set').classList.toggle('active', which === 'create-set');
  }

  function init() {
    if (strategies.length === 0) newStrategy();

    $('fs-panel-tab-saved').addEventListener('click', () => switchPanel('saved'));
    $('fs-panel-tab-create').addEventListener('click', () => switchPanel('create'));
    $('fs-panel-tab-create-set').addEventListener('click', () => switchPanel('create-set'));
    $('fs-new-strategy').addEventListener('click', newStrategy);
    $('fs-search').addEventListener('input', () => {
      searchQuery = $('fs-search').value;
      renderList();
    });
    $('fs-generate').addEventListener('click', generateOptions);
    $('fs-use-strategy').addEventListener('click', useReviewedCandidate);
    $('fs-edit-brief').addEventListener('click', enterEditMode);
    $('fs-save-brief').addEventListener('click', saveBriefAndExit);
    $('fs-idea').addEventListener('input', updateGenerateButtonState);
    $('fs-goal-select').addEventListener('change', () => { updateGoalOtherVisibility('fs'); updateGenerateButtonState(); });
    $('fss-goal-select').addEventListener('change', () => { updateGoalOtherVisibility('fss'); updateSetGenerateButtonState(); });
    $('fs-goal').addEventListener('input', updateGenerateButtonState);
    $('fss-goal').addEventListener('input', updateSetGenerateButtonState);
    $('fs-business-select').addEventListener('change', () => {
      const record = getById(activeId);
      const id = $('fs-business-select').value || null;
      if (record) record.businessId = id;
      if (record) record.productName = '';
      refreshProductOptions('');
      if (id) App.businessProfile.selectBusiness(id);
      updateGenerateButtonState();
      refreshBusinessBadge();
    });
    $('fss-business-select').addEventListener('change', () => {
      refreshSetProductCheckboxes();
    });
    $('fss-idea').addEventListener('input', updateSetGenerateButtonState);
    $('fss-generate').addEventListener('click', generateSet);
    $('fss-regenerate-item').addEventListener('click', regenerateSetItem);
    $('fss-use-set').addEventListener('click', commitSet);

    buildStrategyBriefDOM($('fs-brief'));

    refreshBusinessOptions();
    loadIntoForm(getById(activeId));
    renderList();

    const panel = document.getElementById('tab-strategy');
    const debouncedUpdate = App.utils.debounce(() => {
      readFormIntoActive();
      showSaved();
      renderList();
    }, 400);
    panel.addEventListener('input', debouncedUpdate);
    panel.addEventListener('change', debouncedUpdate);
    panel.addEventListener('click', (e) => {
      if (e.target.closest('button') && !e.target.closest('.funnel-row') && !e.target.closest('.subtab-btn')) debouncedUpdate();
    });
  }

  App.strategy = {
    init,
    getState,
    setState,
    list,
    listByBusiness,
    getById,
    selectStrategy,
    newStrategy,
    duplicateStrategy,
    deleteStrategy,
    generateOptions,
    chooseCandidate,
    refreshBusinessOptions,
    syncBusinessSelection
  };
})(window.App);
