/* Shared app shell: tabs, theming, copy/download, small utilities. */
window.App = {
  generators: {}, // each generator module registers { getHTML(), getCSS(), filename, init() }
  utils: {}
};

(function (App) {
  'use strict';

  function debounce(fn, wait) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function hexToRgba(hex, alpha) {
    const h = hex.replace('#', '');
    const bigint = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast._t);
    const duration = Math.min(8000, Math.max(1600, String(message).length * 60));
    showToast._t = setTimeout(() => toast.classList.remove('show'), duration);
  }

  function copyText(text, label) {
    const finish = () => showToast((label || 'Code') + ' copied to clipboard');
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(finish).catch(() => fallbackCopy(text, finish));
    } else {
      fallbackCopy(text, finish);
    }
  }

  function fallbackCopy(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* noop */ }
    document.body.removeChild(ta);
    if (done) done();
  }

  function downloadFile(filename, content, mime) {
    const blob = new Blob([content], { type: mime || 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Downloaded ' + filename);
  }

  /* ---------- SEO / share metadata ---------- */

  // Search snippets get cut around here, and so do most link-preview cards.
  const META_DESCRIPTION_MAX = 155;

  function truncateForMeta(text) {
    const clean = String(text || '').replace(/\s+/g, ' ').trim();
    if (clean.length <= META_DESCRIPTION_MAX) return clean;
    // Cut on a word boundary so the snippet never ends mid-word.
    const cut = clean.slice(0, META_DESCRIPTION_MAX);
    const lastSpace = cut.lastIndexOf(' ');
    return (lastSpace > 40 ? cut.slice(0, lastSpace) : cut).replace(/[,;:.\s]+$/, '') + '…';
  }

  // Accepts what people actually type into a URL field -- "riveraplumbing.co", a trailing space, a
  // full https:// address -- and returns a usable absolute URL, or '' if it can't be made into one.
  // Everything downstream treats '' as "no site URL configured" and degrades accordingly.
  function normalizeSiteUrl(text) {
    const raw = String(text || '').trim();
    if (!raw) return '';
    const withProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : 'https://' + raw;
    try {
      const url = new URL(withProtocol);
      // A bare "https://" or a hostname with no dot is a typo, not a site. Anything outside
      // http/https is meaningless as a page address, so a mistyped scheme is rejected rather than
      // passed through into og:url where it would just break the link preview.
      if (!url.hostname || url.hostname.indexOf('.') === -1) return '';
      if (url.protocol !== 'http:' && url.protocol !== 'https:') return '';
      return url.href;
    } catch (e) {
      return '';
    }
  }

  // Link-preview scrapers need an absolute og:image; /uploads/... only resolves for them by luck.
  // With no site URL configured the relative path is passed through unchanged, which is what the
  // export did before this field existed.
  function absolutizeUrl(url, base) {
    const value = String(url || '').trim();
    if (!value || !base) return value;
    try {
      return new URL(value, base).href;
    } catch (e) {
      return value;
    }
  }

  // The share image is the first photo the designer actually uploaded, i.e. one served from
  // /uploads/. Placeholder image slots still carry their grey SVG data: URI, which no link-preview
  // scraper can fetch, so a page with nothing uploaded yet is better off with no og:image at all
  // than with a tag pointing at something unfetchable.
  function firstUploadedImageSrc(bodyHtml) {
    const re = /<img\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi;
    let m;
    while ((m = re.exec(bodyHtml)) !== null) {
      if (m[1].indexOf('/uploads/') === 0) return m[1];
    }
    return '';
  }

  // Returns the <meta> block for search results and link previews (Messenger, Viber, Facebook,
  // WhatsApp, X, Slack). Every value is optional -- a tag whose content would be empty is omitted
  // rather than shipped blank, since an empty og:title is worse than none.
  function buildSeoMeta(opts) {
    const o = opts || {};
    const title = String(o.title || '').trim();
    const description = truncateForMeta(o.description);
    const siteName = String(o.siteName || '').trim();
    const image = String(o.image || '').trim();
    const url = String(o.url || '').trim();

    const tag = (attr, key, value) =>
      value ? `<meta ${attr}="${escapeHtml(key)}" content="${escapeHtml(value)}">` : '';

    return [
      tag('name', 'description', description),
      tag('property', 'og:type', 'website'),
      tag('property', 'og:title', title),
      tag('property', 'og:description', description),
      tag('property', 'og:site_name', siteName),
      // Consolidates shares of the same page across tracking-parameter variants (?utm_source=...),
      // which for an ad-driven funnel is most of its inbound links. Omitted when there's no site URL:
      // a scraper with no og:url falls back to the address it fetched, which is always right, so a
      // guessed one would only make things worse.
      tag('property', 'og:url', url),
      tag('property', 'og:image', image),
      // summary_large_image renders a full-width card, but only when there's actually an image to
      // fill it -- otherwise it degrades to an awkward empty box, so fall back to the compact card.
      tag('name', 'twitter:card', image ? 'summary_large_image' : 'summary'),
      tag('name', 'twitter:title', title),
      tag('name', 'twitter:description', description),
      tag('name', 'twitter:image', image)
    ].filter(Boolean).join('\n');
  }

  // Assembles the full <head> extras for an export: share metadata, then the schema.org graph, then
  // font links. metaFromBusiness() carries the business record through on `business` so the JSON-LD
  // can be built from the same source as the meta tags and reuse the share image it already resolved.
  function buildPageHead(meta, fontLinks) {
    const o = meta || {};
    const jsonLd = (o.business && App.structuredData)
      ? App.structuredData.buildJsonLdScript(o.business, { image: o.image, url: o.url })
      : '';
    return [buildSeoMeta(o), jsonLd, fontLinks].filter(Boolean).join('\n');
  }

  // "Rivera Plumbing — Fast, reliable, fair." reads well as a tab label, a bookmark, and a search
  // result headline all at once. Falls back to the bare name, then to whatever the caller passes.
  function pageTitleFor(business, fallback) {
    const b = business || {};
    const name = String(b.name || '').trim();
    const tagline = String(b.tagline || '').trim();
    if (name && tagline) return `${name} — ${tagline}`;
    return name || fallback || 'Page';
  }

  // The elevator pitch is written to describe the business in a sentence or two, which is exactly
  // what a meta description wants; the tagline is the next best thing when it's blank.
  function metaFromBusiness(business, title, bodyHtml) {
    const b = business || {};
    const siteUrl = normalizeSiteUrl(b.siteUrl);
    return {
      title: title,
      description: b.description || b.tagline || '',
      siteName: String(b.name || '').trim(),
      // Absolutised here rather than at each call site so the meta tags and the JSON-LD graph, which
      // both read this one value, can never disagree about where the share image lives.
      image: absolutizeUrl(firstUploadedImageSrc(bodyHtml), siteUrl),
      url: siteUrl,
      business: business || null
    };
  }

  // Filenames for downloaded exports -- every AI Funnel download used to land as the same
  // "ai-funnel-page.html", so they collided in the Downloads folder and had to be renamed by hand.
  function slugify(text, fallback) {
    const slug = String(text || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    return slug || fallback || 'page';
  }

  function buildFullHtmlDoc(title, bodyHtml, css, extraHead) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)}</title>${extraHead ? '\n' + extraHead : ''}
<style>
${css}
</style>
</head>
<body>
${bodyHtml}
<script>
if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.querySelectorAll('video[data-bg-video]').forEach(function (v) {
    v.removeAttribute('autoplay');
    v.pause();
  });
}
</script>
</body>
</html>
`;
  }

  function scopeCss(css, scopeClass) {
    return css.split('\n').map((line) => {
      const trimmed = line.trim();
      if (!trimmed.endsWith('{') || trimmed.startsWith('@')) return line;
      const indent = line.slice(0, line.length - line.trimStart().length);
      const selectorPart = trimmed.slice(0, -1).trim();
      const scoped = selectorPart.split(',').map((sel) => `.${scopeClass} ${sel.trim()}`).join(', ');
      return `${indent}${scoped} {`;
    }).join('\n');
  }

  /* Spend on a bring-your-own-key product is read at two very different scales: a single
     generation lands in fractions of a cent, a month of them lands in dollars. Rounding
     everything to 2dp would print "$0.00" for real money that was actually spent, so small
     amounts keep enough precision to stay truthful. */
  function formatCost(value) {
    if (typeof value !== 'number' || !isFinite(value)) return '--';
    if (value === 0) return '$0.00';
    if (value < 0.01) return '$' + value.toFixed(4);
    return '$' + value.toFixed(2);
  }

  function formatTokens(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '--';
    return n.toLocaleString();
  }

  App.utils = {
    debounce, escapeHtml, hexToRgba, showToast, copyText, downloadFile, buildFullHtmlDoc, scopeCss,
    buildSeoMeta, buildPageHead, pageTitleFor, metaFromBusiness, firstUploadedImageSrc, slugify,
    normalizeSiteUrl, absolutizeUrl, formatCost, formatTokens
  };

  /* ---------- Tabs ---------- */
  /* Tabs with no code panel behind them. Only the View Code button is withheld here -- Export and
     Import stay on every tab, because Business Info is exactly where someone restoring a project on
     a new machine goes looking for Import, and hiding the whole bar there sent them to support. */
  const NO_CODE_PANEL_TABS = ['business', 'strategy', 'account'];

  function positionCodeActions(target) {
    const actions = document.getElementById('headerCodeActions');
    if (!actions) return;
    actions.hidden = false;
    const codeToggle = document.getElementById('codeToggle');
    if (codeToggle) codeToggle.hidden = NO_CODE_PANEL_TABS.includes(target);
    const headerActions = document.querySelector('.header-actions');
    if (headerActions) headerActions.appendChild(actions);
  }

  function initTabs() {
    const buttons = document.querySelectorAll('.tab-btn');
    positionCodeActions('business');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        buttons.forEach(b => b.classList.toggle('active', b === btn));
        document.querySelectorAll('.tab-panel').forEach(p => {
          p.classList.toggle('active', p.dataset.tabPanel === target);
        });
        positionCodeActions(target);
        document.querySelectorAll('.code-panel').forEach(p => {
          p.classList.toggle('active', p.dataset.tabPanel === target);
        });
        if (target === 'strategy' && App.strategy) {
          App.strategy.refreshBusinessOptions();
        }
        if (target === 'aifunnel' && App.aiFunnel) {
          App.aiFunnel.refreshBusinessOptions();
          // The strategist opens the conversation on its own, but only once this tab is on screen.
          if (App.aiFunnel.maybeAutoStartInterview) App.aiFunnel.maybeAutoStartInterview();
        }
        if (target === 'account' && App.account) {
          App.account.refresh();
        }
      });
    });
  }

  /* ---------- Code drawer ---------- */
  function initCodeDrawer() {
    const drawer = document.getElementById('codeDrawer');
    const backdrop = document.getElementById('drawerBackdrop');
    const openBtn = document.getElementById('codeToggle');
    const closeBtn = document.getElementById('codeDrawerClose');

    function open() {
      drawer.classList.add('open');
      backdrop.classList.add('open');
      drawer.setAttribute('aria-hidden', 'false');
    }

    function close() {
      drawer.classList.remove('open');
      backdrop.classList.remove('open');
      drawer.setAttribute('aria-hidden', 'true');
    }

    openBtn.addEventListener('click', open);
    closeBtn.addEventListener('click', close);
    backdrop.addEventListener('click', close);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });
  }

  /* ---------- Copy / Download delegation ---------- */
  function initToolbar() {
    document.addEventListener('click', (e) => {
      const copyBtn = e.target.closest('[data-copy]');
      if (copyBtn) {
        const el = document.getElementById(copyBtn.dataset.copy);
        if (el) copyText(el.textContent, copyBtn.textContent.trim());
        return;
      }
      const dlBtn = e.target.closest('[data-download]');
      if (dlBtn) {
        const key = dlBtn.dataset.download;
        const gen = App.generators[key];
        if (gen && typeof gen.download === 'function') gen.download();
      }
    });
  }

  /* Preview width switching.

     The iframe's own width IS the viewport its content sees, so narrowing the element is enough to
     make the generated page's media queries fire for real -- no user-agent spoofing, no separate
     render path, and what you see is genuinely what a phone would get. Desktop is width:auto rather
     than a fixed number so it keeps filling whatever space the pane has.

     Frames are switched by element id so the same control works for the AI Funnel preview and the
     Page Editor canvas without either knowing about the other. */
  /* A 768px frame does not fit in a ~540px editor pane, and clipping it would hide the right
     quarter of the page with no scrollbar and no clue it was missing. Scaling solves that without
     lying: the iframe is still genuinely `width` pixels wide, so the page's media queries fire for
     the real breakpoint, and only the visual presentation is shrunk to fit -- the same trick device
     previews in design tools use. Height is divided back out so the scaled frame still fills the
     pane vertically instead of leaving dead space under it. */
  function applyViewport(frame, width) {
    const wrap = frame.closest('.preview-frame-wrap');
    if (!width || !wrap) {
      frame.style.width = '';
      frame.style.height = '';
      frame.style.transform = '';
      frame.style.transformOrigin = '';
      frame.style.marginLeft = '';
      frame.dataset.viewportWidth = '';
      return;
    }
    const available = wrap.clientWidth;
    const scale = Math.min(1, available / width);
    frame.dataset.viewportWidth = String(width);
    frame.style.width = width + 'px';
    frame.style.height = (100 / scale) + '%';
    frame.style.transformOrigin = 'top left';
    frame.style.transform = scale < 1 ? 'scale(' + scale + ')' : '';
    frame.style.marginLeft = Math.max(0, (available - width * scale) / 2) + 'px';
  }

  function initViewportControls() {
    // The pane width changes with the window, so a frame scaled to fit must be recomputed.
    window.addEventListener('resize', App.utils.debounce(() => {
      document.querySelectorAll('.preview-frame').forEach((frame) => {
        const w = Number(frame.dataset.viewportWidth);
        if (w) applyViewport(frame, w);
      });
    }, 150));

    document.querySelectorAll('.viewport-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const frameId = btn.dataset.viewportFor;
        const width = Number(btn.dataset.width);
        const frame = document.getElementById(frameId);
        if (!frame) return;

        document.querySelectorAll('.viewport-btn[data-viewport-for="' + frameId + '"]').forEach((b) => {
          b.classList.toggle('is-active', b === btn);
        });

        applyViewport(frame, width);
        const label = document.getElementById(frameId + '-viewport-size');
        if (label) label.textContent = width ? width + 'px wide' : 'full width';
      });
    });
  }

  App.initShell = function () {
    initViewportControls();
    initTabs();
    initToolbar();
    initCodeDrawer();
  };
})(window.App);
