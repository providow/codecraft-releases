/* Page Editor tab: a saved library of AI Funnel results. Each "Save and Edit" click in AI Funnel creates a
   new, independent page here (never overwrites an earlier one) -- mirrors the businessProfile.js/
   strategy.js saved-record pattern. The editor view lets you pick a section and (Phase 2) ask the AI to
   revise just that section; Phase 1 ships the data model, the saved-pages grid, and the editor shell
   (canvas + selectable section list) with the chat wiring still to come. */
(function (App) {
  'use strict';
  const $ = (id) => document.getElementById(id);

  let pages = [];
  let nextId = 1;
  let editingId = null;
  let selectedSectionIndex = -1;
  let chatBusy = false;
  let undoStack = [];
  let redoStack = [];
  let imageUploadBusy = false;
  const IMAGE_ACCEPTED_MIME = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
  const IMAGE_MAX_BYTES = 8 * 1024 * 1024;

  async function postChat(mode, extra) {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(Object.assign({ mode, messages: [] }, extra))
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  async function postJson(url, body) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  function cloneState(s) {
    return JSON.parse(JSON.stringify(s));
  }

  function emptyPage() {
    const now = Date.now();
    return {
      id: 'page-' + (nextId++),
      businessId: null,
      title: '',
      status: 'draft',
      sections: [],
      fonts: [],
      externalFontLinks: [],
      createdAt: now,
      updatedAt: now
    };
  }

  function getById(id) {
    return pages.find((p) => p.id === id) || null;
  }

  function uniqueTitleFor(businessId) {
    const business = App.businessProfile.getById(businessId);
    const base = (business && business.name) || 'Untitled Business';
    const existingTitles = pages.filter((p) => p.businessId === businessId).map((p) => p.title);
    if (!existingTitles.includes(base)) return base;
    let n = 2;
    while (existingTitles.includes(`${base} (${n})`)) n++;
    return `${base} (${n})`;
  }

  // Called by js/aiFunnel.js's "Save and Edit" button and by js/importHtml.js -- never overwrites an
  // existing page, always creates a new one, so re-generating/re-importing never loses an earlier
  // saved result. externalFontLinks carries raw font-service <link> hrefs (e.g. from an imported
  // page's own Google Fonts link) that fall outside this app's own curated font list.
  function createFromSections(businessId, sections, fonts, externalFontLinks) {
    const page = emptyPage();
    page.businessId = businessId;
    page.title = uniqueTitleFor(businessId);
    page.sections = cloneState(sections || []);
    page.fonts = cloneState(fonts || []);
    page.externalFontLinks = cloneState(externalFontLinks || []);
    pages.unshift(page);
    save();
    renderGrid();
    return page;
  }

  function escapeAttr(str) {
    return String(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
  }

  // The real, exportable page -- no editor-only chrome. Shared by Copy/Download and the code drawer,
  // and reused as the base for the editor's own srcdoc build below.
  function pageContentParts(page) {
    const sectionHtml = page.sections.map((s) => s.html).filter(Boolean);
    const cssParts = page.sections.map((s) => s.css).filter(Boolean);
    const html = `<div class="page-content">\n${sectionHtml.join('\n')}\n</div>`;
    const css = ['html, body { margin: 0; }', '.page-content { position: relative; }', ...cssParts]
      .filter(Boolean)
      .join('\n\n');
    return { html, css };
  }

  function fontHeadLinksFor(page) {
    const curated = Array.from(new Set((page.fonts || []).map((f) => App.getGoogleFontLink(f)).filter(Boolean)));
    const external = (page.externalFontLinks || []).map((href) => `<link rel="stylesheet" href="${escapeAttr(href)}">`);
    return curated.concat(external).join('\n');
  }

  function buildCleanPageDoc(page) {
    const { html, css } = pageContentParts(page);
    const business = App.businessProfile.getById(page.businessId);
    // The page's own title wins here -- it's user-editable in the editor header and already defaults
    // to the business name -- with the business only filling in the tagline half when it's untouched.
    const title = page.title || App.utils.pageTitleFor(business, 'Page Preview');
    const extraHead = App.utils.buildPageHead(
      App.utils.metaFromBusiness(business, title, html),
      fontHeadLinksFor(page)
    );
    return App.utils.buildFullHtmlDoc(title, html, css, extraHead);
  }

  // Each section is wrapped in a thin, click-selectable shell so the canvas itself is the primary
  // way to pick which section to describe changes for -- no detour through the Navigator tab needed.
  // The wrapper adds no visual chrome of its own beyond a hover/selected outline + a small type
  // label, and never changes the section's own CSS scoping (selectors still target the section's
  // real root class one level down, unaffected by the extra wrapper). This editor-only chrome never
  // leaks into the exported/downloaded HTML, which is built from pageContentParts() instead.
  // A zero-height insertion point sits between every pair of sections, plus one above the first and
  // below the last. The strip takes no vertical space and stays invisible until hovered, so it adds
  // no chrome to the canvas; its index is the position a new section would occupy in page.sections.
  function insertStripHtml(index) {
    return '<div class="pages-editor-insert"><div class="pages-editor-insert-hit">'
      + '<span class="pages-editor-insert-line"></span>'
      + `<button type="button" class="pages-editor-insert-btn" data-insert-index="${index}"`
      + ' title="Add a section here" aria-label="Add a section here">+</button></div></div>';
  }

  function buildEditorPageDoc(page) {
    const parts = [];
    page.sections.forEach((s, i) => {
      parts.push(insertStripHtml(i));
      parts.push(`<div class="pages-editor-section" data-section-index="${i}" data-section-type="${escapeAttr(s.type)}">${markEditableText(s.html)}</div>`);
    });
    parts.push(insertStripHtml(page.sections.length));
    const cssParts = page.sections.map((s) => s.css).filter(Boolean);
    const html = `<div class="page-content">\n${parts.join('\n')}\n</div>`;
    const editorChromeCss = `
.pages-editor-section { position: relative; cursor: pointer; outline: 2px solid transparent; outline-offset: -2px; transition: outline-color .12s ease; }
.pages-editor-section:hover { outline-color: rgba(91,124,153,0.5); }
.pages-editor-section-selected { outline-color: #5b7c99; }
.pages-editor-section::before { content: attr(data-section-type); position: absolute; top: 0; left: 0; background: #5b7c99; color: #fff; font: 600 11px/1.6 system-ui, -apple-system, sans-serif; padding: 2px 8px; border-radius: 0 0 6px 0; text-transform: uppercase; letter-spacing: .03em; opacity: 0; pointer-events: none; transition: opacity .1s ease; z-index: 9999; }
.pages-editor-section:hover::before, .pages-editor-section-selected::before { opacity: 1; }
.pages-editor-section img[data-ai-image-slot] { cursor: pointer; outline: 2px dashed transparent; outline-offset: 2px; transition: outline-color .12s ease, filter .12s ease; }
.pages-editor-section img[data-ai-image-slot]:hover { outline-color: #5b7c99; filter: brightness(0.9); }
.pages-editor-section [data-ai-video-slot] { cursor: pointer; outline: 2px dashed transparent; outline-offset: 2px; transition: outline-color .12s ease, filter .12s ease; }
.pages-editor-section [data-ai-video-slot]:hover { outline-color: #5b7c99; filter: brightness(0.94); }
.pages-editor-section [data-ai-video-bg-slot] { cursor: pointer; outline: 2px dashed transparent; outline-offset: -2px; transition: outline-color .12s ease, filter .12s ease; }
.pages-editor-section [data-ai-video-bg-slot]:hover { outline-color: #5b7c99; filter: brightness(1.15); }
.pages-editor-section [data-cc-edit]:hover { outline: 1px dashed rgba(91,124,153,0.75); outline-offset: 2px; }
.pages-editor-section [data-cc-edit][contenteditable="true"] { outline: 2px solid #5b7c99; outline-offset: 2px; background: rgba(91,124,153,0.06); cursor: text; }
.pages-editor-section [data-cc-edit][contenteditable="true"]:hover { outline: 2px solid #5b7c99; }
.pages-editor-insert { position: relative; height: 0; }
.pages-editor-insert-hit { position: absolute; left: 0; right: 0; top: -10px; height: 20px; display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity .12s ease; z-index: 9998; }
.pages-editor-insert-hit:hover { opacity: 1; }
.pages-editor-insert-line { position: absolute; left: 0; right: 0; top: 50%; height: 2px; margin-top: -1px; background: #5b7c99; }
.pages-editor-insert-btn { position: relative; width: 24px; height: 24px; padding: 0; border: none; border-radius: 50%; background: #5b7c99; color: #fff; font: 400 17px/1 system-ui, -apple-system, sans-serif; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 1px 4px rgba(0,0,0,0.25); }
.pages-editor-insert-btn:hover { background: #46617a; }`;
    const css = [editorChromeCss, 'html, body { margin: 0; }', '.page-content { position: relative; }', ...cssParts]
      .filter(Boolean)
      .join('\n\n');
    return App.utils.buildFullHtmlDoc(page.title || 'Page Preview', html, css, fontHeadLinksFor(page));
  }

  function updateCodePanel(page) {
    const htmlEl = $('pages-html-code');
    const cssEl = $('pages-css-code');
    const jsonEl = $('pages-json-code');
    if (!htmlEl || !cssEl || !jsonEl) return;
    if (!page) {
      htmlEl.textContent = '';
      cssEl.textContent = '';
      jsonEl.textContent = '';
      return;
    }
    const { html, css } = pageContentParts(page);
    htmlEl.textContent = html;
    cssEl.textContent = css;
    jsonEl.textContent = JSON.stringify(page.sections, null, 2);
  }

  /* Two different things get called "the HTML", and pasting the wrong one into a page builder is
     the most likely way a finished page arrives looking broken.

     Download gives a complete standalone document -- doctype, <html>, <head>, the lot -- which is
     right for hosting the file directly. Paste that into a Custom HTML block in GoHighLevel,
     Webflow or WordPress and the builder injects it into an existing document, where the parser
     discards the wrapper tags and the <head> takes the <style> and font <link>s with it. The
     content survives with no styling at all.

     This produces the other shape: font links, a <style>, and the content div, with nothing that
     assumes it owns the document. Note the html/body reset is deliberately dropped -- in an embed
     that rule would reach out and restyle the host builder's own page. */
  function embedCodeFor(page) {
    const sectionHtml = page.sections.map((s) => s.html).filter(Boolean);
    const cssParts = page.sections.map((s) => s.css).filter(Boolean);
    const fontLinks = fontHeadLinksFor(page);
    return [
      fontLinks,
      '<style>',
      ['.page-content { position: relative; }'].concat(cssParts).join('\n\n'),
      '</style>',
      '<div class="page-content">',
      sectionHtml.join('\n'),
      '</div>'
    ].filter(Boolean).join('\n');
  }

  /* An uploaded photo is written into its section as /uploads/<business>/<id>.jpg -- a path that
     only resolves while this app's own server is running. Every export ends up somewhere else: a
     host, or a page builder's Custom HTML block. There that path 404s and the page silently loses
     every real photo, having looked perfect in the editor a moment earlier.

     So exports inline them. Each distinct uploaded image is fetched once and embedded as a data
     URI -- the same shape the generator already uses for its grey placeholder SVGs -- which keeps
     a downloaded file or a pasted embed genuinely self-contained. Anything that fails to fetch is
     left as its original path and reported, rather than quietly dropped. */
  async function inlineUploadedImages(html) {
    const pattern = /src=(["'])([/]uploads[^"']+)["']/g;
    const urls = Array.from(new Set(Array.from(html.matchAll(pattern), (m) => m[2])));
    if (!urls.length) return { html: html, failed: [] };

    const dataUris = new Map();
    const failed = [];
    await Promise.all(urls.map(async (url) => {
      try {
        const res = await fetch(url);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const blob = await res.blob();
        dataUris.set(url, await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(blob);
        }));
      } catch (err) {
        failed.push(url);
      }
    }));

    const out = html.replace(pattern, (whole, quote, url) =>
      dataUris.has(url) ? 'src=' + quote + dataUris.get(url) + quote : whole);
    return { html: out, failed: failed };
  }

  // copyText fires its own success toast asynchronously, so a warning has to land after it to be
  // the message the user is left looking at.
  function warnAboutFailures(failed, what, delay) {
    if (!failed.length) return;
    const say = () => App.utils.showToast(
      failed.length + ' photo' + (failed.length === 1 ? '' : 's') + ' could not be embedded, so ' +
      what + ' still points at /uploads and those images will not load once published.'
    );
    if (delay) setTimeout(say, 60); else say();
  }

  async function copyEmbedCode() {
    const page = getById(editingId);
    if (!page) return;
    const result = await inlineUploadedImages(embedCodeFor(page));
    App.utils.copyText(result.html, 'Embed code');
    warnAboutFailures(result.failed, 'the embed code', true);
  }

  async function downloadPageHtml() {
    const page = getById(editingId);
    if (!page) return;
    const result = await inlineUploadedImages(buildCleanPageDoc(page));
    App.utils.downloadFile((page.title || 'page') + '.html', result.html, 'text/html');
    warnAboutFailures(result.failed, 'the downloaded file', false);
  }

  function downloadPageJson() {
    const page = getById(editingId);
    if (!page) return;
    App.utils.downloadFile((page.title || 'page') + '-sections.json', JSON.stringify(page.sections, null, 2), 'application/json');
  }

  function renderGrid() {
    const grid = $('pages-grid');
    const emptyMsg = $('pages-empty-msg');
    if (!grid) return;
    grid.innerHTML = '';
    if (emptyMsg) emptyMsg.hidden = pages.length > 0;

    pages.forEach((page) => {
      const business = App.businessProfile.getById(page.businessId);
      const card = document.createElement('div');
      card.className = 'page-card';

      const title = document.createElement('div');
      title.className = 'page-card-title';
      title.textContent = page.title || 'Untitled Page';
      card.appendChild(title);

      const meta = document.createElement('div');
      meta.className = 'page-card-meta';
      const badge = document.createElement('span');
      badge.className = 'page-card-badge';
      badge.textContent = page.status;
      meta.appendChild(badge);
      const info = document.createElement('span');
      const sectionWord = page.sections.length === 1 ? 'section' : 'sections';
      info.textContent = `${business ? business.name + ' · ' : ''}${page.sections.length} ${sectionWord} · ${new Date(page.updatedAt).toLocaleDateString()}`;
      meta.appendChild(info);
      card.appendChild(meta);

      const actions = document.createElement('div');
      actions.className = 'page-card-actions';

      const editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.className = 'btn btn-primary';
      editBtn.textContent = 'Edit';
      editBtn.addEventListener('click', () => openEditor(page.id));
      actions.appendChild(editBtn);

      const dupBtn = document.createElement('button');
      dupBtn.type = 'button';
      dupBtn.className = 'btn';
      dupBtn.textContent = 'Duplicate';
      dupBtn.addEventListener('click', () => duplicatePage(page.id));
      actions.appendChild(dupBtn);

      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'btn';
      delBtn.textContent = 'Delete';
      delBtn.addEventListener('click', () => deletePage(page.id));
      actions.appendChild(delBtn);

      card.appendChild(actions);
      grid.appendChild(card);
    });
  }

  function duplicatePage(id) {
    const idx = pages.findIndex((p) => p.id === id);
    if (idx === -1) return;
    const clone = cloneState(pages[idx]);
    clone.id = 'page-' + (nextId++);
    clone.title = (clone.title || 'Untitled Page') + ' (Copy)';
    clone.createdAt = Date.now();
    clone.updatedAt = Date.now();
    pages.splice(idx + 1, 0, clone);
    save();
    renderGrid();
  }

  function deletePage(id) {
    const idx = pages.findIndex((p) => p.id === id);
    if (idx === -1) return;
    pages.splice(idx, 1);
    if (id === editingId) closeEditor();
    save();
    renderGrid();
  }

  // Strips tags for a short plain-text preview of a section's content -- good enough for a Navigator
  // row label, doesn't need to be a real HTML sanitizer since it's never re-inserted as markup.
  function previewTextFor(section) {
    const tmp = document.createElement('div');
    tmp.innerHTML = section.html || '';
    const text = (tmp.textContent || '').replace(/\s+/g, ' ').trim();
    return text.length > 60 ? text.slice(0, 60) + '…' : text || '(empty)';
  }

  function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result || '';
        const comma = result.indexOf(',');
        resolve(comma === -1 ? '' : result.slice(comma + 1));
      };
      reader.onerror = () => reject(new Error('Could not read file'));
      reader.readAsDataURL(file);
    });
  }

  // Replaces the src="..." of the Nth <img data-ai-image-slot="true"> occurrence in a section's html
  // (0-based, in document order) -- occurrenceIndex is computed client-side by counting DOM matches
  // within that section's own wrapper, which lines up with this regex's left-to-right match order for
  // any well-formed HTML the AI could have produced.
  function replaceNthImageSlotSrc(html, occurrenceIndex, newUrl) {
    // The attribute value has to be read to its OWN closing quote. A placeholder src is a data
    // URI whose SVG carries quotes of the other kind inside it -- src="...%3Csvg xmlns='...'..."
    // -- so a naive [^"']* stops at the first inner quote and replaces a fragment, leaving the
    // tail of the old URI behind as broken markup. Matching (["'])(?:(?!\1).)*\1 keeps the
    // opening quote and consumes anything that is not that same quote.
    const SRC_ATTR = /\bsrc\s*=\s*(["'])(?:(?!\1)[\s\S])*\1/i;
    let count = -1;
    return html.replace(/<img\b[^>]*\bdata-ai-image-slot=["']true["'][^>]*>/gi, (tag) => {
      count += 1;
      if (count !== occurrenceIndex) return tag;
      const attr = `src="${escapeAttr(newUrl)}"`;
      if (SRC_ATTR.test(tag)) return tag.replace(SRC_ATTR, () => attr);
      return tag.replace(/^<img\b/i, () => `<img ${attr}`);
    });
  }

  // Triggered by clicking an AI-placed image slot in the canvas (see refreshCanvas). Opens a native
  // file picker, uploads through the same per-business /api/images/upload endpoint the Image Storage
  // tab already uses, then swaps that one placeholder's src for the uploaded image's real URL.
  function openImageUploadForSlot(page, sectionIndex, occurrenceIndex) {
    if (imageUploadBusy) return;
    if (!page.businessId) {
      App.utils.showToast('This page has no business assigned -- select a business before uploading images.');
      return;
    }
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = IMAGE_ACCEPTED_MIME.join(',');
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      input.remove();
      if (!file) return;
      if (!IMAGE_ACCEPTED_MIME.includes(file.type)) {
        App.utils.showToast('Unsupported file type -- use PNG, JPEG, GIF, or WebP.');
        return;
      }
      if (file.size > IMAGE_MAX_BYTES) {
        App.utils.showToast('That image is too large (max 8MB).');
        return;
      }
      imageUploadBusy = true;
      try {
        const dataBase64 = await readFileAsBase64(file);
        const data = await postJson('/api/images/upload', {
          businessId: page.businessId, filename: file.name, mimeType: file.type, dataBase64
        });
        const section = page.sections[sectionIndex];
        if (!section || !data.image) return;
        pushUndo(page);
        section.html = replaceNthImageSlotSrc(section.html, occurrenceIndex, data.image.url);
        page.updatedAt = Date.now();
        refreshCanvas(page);
        save();
        App.utils.showToast('Image uploaded.');
      } catch (e) {
        App.utils.showToast('Could not upload image: ' + e.message);
      } finally {
        imageUploadBusy = false;
      }
    }, { once: true });
    document.body.appendChild(input);
    input.click();
  }

  function isSafeEmbedUrl(url) {
    try {
      const u = new URL(url, window.location.href);
      return u.protocol === 'http:' || u.protocol === 'https:';
    } catch (e) {
      return false;
    }
  }

  // Turns a pasted URL into a real embeddable element -- YouTube/Vimeo links become their standard
  // /embed/ iframe form, a direct video file (.mp4/.webm/.ogg/.mov) becomes a plain <video>, and
  // anything else is trusted as an already-embeddable URL (e.g. another platform's own /embed/ link)
  // and dropped into an <iframe>. Returns null for an empty or unsafe (non-http/https) URL.
  function resolveVideoEmbed(rawUrl) {
    const url = (rawUrl || '').trim();
    if (!url || !isSafeEmbedUrl(url)) return null;
    const IFRAME_ALLOW = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    const yt = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{6,})/i);
    if (yt) {
      return `<iframe src="https://www.youtube.com/embed/${escapeAttr(yt[1])}" style="width:100%;height:100%;border:0;display:block;" allow="${IFRAME_ALLOW}" allowfullscreen></iframe>`;
    }
    const vimeo = url.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
    if (vimeo) {
      return `<iframe src="https://player.vimeo.com/video/${escapeAttr(vimeo[1])}" style="width:100%;height:100%;border:0;display:block;" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
    }
    if (/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(url)) {
      return `<video src="${escapeAttr(url)}" controls style="width:100%;height:100%;display:block;"></video>`;
    }
    return `<iframe src="${escapeAttr(url)}" style="width:100%;height:100%;border:0;display:block;" allow="${IFRAME_ALLOW}" allowfullscreen></iframe>`;
  }

  // Replaces the inner content of the Nth <div data-ai-video-slot="true">...</div> occurrence in a
  // section's html (0-based, in document order) with a resolved embed element -- keeps the div's own
  // opening tag (and therefore its section-scoped class/sizing CSS) unchanged, only its placeholder
  // copy is swapped out. Assumes the AI followed its own instruction to keep the placeholder's inner
  // content to one short line of text (no nested elements) per the aiFunnel prompt's "Video:" rule.
  function replaceNthVideoSlotContent(html, occurrenceIndex, embedHtml) {
    let count = -1;
    return html.replace(/<div\b[^>]*\bdata-ai-video-slot=["']true["'][^>]*>[\s\S]*?<\/div>/gi, (tag) => {
      count += 1;
      if (count !== occurrenceIndex) return tag;
      const openTagMatch = tag.match(/^<div\b[^>]*>/i);
      const openTag = openTagMatch ? openTagMatch[0] : '<div data-ai-video-slot="true">';
      return openTag + embedHtml + '</div>';
    });
  }

  // Promise-based replacement for window.prompt() -- native prompt()/confirm()/alert() are not
  // supported in every browser environment this app runs in (confirmed by a real user-reported
  // failure elsewhere in this app), so this uses a real inline modal instead, resolving to the
  // entered URL or null on cancel.
  function askVideoUrl(placeholder) {
    return new Promise((resolve) => {
      const backdrop = $('pagesVideoUrlBackdrop');
      const input = $('pagesVideoUrlInput');
      const saveBtn = $('pagesVideoUrlSave');
      const cancelBtn = $('pagesVideoUrlCancel');

      input.value = '';
      input.placeholder = placeholder || 'https://...';
      backdrop.hidden = false;
      input.focus();

      function cleanup() {
        backdrop.hidden = true;
        saveBtn.removeEventListener('click', onSave);
        cancelBtn.removeEventListener('click', onCancel);
        backdrop.removeEventListener('keydown', onKeydown);
      }
      function onSave() {
        const value = input.value;
        cleanup();
        resolve(value);
      }
      function onCancel() {
        cleanup();
        resolve(null);
      }
      function onKeydown(e) {
        if (e.key === 'Escape') onCancel();
        else if (e.key === 'Enter') onSave();
      }
      saveBtn.addEventListener('click', onSave);
      cancelBtn.addEventListener('click', onCancel);
      backdrop.addEventListener('keydown', onKeydown);
    });
  }

  /* Triggered by the + between two sections in the canvas. Mirrors askVideoUrl: one hidden dialog
     in the page, driven as a promise, resolving with the typed description or null on a back-out.

     The chips only prefill the box. They exist for someone facing an empty field, not as a menu of
     section types -- the text stays editable afterwards, and describing something not on the list
     is the normal case rather than the exception. */
  function askNewSection(index, total) {
    return new Promise((resolve) => {
      const backdrop = $('pagesAddSectionBackdrop');
      const input = $('pagesAddSectionInput');
      const goBtn = $('pagesAddSectionGo');
      const cancelBtn = $('pagesAddSectionCancel');
      const chips = $('pagesAddSectionChips');
      const hint = $('pagesAddSectionHint');

      const where = index === 0 ? 'Adding above the first section'
        : index >= total ? 'Adding below the last section'
        : 'Adding between sections ' + index + ' and ' + (index + 1);

      input.value = '';
      goBtn.disabled = true;
      hint.textContent = where + ' · Ctrl+Enter to submit';
      backdrop.hidden = false;
      input.focus();

      function cleanup() {
        backdrop.hidden = true;
        input.removeEventListener('input', onInput);
        chips.removeEventListener('click', onChip);
        goBtn.removeEventListener('click', onGo);
        cancelBtn.removeEventListener('click', onCancel);
        backdrop.removeEventListener('keydown', onKeydown);
      }
      function onInput() { goBtn.disabled = !input.value.trim(); }
      function onChip(e) {
        const btn = e.target.closest('[data-chip]');
        if (!btn) return;
        input.value = btn.dataset.chip;
        onInput();
        input.focus();
      }
      function onGo() {
        const value = input.value.trim();
        if (!value) return;
        cleanup();
        resolve(value);
      }
      function onCancel() {
        cleanup();
        resolve(null);
      }
      // Enter alone inserts a newline: the box is a textarea because a useful section description
      // often runs to two or three lines, so Enter must not submit out from under the designer.
      function onKeydown(e) {
        if (e.key === 'Escape') onCancel();
        else if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) onGo();
      }
      input.addEventListener('input', onInput);
      chips.addEventListener('click', onChip);
      goBtn.addEventListener('click', onGo);
      cancelBtn.addEventListener('click', onCancel);
      backdrop.addEventListener('keydown', onKeydown);
    });
  }

  // Phase 1: collects the description and confirms where it would land. The generation call and the
  // insert itself are wired in once the pageSectionAdd mode exists server-side.
  async function openAddSection(page, index) {
    const description = await askNewSection(index, page.sections.length);
    if (description === null) return;
    App.utils.showToast('Would add at position ' + (index + 1) + ': "' + description + '"');
  }

  // Triggered by clicking an AI-placed video slot in the canvas (see refreshCanvas). Asks for a
  // YouTube/Vimeo/direct-file URL and swaps the placeholder's content for the resolved embed -- no
  // server involvement, this is pure client-side URL parsing (unlike the image slot's upload flow).
  async function openVideoEmbedForSlot(page, sectionIndex, occurrenceIndex) {
    const url = await askVideoUrl();
    if (url === null) return;
    const embedHtml = resolveVideoEmbed(url);
    if (!embedHtml) {
      App.utils.showToast(url.trim() ? 'That doesn\'t look like a valid video URL.' : 'No URL entered.');
      return;
    }
    const section = page.sections[sectionIndex];
    if (!section) return;
    pushUndo(page);
    section.html = replaceNthVideoSlotContent(section.html, occurrenceIndex, embedHtml);
    page.updatedAt = Date.now();
    refreshCanvas(page);
    save();
    App.utils.showToast('Video added.');
  }

  // Background videos accept a direct file (real <video>, sized with object-fit:cover -- the clean
  // path) or a YouTube link (a genuine hack: YouTube is an iframe, iframes have no object-fit, so it's
  // deliberately oversized and centered inside an overflow:hidden wrapper to approximate "fill and
  // crop", muted/looped via URL params, and pointer-events:none since it's decorative, not a player).
  // Vimeo and other embeddable-URL platforms stay unsupported here -- same fragility, not asked for.
  // Returns an HTML string or null.
  function resolveVideoBackgroundEmbed(rawUrl) {
    const url = (rawUrl || '').trim();
    if (!url || !isSafeEmbedUrl(url)) return null;
    if (/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(url)) {
      return `<video src="${escapeAttr(url)}" autoplay muted loop playsinline data-bg-video="true" style="width:100%;height:100%;object-fit:cover;display:block;"></video>`;
    }
    const yt = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{6,})/i);
    if (yt) {
      const id = escapeAttr(yt[1]);
      const src = `https://www.youtube.com/embed/${id}?autoplay=1&mute=1&loop=1&playlist=${id}&controls=0&modestbranding=1&playsinline=1&rel=0&disablekb=1&fs=0&iv_load_policy=3`;
      return `<div style="position:absolute;inset:0;overflow:hidden;" data-bg-video="true"><iframe src="${src}" style="position:absolute;top:50%;left:50%;width:177.78vh;height:56.25vw;min-width:100%;min-height:100%;transform:translate(-50%,-50%);border:0;pointer-events:none;" allow="autoplay; encrypted-media" tabindex="-1"></iframe></div>`;
    }
    return null;
  }

  // Same replacement approach as replaceNthVideoSlotContent, targeting the background-slot attribute
  // instead -- the slot div's own position:absolute;inset:0 sizing (written by the AI per the
  // aiFunnel prompt's "Video-background hero" rule) already makes the inserted <video> fill it.
  function replaceNthVideoBgSlotContent(html, occurrenceIndex, embedHtml) {
    let count = -1;
    return html.replace(/<div\b[^>]*\bdata-ai-video-bg-slot=["']true["'][^>]*>[\s\S]*?<\/div>/gi, (tag) => {
      count += 1;
      if (count !== occurrenceIndex) return tag;
      const openTagMatch = tag.match(/^<div\b[^>]*>/i);
      const openTag = openTagMatch ? openTagMatch[0] : '<div data-ai-video-bg-slot="true">';
      return openTag + embedHtml + '</div>';
    });
  }

  // Triggered by clicking an AI-placed video-BACKGROUND slot (the full-bleed hero treatment,
  // distinct from the bounded data-ai-video-slot box handled above).
  async function openVideoBackgroundForSlot(page, sectionIndex, occurrenceIndex) {
    const url = await askVideoUrl('Direct .mp4/.webm URL or a YouTube link');
    if (url === null) return;
    const embedHtml = resolveVideoBackgroundEmbed(url);
    if (!embedHtml) {
      App.utils.showToast(url.trim() ? 'Background videos need a direct .mp4/.webm/.ogg/.mov link or a YouTube URL -- Vimeo and other platforms aren\'t supported here.' : 'No URL entered.');
      return;
    }
    const section = page.sections[sectionIndex];
    if (!section) return;
    pushUndo(page);
    section.html = replaceNthVideoBgSlotContent(section.html, occurrenceIndex, embedHtml);
    page.updatedAt = Date.now();
    refreshCanvas(page);
    save();
    App.utils.showToast('Background video added.');
  }

  function refreshCanvas(page) {
    const frame = $('pages-preview-frame');
    frame.srcdoc = buildEditorPageDoc(page);
    frame.onload = () => {
      const doc = frame.contentDocument;
      if (!doc) return;
      // Double-click starts text editing. Single click keeps its existing meaning (pick the
      // section for the AI chat), so the two never fight over the same gesture.
      doc.querySelectorAll('[data-cc-edit]').forEach((el) => {
        el.addEventListener('dblclick', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (el.getAttribute('contenteditable') === 'true') return;
          const sectionEl = el.closest('[data-section-index]');
          if (!sectionEl) return;
          const original = el.innerHTML;
          el.setAttribute('contenteditable', 'true');
          el.focus();

          // Paste as plain text -- pasting from a browser or Word otherwise drags in span/style
          // soup that overrides the section's own CSS.
          const onPaste = (ev) => {
            ev.preventDefault();
            const text = (ev.clipboardData || window.clipboardData).getData('text');
            el.ownerDocument.execCommand('insertText', false, text);
          };
          // Enter and Escape commit and cancel directly rather than going through blur(). Routing a
          // deliberate keystroke through a side effect is fragile -- blur does not always fire when
          // the frame itself is not the focused document, which would silently drop the edit. blur
          // stays as the click-away path, and `settled` keeps the two from both running.
          let settled = false;
          const cleanup = () => {
            el.removeAttribute('contenteditable');
            el.removeEventListener('paste', onPaste);
            el.removeEventListener('keydown', onKey);
            el.removeEventListener('blur', onBlur);
          };
          const commit = () => {
            if (settled) return;
            settled = true;
            const next = el.innerHTML;
            cleanup();
            if (next === original) return;
            const changed = applyTextEdit(
              getById(editingId),
              Number(sectionEl.dataset.sectionIndex),
              Number(el.dataset.ccEdit),
              next
            );
            if (changed) {
              const page = getById(editingId);
              renderNavigator(page);
              renderLinks(page);
              renderForms(page);
              App.utils.showToast('Text updated.');
            }
          };
          const cancel = () => {
            if (settled) return;
            settled = true;
            el.innerHTML = original;
            cleanup();
          };
          const onKey = (ev) => {
            if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); commit(); el.blur(); }
            else if (ev.key === 'Escape') { ev.preventDefault(); cancel(); el.blur(); }
          };
          const onBlur = () => commit();
          el.addEventListener('paste', onPaste);
          el.addEventListener('keydown', onKey);
          el.addEventListener('blur', onBlur);
        });
      });

      doc.querySelectorAll('[data-section-index]').forEach((el) => {
        el.addEventListener('click', (e) => {
          e.preventDefault();
          if (e.target.closest('[contenteditable="true"]')) return;
          pickSectionForChat(Number(el.dataset.sectionIndex));
        });
        const sectionIndex = Number(el.dataset.sectionIndex);
        el.querySelectorAll('img[data-ai-image-slot]').forEach((imgEl, occurrenceIndex) => {
          imgEl.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            openImageUploadForSlot(page, sectionIndex, occurrenceIndex);
          });
        });
        el.querySelectorAll('[data-ai-video-slot]').forEach((videoEl, occurrenceIndex) => {
          videoEl.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            openVideoEmbedForSlot(page, sectionIndex, occurrenceIndex);
          });
        });
        el.querySelectorAll('[data-ai-video-bg-slot]').forEach((bgEl, occurrenceIndex) => {
          bgEl.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            openVideoBackgroundForSlot(page, sectionIndex, occurrenceIndex);
          });
        });
      });

      doc.querySelectorAll('.pages-editor-insert-btn').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          openAddSection(page, Number(btn.dataset.insertIndex));
        });
      });
      updateCanvasHighlight();
    };
    updateCodePanel(page);
  }

  // Reflects the current selection as an outline directly in the iframe, without reloading its
  // srcdoc (a reload would discard scroll position and re-run any section-level CSS transitions).
  function updateCanvasHighlight() {
    const frame = $('pages-preview-frame');
    const doc = frame.contentDocument;
    if (!doc) return;
    doc.querySelectorAll('.pages-editor-section').forEach((el) => {
      el.classList.toggle('pages-editor-section-selected', Number(el.dataset.sectionIndex) === selectedSectionIndex);
    });
  }

  /* ---------- Inline text editing ----------
     Retyping a headline should not cost an AI round trip. Double-click any element that owns text
     and edit it in place.

     Addressing is the whole problem here. Links and image slots can be found by regex because a
     href/src is an attribute; an element's inner text cannot be, since matching balanced tags with
     a regex is not reliable. So both the editor's copy and the write-back walk the SAME ordered
     list of text-owning elements, derived from the same clean stored HTML -- the editor marks the
     Nth one, the write-back replaces the Nth one. Editor markers are added to the rendered copy
     only and never enter section.html, matching how the section wrapper chrome already works.

     "Owns text" means the element has a direct non-empty text node child. That deliberately picks
     the <h1> rather than its wrapping <div>, so editing can never restructure a layout. */
  function editableTextElements(doc) {
    return Array.from(doc.body.querySelectorAll('*')).filter((el) => {
      if (/^(script|style|br|img|input|textarea|select|video|source|iframe)$/i.test(el.tagName)) return false;
      return Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent.trim());
    });
  }

  function markEditableText(html) {
    const doc = new DOMParser().parseFromString('<body>' + html + '</body>', 'text/html');
    editableTextElements(doc).forEach((el, i) => {
      el.setAttribute('data-cc-edit', String(i));
      el.setAttribute('title', 'Double-click to edit this text');
    });
    return doc.body.innerHTML;
  }

  function applyTextEdit(page, sectionIndex, editIndex, newInnerHtml) {
    const section = page.sections[sectionIndex];
    if (!section) return false;
    const doc = new DOMParser().parseFromString('<body>' + section.html + '</body>', 'text/html');
    const targets = editableTextElements(doc);
    const el = targets[editIndex];
    if (!el) return false;
    if (el.innerHTML === newInnerHtml) return false;
    el.innerHTML = newInnerHtml;
    pushUndo(page);
    section.html = doc.body.innerHTML;
    page.updatedAt = Date.now();
    save();
    return true;
  }

  /* ---------- Placeholder testimonials ----------
     When the Business Info Reviews field is empty the generator still writes testimonials, because
     a proof section with nothing in it reads worse than one with something. That is a reasonable
     default for a draft and a bad thing to publish: the quotes are invented, and they go out under
     a real client's name.

     So the generation is left alone and the warning lives here instead -- visible to the designer
     in the editor, invisible to the visitor. Detection is structural (blockquote/cite) rather than
     by section name, since the generator invents its own section types and "proof", "patient-proof"
     and "testimonials" have all turned up. */
  function placeholderTestimonials(page) {
    const business = App.businessProfile.getById(page.businessId);
    const realReviews = ((business && business.reviews) || []).filter(
      (r) => r && (String(r.quote || '').trim() || String(r.text || '').trim())
    );
    if (realReviews.length) return null;   // the user supplied their own -- nothing invented

    const parser = new DOMParser();
    const hits = [];
    page.sections.forEach((section, i) => {
      const doc = parser.parseFromString('<body>' + section.html + '</body>', 'text/html');
      const quotes = doc.querySelectorAll('blockquote, cite');
      if (quotes.length) hits.push({ index: i, type: section.type, count: doc.querySelectorAll('blockquote').length || quotes.length });
    });
    if (!hits.length) return null;
    return { sections: hits, total: hits.reduce((n, h) => n + h.count, 0) };
  }

  function renderPlaceholderWarning(page) {
    const box = $('pages-placeholder-warning');
    if (!box) return;
    const found = page ? placeholderTestimonials(page) : null;
    if (!found) { box.hidden = true; return; }
    box.hidden = false;
    $('pages-placeholder-title').textContent =
      found.total + ' placeholder testimonial' + (found.total === 1 ? '' : 's') + ' on this page';
    $('pages-placeholder-body').textContent =
      'No reviews were saved for this business, so these quotes were written by the AI. Replace them with '
      + 'real ones before publishing -- invented testimonials under a client\u2019s name are their legal problem '
      + 'and your reputation. Section' + (found.sections.length === 1 ? '' : 's') + ': '
      + found.sections.map((s) => s.type).join(', ') + '.';
  }

  /* ---------- Forms ----------
     A generated form is markup only: it has fields and styling but nowhere to send anything.
     CodeCraft deliberately does not receive submissions itself -- the whole promise is that there
     are no CodeCraft servers and client data never passes through us -- so wiring a form means
     pointing it at a service the designer already controls.

     Every preset below is "set an action URL", which keeps the generated design intact. The GHL
     entry uses an inbound-webhook URL for the same reason: pasting GoHighLevel's iframe embed
     would work too, but it replaces the bespoke form with their generic one.

     A form whose fields have no name attribute submits nothing useful no matter where it points,
     so that is checked here and repairable in one click. */
  const FORM_PRESETS = [
    { id: 'none', label: 'Not connected', hint: 'Submissions go nowhere. Pick a destination below.' },
    { id: 'ghl', label: 'GoHighLevel', placeholder: 'https://services.leadconnectorhq.com/hooks/…',
      hint: 'Create an Inbound Webhook trigger in a GHL workflow and paste its URL. Keeps this form\u2019s design.' },
    { id: 'formspree', label: 'Formspree', placeholder: 'https://formspree.io/f/xxxxxxx',
      hint: 'Free tier available. Paste the endpoint from your Formspree form.' },
    { id: 'basin', label: 'Basin', placeholder: 'https://usebasin.com/f/xxxxxxx',
      hint: 'Paste the endpoint from your Basin form.' },
    { id: 'web3forms', label: 'Web3Forms', placeholder: 'your-access-key',
      hint: 'Paste your access key \u2014 the endpoint and hidden key field are added for you.', key: true },
    { id: 'custom', label: 'Custom URL', placeholder: 'https://…',
      hint: 'Any endpoint that accepts a POST from a static page.' },
    { id: 'email', label: 'Email (mailto)', placeholder: 'you@example.com',
      hint: 'Opens the visitor\u2019s mail app. Works everywhere but is unreliable and exposes the address.' }
  ];

  function formsIn(page) {
    const parser = new DOMParser();
    const rows = [];
    page.sections.forEach((section, sectionIndex) => {
      const doc = parser.parseFromString('<body>' + section.html + '</body>', 'text/html');
      Array.from(doc.querySelectorAll('form')).forEach((form, occurrenceIndex) => {
        const fields = Array.from(form.querySelectorAll('input, textarea, select'))
          .filter((f) => !/^(submit|button|image|reset)$/i.test(f.getAttribute('type') || ''));
        const unnamed = fields.filter((f) => !(f.getAttribute('name') || '').trim());
        const action = form.getAttribute('action') || '';
        rows.push({
          sectionIndex, sectionType: section.type, occurrenceIndex, action,
          method: (form.getAttribute('method') || '').toUpperCase(),
          fieldCount: fields.length, unnamedCount: unnamed.length,
          label: (form.querySelector('button, [type=submit]') || {}).textContent || 'Form'
        });
      });
    });
    return rows;
  }

  function withNthForm(page, sectionIndex, occurrenceIndex, mutate) {
    const section = page.sections[sectionIndex];
    if (!section) return false;
    const doc = new DOMParser().parseFromString('<body>' + section.html + '</body>', 'text/html');
    const form = doc.querySelectorAll('form')[occurrenceIndex];
    if (!form) return false;
    mutate(form, doc);
    pushUndo(page);
    section.html = doc.body.innerHTML;
    page.updatedAt = Date.now();
    save();
    return true;
  }

  function setFormDestination(page, row, presetId, value) {
    const preset = FORM_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    const v = String(value || '').trim();
    const ok = withNthForm(page, row.sectionIndex, row.occurrenceIndex, (form, doc) => {
      // A stale hidden key from a previous provider must never ride along to the next one.
      const oldKey = form.querySelector('input[name="access_key"]');
      if (oldKey) oldKey.remove();

      if (presetId === 'none' || !v) {
        form.removeAttribute('action');
        form.removeAttribute('method');
        // enctype too -- it is only ever set by the mailto preset, and leaving it behind means a
        // form disconnected from mailto carries a stale attribute into whatever comes next.
        form.removeAttribute('enctype');
        return;
      }
      if (presetId === 'email') {
        form.setAttribute('action', 'mailto:' + v);
        form.setAttribute('method', 'post');
        form.setAttribute('enctype', 'text/plain');
        return;
      }
      form.removeAttribute('enctype');
      form.setAttribute('method', 'post');
      if (presetId === 'web3forms') {
        form.setAttribute('action', 'https://api.web3forms.com/submit');
        const hidden = doc.createElement('input');
        hidden.setAttribute('type', 'hidden');
        hidden.setAttribute('name', 'access_key');
        hidden.setAttribute('value', v);
        form.insertBefore(hidden, form.firstChild);
        return;
      }
      form.setAttribute('action', v);
    });
    if (ok) {
      refreshCanvas(page);
      renderForms(page);
      App.utils.showToast('Form destination updated.');
    }
  }

  // Derive a submittable name from whatever the field already tells us, so a generation that
  // forgot them does not have to be re-run.
  function repairFieldNames(page, row) {
    let fixed = 0;
    const ok = withNthForm(page, row.sectionIndex, row.occurrenceIndex, (form, doc) => {
      const used = Object.create(null);
      Array.from(form.querySelectorAll('input, textarea, select')).forEach((f, i) => {
        const type = (f.getAttribute('type') || '').toLowerCase();
        if (/^(submit|button|image|reset)$/.test(type)) return;
        if ((f.getAttribute('name') || '').trim()) { used[f.getAttribute('name')] = true; return; }
        const id = f.getAttribute('id');
        const label = id ? form.querySelector('label[for="' + id + '"]') : null;
        const source = (label && label.textContent) || f.getAttribute('aria-label')
          || f.getAttribute('placeholder') || (type === 'email' ? 'email' : type === 'tel' ? 'phone' : 'field_' + (i + 1));
        let base = String(source).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40) || ('field_' + (i + 1));
        let name = base, n = 2;
        while (used[name]) { name = base + '_' + n; n++; }
        used[name] = true;
        f.setAttribute('name', name);
        fixed++;
      });
    });
    if (ok) {
      refreshCanvas(page);
      renderForms(page);
      App.utils.showToast(fixed + ' field name' + (fixed === 1 ? '' : 's') + ' added.');
    }
  }

  function presetForAction(action) {
    if (!action) return 'none';
    if (/^mailto:/i.test(action)) return 'email';
    if (/api\.web3forms\.com/i.test(action)) return 'web3forms';
    if (/formspree\.io/i.test(action)) return 'formspree';
    if (/usebasin\.com/i.test(action)) return 'basin';
    if (/leadconnectorhq\.com|gohighlevel/i.test(action)) return 'ghl';
    return 'custom';
  }

  function renderForms(page) {
    const list = $('pages-forms-list');
    const summary = $('pages-forms-summary');
    if (!list) return;
    list.innerHTML = '';
    const rows = formsIn(page);
    const problems = rows.filter((r) => !r.action || r.unnamedCount).length;

    if (summary) {
      summary.textContent = !rows.length
        ? 'No forms on this page.'
        : rows.length + ' form' + (rows.length === 1 ? '' : 's')
          + (problems ? ' \u00b7 ' + problems + ' not ready to collect leads' : ' \u00b7 all connected');
      summary.dataset.tone = problems ? 'warn' : 'ok';
    }

    rows.forEach((row) => {
      const item = document.createElement('div');
      item.className = 'pages-link-row' + ((!row.action || row.unnamedCount) ? ' has-issue' : '');

      const head = document.createElement('div');
      head.className = 'pages-link-head';
      const badge = document.createElement('span');
      badge.className = 'pages-nav-row-badge';
      badge.textContent = row.sectionType;
      const label = document.createElement('span');
      label.className = 'pages-link-text';
      label.textContent = row.fieldCount + ' field' + (row.fieldCount === 1 ? '' : 's');
      head.appendChild(badge);
      head.appendChild(label);
      item.appendChild(head);

      const current = presetForAction(row.action);
      const select = document.createElement('select');
      select.className = 'pages-form-select';
      FORM_PRESETS.forEach((p) => {
        const opt = document.createElement('option');
        opt.value = p.id;
        opt.textContent = p.label;
        opt.selected = p.id === current;
        select.appendChild(opt);
      });
      item.appendChild(select);

      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'pages-link-input';
      input.value = current === 'web3forms' ? '' : (current === 'email' ? row.action.replace(/^mailto:/i, '') : row.action);
      item.appendChild(input);

      const hint = document.createElement('p');
      hint.className = 'pages-form-hint';
      item.appendChild(hint);

      const syncPreset = () => {
        const p = FORM_PRESETS.find((x) => x.id === select.value);
        hint.textContent = p ? p.hint : '';
        input.placeholder = (p && p.placeholder) || '';
        input.hidden = select.value === 'none';
      };
      syncPreset();
      select.addEventListener('change', () => {
        syncPreset();
        if (select.value === 'none') setFormDestination(page, row, 'none', '');
        else input.focus();
      });
      const commit = () => {
        if (select.value === 'none') return;
        const v = input.value.trim();
        if (!v) return;
        setFormDestination(page, row, select.value, v);
      };
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });

      if (row.unnamedCount) {
        const warn = document.createElement('p');
        warn.className = 'pages-link-issue';
        warn.textContent = row.unnamedCount + ' field' + (row.unnamedCount === 1 ? '' : 's')
          + ' missing a name \u2014 those answers arrive empty wherever you send them.';
        item.appendChild(warn);
        const fixBtn = document.createElement('button');
        fixBtn.type = 'button';
        fixBtn.className = 'btn pages-form-fix';
        fixBtn.textContent = 'Add field names';
        fixBtn.addEventListener('click', () => repairFieldNames(page, row));
        item.appendChild(fixBtn);
      } else if (!row.action) {
        const warn = document.createElement('p');
        warn.className = 'pages-link-issue';
        warn.textContent = 'No destination \u2014 submissions go nowhere.';
        item.appendChild(warn);
      }

      list.appendChild(item);
    });
  }

  /* ---------- Links ----------
     Every generated CTA points somewhere, and on a fresh page that somewhere is usually a
     placeholder anchor. Hunting them by clicking around the preview is slow and easy to get
     wrong; a flat list of every link on the page, with the problems called out, is one pass.

     Anchors are addressed by their occurrence index within a section -- the same approach the
     image and video slot editors already use, and it carries the same assumption: that the Nth
     <a> the DOM parser sees is the Nth <a> the regex sees. True for generated markup, which has
     no anchors hiding inside comments or attribute values. */
  function replaceNthLinkHref(html, occurrenceIndex, newHref) {
    let count = -1;
    return html.replace(/<a\b[^>]*>/gi, (tag) => {
      count += 1;
      if (count !== occurrenceIndex) return tag;
      const safe = escapeAttr(newHref);
      if (/\bhref\s*=\s*["'][^"']*["']/i.test(tag)) {
        return tag.replace(/\bhref\s*=\s*["'][^"']*["']/i, 'href="' + safe + '"');
      }
      return tag.replace(/^<a\b/i, '<a href="' + safe + '"');
    });
  }

  function collectLinks(page) {
    const parser = new DOMParser();

    // Which section does each id live in? Needed to spot a button that scrolls to the section
    // it is already inside -- a dead control that looks fine until someone clicks it.
    const idSection = Object.create(null);
    page.sections.forEach((section, i) => {
      const doc = parser.parseFromString('<body>' + section.html + '</body>', 'text/html');
      doc.querySelectorAll('[id]').forEach((el) => { idSection[el.id] = i; });
    });

    const rows = [];
    page.sections.forEach((section, sectionIndex) => {
      const doc = parser.parseFromString('<body>' + section.html + '</body>', 'text/html');
      Array.from(doc.querySelectorAll('a')).forEach((a, occurrenceIndex) => {
        const href = a.getAttribute('href') || '';
        const text = (a.textContent || '').replace(/\s+/g, ' ').trim();
        let issue = '';
        if (!href || href === '#') {
          issue = 'No destination';
        } else if (href.charAt(0) === '#') {
          const target = href.slice(1);
          if (!(target in idSection)) issue = 'Anchor not found on this page';
          else if (idSection[target] === sectionIndex) issue = 'Links to its own section';
        }
        rows.push({ sectionIndex, sectionType: section.type, occurrenceIndex, href, text, issue });
      });
    });
    return rows;
  }

  function applyLinkHref(page, sectionIndex, occurrenceIndex, newHref) {
    const section = page.sections[sectionIndex];
    if (!section) return;
    pushUndo(page);
    section.html = replaceNthLinkHref(section.html, occurrenceIndex, newHref);
    page.updatedAt = Date.now();
    refreshCanvas(page);
    renderLinks(page);
    renderForms(page);
    save();
  }

  function renderLinks(page) {
    const list = $('pages-links-list');
    const summary = $('pages-links-summary');
    if (!list) return;
    list.innerHTML = '';

    const rows = collectLinks(page);
    const problems = rows.filter((r) => r.issue).length;
    if (summary) {
      summary.textContent = !rows.length
        ? 'This page has no links yet.'
        : rows.length + ' link' + (rows.length === 1 ? '' : 's') + ' on this page'
          + (problems ? ' \u00b7 ' + problems + ' need attention' : ' \u00b7 all have a destination');
      summary.dataset.tone = problems ? 'warn' : 'ok';
    }

    rows.forEach((row) => {
      const item = document.createElement('div');
      item.className = 'pages-link-row' + (row.issue ? ' has-issue' : '');

      const head = document.createElement('div');
      head.className = 'pages-link-head';
      const badge = document.createElement('span');
      badge.className = 'pages-nav-row-badge';
      badge.textContent = row.sectionType;
      const label = document.createElement('span');
      label.className = 'pages-link-text';
      label.textContent = row.text || '(no text)';
      head.appendChild(badge);
      head.appendChild(label);
      item.appendChild(head);

      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'pages-link-input';
      input.value = row.href;
      input.placeholder = 'https://… or #section';
      input.setAttribute('aria-label', 'Destination for "' + (row.text || 'link') + '"');
      const commit = () => {
        const next = input.value.trim();
        if (next === row.href) return;
        applyLinkHref(page, row.sectionIndex, row.occurrenceIndex, next);
        App.utils.showToast('Link updated.');
      };
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
      });
      item.appendChild(input);

      if (row.issue) {
        const warn = document.createElement('p');
        warn.className = 'pages-link-issue';
        warn.textContent = row.issue;
        item.appendChild(warn);
      }
      list.appendChild(item);
    });
  }

  function renderNavigator(page) {
    const container = $('pages-navigator-list');
    if (!container) return;
    container.innerHTML = '';
    page.sections.forEach((section, index) => {
      const row = document.createElement('div');
      row.className = 'pages-nav-row' + (index === selectedSectionIndex ? ' is-active' : '');

      const main = document.createElement('div');
      main.className = 'pages-nav-row-main';
      const badge = document.createElement('span');
      badge.className = 'pages-nav-row-badge';
      badge.textContent = section.type;
      main.appendChild(badge);
      const preview = document.createElement('span');
      preview.className = 'pages-nav-row-preview';
      preview.textContent = previewTextFor(section);
      main.appendChild(preview);
      row.appendChild(main);

      const actions = document.createElement('div');
      actions.className = 'pages-nav-row-actions';

      const upBtn = document.createElement('button');
      upBtn.type = 'button';
      upBtn.className = 'pages-nav-icon-btn';
      upBtn.textContent = '↑';
      upBtn.title = 'Move up';
      upBtn.disabled = index === 0;
      upBtn.addEventListener('click', (e) => { e.stopPropagation(); moveSection(index, -1); });
      actions.appendChild(upBtn);

      const downBtn = document.createElement('button');
      downBtn.type = 'button';
      downBtn.className = 'pages-nav-icon-btn';
      downBtn.textContent = '↓';
      downBtn.title = 'Move down';
      downBtn.disabled = index === page.sections.length - 1;
      downBtn.addEventListener('click', (e) => { e.stopPropagation(); moveSection(index, 1); });
      actions.appendChild(downBtn);

      const dupBtn = document.createElement('button');
      dupBtn.type = 'button';
      dupBtn.className = 'pages-nav-icon-btn';
      dupBtn.textContent = '⧉';
      dupBtn.title = 'Duplicate';
      dupBtn.addEventListener('click', (e) => { e.stopPropagation(); duplicateSection(index); });
      actions.appendChild(dupBtn);

      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'pages-nav-icon-btn';
      delBtn.textContent = '🗑';
      delBtn.title = 'Delete';
      delBtn.addEventListener('click', (e) => { e.stopPropagation(); deleteSection(index); });
      actions.appendChild(delBtn);

      row.appendChild(actions);
      row.addEventListener('click', () => pickSectionForChat(index));
      container.appendChild(row);
    });
  }

  // Picking a section to work on should drop the designer straight into AI Chat ready to type --
  // requiring a manual tab switch after every selection was the friction this function removes.
  function pickSectionForChat(index) {
    selectSection(index);
    switchSidebarTab('chat');
    const input = $('pages-chat-input');
    if (input && !input.disabled) input.focus();
  }

  function appendChatBubble(role, text) {
    const log = $('pages-chat-log');
    if (!log) return;
    const bubble = document.createElement('div');
    bubble.className = 'pages-chat-bubble ' + (role === 'user' ? 'pages-chat-bubble-user' : 'pages-chat-bubble-ai');
    bubble.textContent = text;
    log.appendChild(bubble);
    log.scrollTop = log.scrollHeight;
  }

  function updateChatAvailability() {
    const hasSelection = selectedSectionIndex !== -1;
    $('pages-chat-input').disabled = chatBusy || !hasSelection;
    $('pages-chat-send').disabled = chatBusy || !hasSelection;
  }

  function selectSection(index) {
    const changed = index !== selectedSectionIndex;
    selectedSectionIndex = index;
    const page = getById(editingId);
    if (page) { renderNavigator(page); renderLinks(page); renderForms(page); renderPlaceholderWarning(page); }
    updateCanvasHighlight();
    const chatEmpty = $('pages-chat-empty');
    if (chatEmpty && page) {
      const section = page.sections[index];
      chatEmpty.textContent = section
        ? `Selected: ${section.type}. Tell the AI what to change about it below.`
        : 'Click a section in the preview, then tell the AI what to change about it.';
    }
    // A fresh selection starts a fresh micro-conversation about just that section, rather than
    // mixing edit requests for different sections into one confusing thread.
    if (changed) $('pages-chat-log').innerHTML = '';
    updateChatAvailability();
  }

  async function sendChatMessage() {
    const input = $('pages-chat-input');
    const instruction = input.value.trim();
    const page = getById(editingId);
    if (chatBusy || !instruction || !page || selectedSectionIndex === -1) return;
    const section = page.sections[selectedSectionIndex];
    if (!section) return;

    appendChatBubble('user', instruction);
    input.value = '';
    chatBusy = true;
    updateChatAvailability();
    const thinkingBubble = document.createElement('div');
    thinkingBubble.className = 'pages-chat-bubble pages-chat-bubble-ai';
    thinkingBubble.textContent = 'Thinking…';
    $('pages-chat-log').appendChild(thinkingBubble);

    try {
      const business = page.businessId ? App.businessProfile.getById(page.businessId) : null;
      const data = await postChat('pageSectionEdit', {
        business,
        section: { type: section.type, html: section.html, css: section.css },
        instruction
      });
      pushUndo(page);
      section.html = typeof data.html === 'string' ? data.html : section.html;
      section.css = typeof data.css === 'string' ? data.css : section.css;
      page.updatedAt = Date.now();
      thinkingBubble.textContent = data.message || 'Done.';
      refreshCanvas(page);
      renderNavigator(page);
      renderLinks(page);
      renderForms(page);
    renderLinks(page);
    renderForms(page);
      save();
    } catch (e) {
      thinkingBubble.remove();
      appendChatBubble('ai', 'Error: ' + e.message);
    } finally {
      chatBusy = false;
      updateChatAvailability();
    }
  }

  // One shared undo/redo history per open page, covering every section-content mutation (reorder,
  // duplicate, delete, AI edits) -- call this with the page's PRE-mutation state right before
  // changing page.sections. A fresh selection/mutation always clears redoStack, matching standard
  // editor undo/redo semantics (you can't redo past a new action).
  function pushUndo(page) {
    undoStack.push(cloneState(page.sections));
    redoStack = [];
    if (undoStack.length > 50) undoStack.shift();
    updateUndoRedoAvailability();
  }

  function updateUndoRedoAvailability() {
    const undoBtn = $('pages-undo-btn');
    const redoBtn = $('pages-redo-btn');
    if (undoBtn) undoBtn.disabled = undoStack.length === 0;
    if (redoBtn) redoBtn.disabled = redoStack.length === 0;
  }

  function undo() {
    const page = getById(editingId);
    if (!page || !undoStack.length) return;
    redoStack.push(cloneState(page.sections));
    page.sections = undoStack.pop();
    page.updatedAt = Date.now();
    selectSection(-1);
    renderNavigator(page);
    renderLinks(page);
    renderForms(page);
    refreshCanvas(page);
    updateUndoRedoAvailability();
    save();
  }

  function redo() {
    const page = getById(editingId);
    if (!page || !redoStack.length) return;
    undoStack.push(cloneState(page.sections));
    page.sections = redoStack.pop();
    page.updatedAt = Date.now();
    selectSection(-1);
    renderNavigator(page);
    renderLinks(page);
    renderForms(page);
    refreshCanvas(page);
    updateUndoRedoAvailability();
    save();
  }

  function moveSection(index, direction) {
    const page = getById(editingId);
    if (!page) return;
    const target = index + direction;
    if (target < 0 || target >= page.sections.length) return;
    pushUndo(page);
    const [section] = page.sections.splice(index, 1);
    page.sections.splice(target, 0, section);
    if (selectedSectionIndex === index) selectedSectionIndex = target;
    page.updatedAt = Date.now();
    renderNavigator(page);
    renderLinks(page);
    renderForms(page);
    refreshCanvas(page);
    save();
  }

  function duplicateSection(index) {
    const page = getById(editingId);
    if (!page) return;
    pushUndo(page);
    const clone = cloneState(page.sections[index]);
    clone.id = 'sec-copy-' + Date.now() + '-' + index;
    page.sections.splice(index + 1, 0, clone);
    page.updatedAt = Date.now();
    renderNavigator(page);
    renderLinks(page);
    renderForms(page);
    refreshCanvas(page);
    save();
  }

  function deleteSection(index) {
    const page = getById(editingId);
    if (!page) return;
    pushUndo(page);
    page.sections.splice(index, 1);
    if (selectedSectionIndex === index) selectSection(-1);
    else if (selectedSectionIndex > index) selectedSectionIndex -= 1;
    page.updatedAt = Date.now();
    renderNavigator(page);
    renderLinks(page);
    renderForms(page);
    refreshCanvas(page);
    save();
  }

  function switchSidebarTab(tab) {
    document.querySelectorAll('.pages-editor-sidebar .subtab-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.sidebarTab === tab);
    });
    $('pages-sidebar-chat').hidden = tab !== 'chat';
    $('pages-sidebar-navigator').hidden = tab !== 'navigator';
    $('pages-sidebar-links').hidden = tab !== 'links';
    $('pages-sidebar-forms').hidden = tab !== 'forms';
  }

  function openEditor(id) {
    const page = getById(id);
    if (!page) return;
    editingId = id;
    selectedSectionIndex = -1;
    undoStack = [];
    redoStack = [];
    $('pages-list-view').hidden = true;
    $('pages-editor-view').hidden = false;
    $('pages-editor-title').value = page.title;
    $('pages-editor-status').textContent = page.status;
    switchSidebarTab('chat');
    refreshCanvas(page);
    renderNavigator(page);
    renderLinks(page);
    renderForms(page);
    // Runs on open, not only on section select -- a pre-publish warning is useless if you have to
    // click something first to be told.
    renderPlaceholderWarning(page);
    updateUndoRedoAvailability();
    const chatEmpty = $('pages-chat-empty');
    if (chatEmpty) chatEmpty.textContent = 'Click a section in the preview, then tell the AI what to change about it.';
    $('pages-chat-log').innerHTML = '';
    updateChatAvailability();
  }

  function closeEditor() {
    editingId = null;
    selectedSectionIndex = -1;
    undoStack = [];
    redoStack = [];
    $('pages-editor-view').hidden = true;
    $('pages-list-view').hidden = false;
    updateCodePanel(null);
    renderGrid();
  }

  function renameActivePage(title) {
    const page = getById(editingId);
    if (!page) return;
    page.title = title;
    page.updatedAt = Date.now();
    save();
  }

  function getState() {
    return { pages, nextId };
  }

  function setState(data) {
    if (!data) return;
    pages = Array.isArray(data.pages) ? data.pages : [];
    nextId = typeof data.nextId === 'number' ? data.nextId : pages.length + 1;
    renderGrid();
  }

  function save() {
    if (App.persistence && typeof App.persistence.saveToLocalStorage === 'function') {
      App.persistence.saveToLocalStorage();
    }
  }

  function init() {
    $('pages-back-btn').addEventListener('click', closeEditor);
    $('pages-editor-title').addEventListener('input', (e) => renameActivePage(e.target.value));
    document.querySelectorAll('.pages-editor-sidebar .subtab-btn').forEach((btn) => {
      btn.addEventListener('click', () => switchSidebarTab(btn.dataset.sidebarTab));
    });
    $('pages-chat-send').addEventListener('click', sendChatMessage);
    $('pages-chat-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChatMessage();
      }
    });
    $('pages-undo-btn').addEventListener('click', undo);
    $('pages-redo-btn').addEventListener('click', redo);
    $('pages-save-btn').addEventListener('click', () => {
      save();
      App.utils.showToast('Page saved.');
    });
    $('pages-copy-embed').addEventListener('click', copyEmbedCode);
    $('pages-download-html').addEventListener('click', downloadPageHtml);
    $('pages-download-json').addEventListener('click', downloadPageJson);
    renderGrid();
  }

  App.pages = { init, getState, setState, getById, createFromSections, openEditor, closeEditor };
})(window.App);
