/* Font catalog: maps each font-family CSS stack (used as <select> option value)
   to its Google Fonts identifier + supported weight subset, when applicable. */
(function (App) {
  'use strict';

  App.fonts = [
    { value: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif", google: null },
    { value: "Georgia, 'Times New Roman', serif", google: null },
    { value: "'Courier New', Courier, monospace", google: null },
    { value: "Verdana, Geneva, sans-serif", google: null },
    { value: "'Trebuchet MS', sans-serif", google: null },

    { value: "'Inter', sans-serif", google: 'Inter', weights: '300;400;500;600;700;800' },
    { value: "'Roboto', sans-serif", google: 'Roboto', weights: '300;400;500;700' },
    { value: "'Open Sans', sans-serif", google: 'Open+Sans', weights: '300;400;500;600;700;800' },
    { value: "'Lato', sans-serif", google: 'Lato', weights: '300;400;700' },
    { value: "'Montserrat', sans-serif", google: 'Montserrat', weights: '300;400;500;600;700;800' },
    { value: "'Poppins', sans-serif", google: 'Poppins', weights: '300;400;500;600;700;800' },
    { value: "'Nunito', sans-serif", google: 'Nunito', weights: '300;400;500;600;700;800' },
    { value: "'Raleway', sans-serif", google: 'Raleway', weights: '300;400;500;600;700;800' },
    { value: "'Work Sans', sans-serif", google: 'Work+Sans', weights: '300;400;500;600;700;800' },
    { value: "'Oswald', sans-serif", google: 'Oswald', weights: '300;400;500;600;700' },

    { value: "'Playfair Display', serif", google: 'Playfair+Display', weights: '400;500;600;700;800' },
    { value: "'Merriweather', serif", google: 'Merriweather', weights: '300;400;700' },
    { value: "'Lora', serif", google: 'Lora', weights: '400;500;600;700' },
    { value: "'Source Serif 4', serif", google: 'Source+Serif+4', weights: '300;400;500;600;700;800' },

    { value: "'Fira Code', monospace", google: 'Fira+Code', weights: '300;400;500;600;700' },
    { value: "'JetBrains Mono', monospace", google: 'JetBrains+Mono', weights: '300;400;500;600;700;800' },
    { value: "'Space Mono', monospace", google: 'Space+Mono', weights: '400;700' },

    { value: "'Bebas Neue', sans-serif", google: 'Bebas+Neue', weights: '400' },
    { value: "'Pacifico', cursive", google: 'Pacifico', weights: '400' },
    { value: "'Dancing Script', cursive", google: 'Dancing+Script', weights: '400;500;600;700' }
  ];

  App.getGoogleFontLink = function (fontFamilyValue) {
    const font = App.fonts.find((f) => f.value === fontFamilyValue);
    if (!font || !font.google) return '';
    return `<link href="https://fonts.googleapis.com/css2?family=${font.google}:wght@${font.weights}&display=swap" rel="stylesheet">`;
  };
})(window.App);
