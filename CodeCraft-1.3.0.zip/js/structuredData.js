/* schema.org JSON-LD for an exported page.

   Everything here is derived from Business Info -- name, phones, email, address, hours, tagline,
   awards, social links -- which is already collected for the AI generator's benefit and was otherwise
   thrown away at export time.

   Two things worth knowing before editing this file:

   1. Not every industry is a LocalBusiness. Marking a SaaS company or an agency with no storefront as
      a LocalBusiness is incorrect structured data, and Google treats misrepresenting a business type
      as a policy violation rather than a harmless mistake -- so INDUSTRY_TYPES maps those to plain
      Organization, and the local-only properties (openingHours in particular) are suppressed for them.

   2. Customer reviews are deliberately NOT emitted. Every review in Business Info is a testimonial the
      business collected about itself, and Google's review-snippet policy makes self-serving reviews
      ineligible for rich results -- marking them up invites a manual action rather than stars. If that
      ever changes, aggregateRating/review belong here, sourced from a real third-party feed. */
(function (App) {
  'use strict';

  // schema.org type per Business Info industry. `local` gates the LocalBusiness-only properties;
  // anything false is an Organization descendant that has no opening hours or street presence.
  const INDUSTRY_TYPES = {
    'E-commerce': { type: 'OnlineStore', local: false },
    'Retail Store': { type: 'Store', local: true },
    'Grocery / Convenience': { type: 'GroceryStore', local: true },
    'Fashion / Apparel': { type: 'ClothingStore', local: true },
    'Furniture / Home Goods': { type: 'FurnitureStore', local: true },
    'Restaurant / Food': { type: 'Restaurant', local: true },
    'Cafe / Coffee Shop': { type: 'CafeOrCoffeeShop', local: true },
    'Bar / Nightlife': { type: 'BarOrPub', local: true },
    'Catering': { type: 'FoodEstablishment', local: true },
    'Bakery': { type: 'Bakery', local: true },
    'Hotel / Lodging': { type: 'Hotel', local: true },
    'Travel / Tourism': { type: 'TravelAgency', local: true },
    'Healthcare': { type: 'MedicalBusiness', local: true },
    'Dental': { type: 'Dentist', local: true },
    'Medical Spa / Aesthetics': { type: 'MedicalBusiness', local: true },
    'Chiropractic': { type: 'Chiropractic', local: true },
    'Physical Therapy': { type: 'Physiotherapy', local: true },
    'Mental Health / Counseling': { type: 'MedicalBusiness', local: true },
    'Fitness / Wellness': { type: 'HealthClub', local: true },
    'Yoga / Pilates Studio': { type: 'HealthClub', local: true },
    'Veterinary / Pet Care': { type: 'VeterinaryCare', local: true },
    'Home Services': { type: 'HomeAndConstructionBusiness', local: true },
    'Plumbing': { type: 'Plumber', local: true },
    'HVAC': { type: 'HVACBusiness', local: true },
    'Electrical': { type: 'Electrician', local: true },
    'Roofing': { type: 'RoofingContractor', local: true },
    'Landscaping / Lawn Care': { type: 'HomeAndConstructionBusiness', local: true },
    'Cleaning Services': { type: 'LocalBusiness', local: true },
    'Pest Control': { type: 'PestControlService', local: true },
    'Moving Services': { type: 'MovingCompany', local: true },
    'Contractor / Remodeling': { type: 'GeneralContractor', local: true },
    'Professional Services': { type: 'ProfessionalService', local: true },
    'Legal / Law Firm': { type: 'LegalService', local: true },
    'Accounting / Financial Services': { type: 'AccountingService', local: true },
    'Consulting': { type: 'ProfessionalService', local: true },
    'Marketing / Advertising Agency': { type: 'ProfessionalService', local: true },
    'IT Services': { type: 'ProfessionalService', local: true },
    'Staffing / Recruiting': { type: 'EmploymentAgency', local: true },
    'Insurance': { type: 'InsuranceAgency', local: true },
    'Real Estate': { type: 'RealEstateAgent', local: true },
    'Property Management': { type: 'RealEstateAgent', local: true },
    'Interior Design': { type: 'HomeAndConstructionBusiness', local: true },
    'Architecture': { type: 'ProfessionalService', local: true },
    'SaaS / Technology': { type: 'Organization', local: false },
    'Software Development': { type: 'Organization', local: false },
    'Mobile Apps': { type: 'Organization', local: false },
    'AI / Machine Learning': { type: 'Organization', local: false },
    'Cybersecurity': { type: 'Organization', local: false },
    'Web Design / Development': { type: 'Organization', local: false },
    'Auto Repair': { type: 'AutoRepair', local: true },
    'Auto Sales / Dealership': { type: 'AutoDealer', local: true },
    'Auto Detailing': { type: 'AutoWash', local: true },
    'Towing': { type: 'AutomotiveBusiness', local: true },
    'Salon / Hair': { type: 'HairSalon', local: true },
    'Barbershop': { type: 'HairSalon', local: true },
    'Nail Salon': { type: 'NailSalon', local: true },
    'Spa / Massage': { type: 'DaySpa', local: true },
    'Photography': { type: 'ProfessionalService', local: true },
    'Education': { type: 'EducationalOrganization', local: false },
    'Online Course / Coaching': { type: 'EducationalOrganization', local: false },
    'Tutoring': { type: 'EducationalOrganization', local: false },
    'Childcare / Daycare': { type: 'ChildCare', local: true },
    'Finance': { type: 'FinancialService', local: true },
    'Banking': { type: 'BankOrCreditUnion', local: true },
    'Investment / Wealth Management': { type: 'FinancialService', local: true },
    'Mortgage / Lending': { type: 'FinancialService', local: true },
    'Event Planning': { type: 'ProfessionalService', local: true },
    'Wedding Services': { type: 'ProfessionalService', local: true },
    'Entertainment / Media': { type: 'EntertainmentBusiness', local: true },
    'Music / DJ Services': { type: 'EntertainmentBusiness', local: true },
    'Manufacturing': { type: 'Organization', local: false },
    'Construction': { type: 'GeneralContractor', local: true },
    'Agriculture': { type: 'Organization', local: false },
    'Logistics / Transportation': { type: 'Organization', local: false },
    'Nonprofit': { type: 'NGO', local: false },
    'Religious Organization': { type: 'Organization', local: false },
    'Government / Public Sector': { type: 'GovernmentOrganization', local: false }
  };

  const DEFAULT_TYPE = { type: 'LocalBusiness', local: true };

  function typeForIndustry(industry) {
    return INDUSTRY_TYPES[String(industry || '').trim()] || DEFAULT_TYPE;
  }

  /* ---------- Opening hours ---------- */

  const DAY_CODES = {
    mon: 'Mo', monday: 'Mo', tue: 'Tu', tues: 'Tu', tuesday: 'Tu', wed: 'We', weds: 'We',
    wednesday: 'We', thu: 'Th', thur: 'Th', thurs: 'Th', thursday: 'Th', fri: 'Fr', friday: 'Fr',
    sat: 'Sa', saturday: 'Sa', sun: 'Su', sunday: 'Su'
  };

  function to24Hour(hour, minute, meridiem) {
    let h = parseInt(hour, 10);
    const m = minute ? parseInt(minute, 10) : 0;
    if (meridiem) {
      const pm = /p/i.test(meridiem);
      if (h === 12) h = pm ? 12 : 0;
      else if (pm) h += 12;
    }
    if (h > 23 || m > 59) return '';
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }

  // Business Hours is a free-text field ("Mon-Fri 8am-6pm"), but schema.org openingHours wants
  // "Mo-Fr 08:00-18:00". Anything this can't confidently parse returns '' so the property is dropped
  // -- an unparseable hours string is better left out than shipped in a shape validators reject.
  function parseOpeningHours(text) {
    const raw = String(text || '').trim();
    if (!raw) return '';

    // Normalise the dash variants and the word forms people type between ranges.
    const s = raw.replace(/[‐-―]/g, '-').replace(/\s+to\s+/gi, '-').replace(/\s+/g, ' ');

    if (/24\s*[\/x-]\s*7|24 hours|always open/i.test(s)) return 'Mo-Su 00:00-23:59';

    const dayRe = '([A-Za-z]{3,9})\\s*-\\s*([A-Za-z]{3,9})';
    const timeRe = '(\\d{1,2})(?::(\\d{2}))?\\s*([ap]\\.?m\\.?)?';
    const m = new RegExp(dayRe + '[,\\s]+' + timeRe + '\\s*-\\s*' + timeRe, 'i').exec(s);
    if (!m) return '';

    const from = DAY_CODES[m[1].toLowerCase()];
    const to = DAY_CODES[m[2].toLowerCase()];
    if (!from || !to) return '';

    // "9am-5" carries its meridiem only on one side; borrow it so the bare half doesn't read as 05:00.
    let openMeridiem = m[5];
    const closeMeridiem = m[8];
    if (!openMeridiem && closeMeridiem && parseInt(m[3], 10) > parseInt(m[6], 10)) {
      openMeridiem = /p/i.test(closeMeridiem) ? 'am' : 'pm';
    }

    const open = to24Hour(m[3], m[4], openMeridiem);
    let close = to24Hour(m[6], m[7], closeMeridiem);
    if (!open || !close) return '';

    // "9-5" with no am/pm on either side is shorthand for a 9am-5pm day, not a 20-hour overnight
    // shift -- push the close into the afternoon when it would otherwise land at or before opening.
    if (!openMeridiem && !closeMeridiem && close <= open) {
      const bumped = to24Hour(String(parseInt(m[6], 10) + 12), m[7], '');
      if (bumped && bumped > open) close = bumped;
    }

    return `${from}-${to} ${open}-${close}`;
  }

  /* ---------- Document ---------- */

  function firstNonEmpty(list, pick) {
    for (let i = 0; i < (list || []).length; i++) {
      const value = String(pick(list[i]) || '').trim();
      if (value) return value;
    }
    return '';
  }

  // Returns the JSON-LD object, or null when there isn't enough to say anything true. A graph whose
  // only claim is "@type: LocalBusiness" with no name is noise, so name is treated as required.
  function buildJsonLd(business, opts) {
    const b = business || {};
    const o = opts || {};
    const name = String(b.name || '').trim();
    if (!name) return null;

    const industry = b.industry === 'Other' ? b.industryOther : b.industry;
    const { type, local } = typeForIndustry(industry);

    const doc = { '@context': 'https://schema.org', '@type': type, name: name };

    // Passed in already normalised by utils.metaFromBusiness so the graph and the og: tags agree.
    if (o.url) doc.url = o.url;

    const description = String(b.description || b.tagline || '').trim();
    if (description) doc.description = description;

    const slogan = String(b.tagline || '').trim();
    if (slogan && slogan !== description) doc.slogan = slogan;

    if (o.image) doc.image = o.image;

    const telephone = firstNonEmpty(b.phones, (p) => p.number);
    if (telephone) doc.telephone = telephone;

    const email = String(b.email || '').trim();
    if (email) doc.email = email;

    // The Address field accepts either a street address or a service-area phrase, and schema.org
    // permits address as plain Text, so it passes through as typed rather than being forced into a
    // PostalAddress whose sub-fields this app never collects.
    const address = String(b.address || '').trim();
    if (address) doc.address = address;

    if (local) {
      const hours = parseOpeningHours(b.hours);
      if (hours) doc.openingHours = hours;
    }

    const sameAs = (b.socialLinks || []).map((l) => String(l.url || '').trim()).filter(Boolean);
    if (sameAs.length) doc.sameAs = sameAs;

    const awards = (b.awards || []).map((a) => String(a.name || '').trim()).filter(Boolean);
    if (awards.length) doc.award = awards;

    return doc;
  }

  // Escaping "<" is what keeps a "</script>" inside any business field from closing the block early;
  // < is still valid JSON, so parsers read it back as the original character.
  function buildJsonLdScript(business, opts) {
    const doc = buildJsonLd(business, opts);
    if (!doc) return '';
    const json = JSON.stringify(doc, null, 2).replace(/</g, '\\u003c');
    return `<script type="application/ld+json">\n${json}\n</script>`;
  }

  App.structuredData = { buildJsonLd, buildJsonLdScript, parseOpeningHours, typeForIndustry };
})(window.App);
