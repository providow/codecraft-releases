#!/usr/bin/env node
/* CodeCraft dev server: static file server + POST /api/chat proxy to the Anthropic API.
   Zero npm dependencies — Node built-ins only. */
'use strict';

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');

const ROOT = __dirname;
const PORT = process.env.PORT || 5173;

function loadEnvFile() {
  const envPath = path.join(ROOT, '.env');
  if (!fs.existsSync(envPath)) return;
  const content = fs.readFileSync(envPath, 'utf8');
  content.split('\n').forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return;
    const eq = trimmed.indexOf('=');
    if (eq === -1) return;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  });
}
loadEnvFile();

/* ---------- Settings ----------
   The API key used to be a module-level const read once at boot, which meant the only way to
   change it was editing .env and restarting. CodeCraft is moving to bring-your-own-key, so the
   key has to be settable at runtime from the Account tab and read fresh on every request.

   Precedence is stored-then-env, deliberately. If an operator sets ANTHROPIC_API_KEY in the
   environment it acts as the default, but whatever the user saves in the Account tab wins --
   otherwise someone would paste their key into the UI, see nothing change, and have no way to
   tell why. getKeySource() exists so the UI can always say which one is actually in use.

   Settings live in data/settings.json, outside the static allowlist in serveStatic(), so the
   key is never reachable over HTTP the way .env once was. */
/* Everything the customer owns lives OUTSIDE the app folder, so updating is "delete the old
   folder, unzip the new one" with nothing to preserve by hand. When data sat in ./data and
   ./uploads, an update either destroyed it or required a page of instructions explaining how not
   to. CODECRAFT_DATA_DIR overrides the location, which keeps a developer checkout pointing at its
   own folder. */
function resolveDataDir() {
  const override = (process.env.CODECRAFT_DATA_DIR || '').trim();
  if (override) return path.resolve(override);
  if (process.platform === 'win32' && process.env.APPDATA) {
    return path.join(process.env.APPDATA, 'CodeCraft');
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'CodeCraft');
  }
  const xdg = (process.env.XDG_DATA_HOME || '').trim();
  if (xdg) return path.join(xdg, 'codecraft');
  return path.join(os.homedir(), '.local', 'share', 'codecraft');
}

const DATA_DIR = resolveDataDir();

/* One-time lift for anyone upgrading from a build that kept data inside the app folder. The old
   copy is left where it is rather than moved: if anything here goes wrong the customer still has
   their only copy, and it disappears on its own when they replace the folder. */
function migrateLegacyData() {
  const pairs = [
    [path.join(ROOT, 'data'), DATA_DIR],
    [path.join(ROOT, 'uploads'), path.join(DATA_DIR, 'uploads')]
  ];
  for (const [from, to] of pairs) {
    try {
      if (!fs.existsSync(from) || fs.existsSync(to)) continue;
      if (!fs.readdirSync(from).length) continue;
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.cpSync(from, to, { recursive: true });
      console.log('  Copied your existing files to ' + to);
      console.log('  The originals are untouched in the app folder until you delete it.');
    } catch (e) {
      console.error('  Could not copy ' + from + ' to ' + to + ': ' + e.message);
      console.error('  Copy that folder across by hand before generating anything.');
    }
  }
}
migrateLegacyData();
const SETTINGS_PATH = path.join(DATA_DIR, 'settings.json');

const ENV_API_KEY = process.env.ANTHROPIC_API_KEY || '';
const ENV_MODEL = process.env.ANTHROPIC_MODEL || '';
const DEFAULT_MODEL = 'claude-opus-5';

/* ---------- Licensing ----------
   CodeCraft is sold once, not by subscription. A key is a signed blob: the buyer's name, email
   and order id, signed with a private key that stays on the seller's machine. Only the public
   half ships, so a key cannot be minted without the private key -- forging one is not feasible.

   What this deliberately does NOT try to do is stop someone editing the check out of this file.
   That is unavoidable in software people download and run, and hardening against it costs real
   usability (machine locking, phone-home, obfuscation) to deter people who were never going to
   pay. The goal is that buying is easier than not buying.

   Trial: three full funnel generations, then only NEW funnel generation stops. Everything
   already made keeps working -- editing, revising, exporting, backups. Users burn their own
   Anthropic credit (~$1.36 a funnel), so a generous trial costs the seller nothing. */
const LICENSE_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAFp0sBAx96Ay+fg5Ex2mvXLhnHphIrghva4+t7tPEu10=
-----END PUBLIC KEY-----`;

const TRIAL_FUNNEL_LIMIT = 3;

/* ---------- Diagnostics ----------
   A support email that arrives with "it doesn't work" costs a round trip to answer. This collects
   the handful of facts that actually narrow a problem down.

   What it deliberately never includes: the API key (only which SOURCE is in use and a short
   fingerprint), and anything from the user's businesses, funnels or copy -- counts only. Client
   work never leaving the machine is the product's promise, and a diagnostics blob that quietly
   scooped up business details would break it in the one place a user is most likely to paste
   the output somewhere public. */
const SUPPORT_EMAIL = 'support@gohighlevelstore.net';
const APP_VERSION = (() => {
  try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version || 'unknown'; }
  catch (e) { return 'unknown'; }
})();

const MAX_RECENT_ERRORS = 10;
const recentErrors = [];

function noteError(context, message) {
  recentErrors.unshift({
    at: new Date().toISOString(),
    context: String(context || 'unknown').slice(0, 80),
    message: String(message || '').slice(0, 300)
  });
  if (recentErrors.length > MAX_RECENT_ERRORS) recentErrors.length = MAX_RECENT_ERRORS;
}

// A fingerprint identifies WHICH key is in play across a support thread without revealing it.
function keyFingerprint(k) {
  if (!k) return '';
  return crypto.createHash('sha256').update(k).digest('hex').slice(0, 8);
}

/* ---------- Update checking ----------

   A copy of CodeCraft asks this URL what the newest version is. The answer is signed with the same
   ed25519 key that signs licences, and verified against the public key compiled in below, so
   nobody who controls the network or the hosting can point a customer at a zip of their choosing.

   The signed payload is prefixed, so a licence key can never be replayed as a release manifest or
   the other way round. Nothing is downloaded or installed here -- this only reports what exists. */
const UPDATE_MANIFEST_URL = (process.env.CODECRAFT_UPDATE_URL || '').trim()
  || 'https://raw.githubusercontent.com/providow/codecraft-releases/main/latest.json';
/* Transport security is belt and braces here: the signature is the real defence, which is why a
   plain-http source is tolerated when someone has deliberately pointed this somewhere else for
   testing. The shipped default is https and a tampered payload is refused either way. */
const UPDATE_INSECURE_OK = !!(process.env.CODECRAFT_UPDATE_URL || '').trim();
const MAX_UPDATE_BYTES = 50 * 1024 * 1024;
const RELEASE_PREFIX = 'codecraft-release-v1:';
const UPDATE_CHECK_TIMEOUT_MS = 8000;

function verifyReleaseManifest(raw) {
  let outer;
  try { outer = JSON.parse(raw); } catch (e) { return null; }
  if (!outer || typeof outer.body !== 'string' || typeof outer.signature !== 'string') return null;
  try {
    const ok = crypto.verify(
      null,
      Buffer.from(RELEASE_PREFIX + outer.body),
      crypto.createPublicKey(LICENSE_PUBLIC_KEY),
      Buffer.from(outer.signature, 'base64url')
    );
    if (!ok) return null;
    const p = JSON.parse(Buffer.from(outer.body, 'base64url').toString('utf8'));
    if (!p || typeof p !== 'object') return null;
    if (!/^\d+\.\d+\.\d+$/.test(String(p.version || ''))) return null;
    const scheme = UPDATE_INSECURE_OK ? /^https?:\/\//i : /^https:\/\//i;
    if (!scheme.test(String(p.url || ''))) return null;
    if (!/^[0-9a-f]{64}$/i.test(String(p.sha256 || ''))) return null;
    return p;
  } catch (e) {
    return null;
  }
}

// 1.10.0 is newer than 1.9.0, which a string comparison gets wrong.
function isNewerVersion(candidate, current) {
  const a = String(candidate).split('.').map(Number);
  const b = String(current).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((a[i] || 0) > (b[i] || 0)) return true;
    if ((a[i] || 0) < (b[i] || 0)) return false;
  }
  return false;
}

/* Follows redirects, which matters more than it looks: the manifest URL is compiled into every
   copy that ships and can never be changed for copies already in the wild, because telling them a
   new address would require the old one to work. A redirect is the only way to move the hosting
   later without stranding everyone. Capped, and a redirect that tries to drop from https to plain
   http is refused rather than followed. */
function httpGetFollow(url, timeoutMs, hops) {
  return new Promise((resolve, reject) => {
    if ((hops || 0) > 5) { reject(new Error('Too many redirects')); return; }
    let settled = false;
    const done = (fn, v) => { if (!settled) { settled = true; fn(v); } };
    const mod = /^http:\/\//i.test(url) ? http : https;
    const req = mod.get(url, { headers: { 'user-agent': 'CodeCraft/' + APP_VERSION } }, (res) => {
      const code = res.statusCode;
      const location = res.headers && res.headers.location;
      if ([301, 302, 303, 307, 308].indexOf(code) !== -1 && location) {
        res.resume();
        let next;
        try { next = new URL(location, url).toString(); } catch (e) { done(reject, new Error('Bad redirect')); return; }
        if (!UPDATE_INSECURE_OK && !/^https:\/\//i.test(next)) {
          done(reject, new Error('Refused a redirect away from https'));
          return;
        }
        done(resolve, httpGetFollow(next, timeoutMs, (hops || 0) + 1));
        return;
      }
      if (code !== 200) {
        res.resume();
        done(reject, new Error('HTTP ' + code));
        return;
      }
      done(resolve, res);
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); done(reject, new Error('Timed out')); });
    req.on('error', (e) => done(reject, e));
  });
}

async function fetchText(url, timeoutMs) {
  const res = await httpGetFollow(url, timeoutMs, 0);
  return new Promise((resolve, reject) => {
    let body = '';
    let size = 0;
    res.setEncoding('utf8');
    res.on('data', (c) => {
      size += c.length;
      if (size > 64 * 1024) { res.destroy(); reject(new Error('Manifest is implausibly large')); return; }
      body += c;
    });
    res.on('end', () => resolve(body));
    res.on('error', reject);
  });
}

async function handleUpdateCheck(req, res) {
  const reply = (code, obj) => {
    res.writeHead(code, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(obj));
  };
  let raw;
  try {
    raw = await fetchText(UPDATE_MANIFEST_URL, UPDATE_CHECK_TIMEOUT_MS);
  } catch (e) {
    // Being offline is not an error worth alarming anyone about.
    reply(200, { checked: false, reason: 'Could not reach the update server. ' + e.message,
                 current: APP_VERSION });
    return;
  }
  const p = verifyReleaseManifest(raw);
  if (!p) {
    reply(200, { checked: false, reason: 'The update information was not signed correctly, so it was ignored.',
                 current: APP_VERSION });
    return;
  }
  reply(200, {
    checked: true,
    current: APP_VERSION,
    latest: p.version,
    available: isNewerVersion(p.version, APP_VERSION),
    notes: typeof p.notes === 'string' ? p.notes.slice(0, 2000) : '',
    bytes: Number(p.bytes) || 0,
    releasedAt: Number(p.releasedAt) || 0
  });
}

async function fetchBinary(url, timeoutMs) {
  const res = await httpGetFollow(url, timeoutMs, 0);
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    res.on('data', (c) => {
      size += c.length;
      if (size > MAX_UPDATE_BYTES) { res.destroy(); reject(new Error('Download is far larger than a CodeCraft release should be')); return; }
      chunks.push(c);
    });
    res.on('end', () => resolve(Buffer.concat(chunks)));
    res.on('error', reject);
  });
}

/* Unzipping with no dependencies. tar has shipped with Windows since 10 1803 and is standard on
   macOS and Linux, and it reads zip files. If it is missing we stop rather than guess. */
function unzip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    /* tar reads an archive path containing a colon as [user@]host:path, so an absolute Windows
       path like C:\Users\... is treated as a remote machine and fails with "cannot connect".
       Running from the file's own directory and naming it relatively avoids that. The -C
       destination is not parsed that way, so it can stay absolute. */
    execFile('tar', ['-xf', path.basename(zipPath), '-C', destDir],
             { cwd: path.dirname(zipPath), timeout: 120000 }, (err) => {
      if (err) {
        reject(new Error('Could not unpack the download. ' + (err.code === 'ENOENT'
          ? 'The tar command is not available on this machine, so CodeCraft cannot unpack updates automatically.'
          : err.message)));
        return;
      }
      resolve();
    });
  });
}

/* Find the folder inside the extracted zip that actually holds the app, and refuse anything that
   does not look like CodeCraft. This is the last line before we start overwriting files. */
function locateReleaseRoot(dir, expectedVersion) {
  const candidates = [dir].concat(
    fs.readdirSync(dir, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => path.join(dir, e.name))
  );
  for (const c of candidates) {
    const pkgPath = path.join(c, 'package.json');
    if (!fs.existsSync(pkgPath) || !fs.existsSync(path.join(c, 'server.js'))) continue;
    if (!fs.existsSync(path.join(c, 'index.html'))) continue;
    let pkg;
    try { pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8')); } catch (e) { continue; }
    if (pkg.name !== 'codecraft') continue;
    if (String(pkg.version) !== String(expectedVersion)) {
      throw new Error('The download says it is version ' + pkg.version + ' but the update was announced as '
        + expectedVersion + '. Nothing has been changed.');
    }
    return c;
  }
  throw new Error('The download does not look like CodeCraft. Nothing has been changed.');
}

/* .env is the customer's, not ours: it holds their API key if they put it there rather than in
   the Account tab, and the release ships a blank one. Everything else in the release is ours to
   replace, and the list comes from the release itself so a version that adds a file delivers it. */
const CUSTOMER_OWNED = new Set(['.env']);

/* Set once an update has been written to disk. The running process still reports the old version,
   because APP_VERSION was read from package.json at startup, so without this a second click would
   cheerfully download and install the same release again. */
let installedAwaitingRestart = null;

async function handleUpdateApply(req, res) {
  const reply = (code, obj) => {
    res.writeHead(code, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(obj));
  };

  let manifest;
  try {
    manifest = verifyReleaseManifest(await fetchText(UPDATE_MANIFEST_URL, UPDATE_CHECK_TIMEOUT_MS));
  } catch (e) {
    reply(502, { error: 'Could not reach the update server. ' + e.message });
    return;
  }
  if (!manifest) {
    reply(502, { error: 'The update information was not signed correctly, so nothing was installed.' });
    return;
  }
  if (installedAwaitingRestart) {
    reply(400, { error: 'Version ' + installedAwaitingRestart
      + ' is already installed. Stop CodeCraft and start it again to use it.' });
    return;
  }
  if (!isNewerVersion(manifest.version, APP_VERSION)) {
    reply(400, { error: 'You already have version ' + APP_VERSION + '.' });
    return;
  }

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'codecraft-update-'));
  const backupDir = path.join(DATA_DIR, 'previous-version-' + APP_VERSION);
  try {
    const zip = await fetchBinary(manifest.url, 120000);

    const got = crypto.createHash('sha256').update(zip).digest('hex');
    if (got.toLowerCase() !== String(manifest.sha256).toLowerCase()) {
      throw new Error('The download did not match the signed fingerprint, so it was discarded. Nothing has been changed.');
    }

    const zipPath = path.join(tmp, 'release.zip');
    fs.writeFileSync(zipPath, zip);
    const extractDir = path.join(tmp, 'x');
    fs.mkdirSync(extractDir, { recursive: true });
    await unzip(zipPath, extractDir);

    const releaseRoot = locateReleaseRoot(extractDir, manifest.version);

    /* Keep the whole current app before touching anything, in the data directory so it survives
       whatever happens next. Small enough that copying it costs nothing. */
    const releaseEntries = fs.readdirSync(releaseRoot).filter((n) => !CUSTOMER_OWNED.has(n));
    if (!releaseEntries.length) throw new Error('The download was empty. Nothing has been changed.');

    fs.rmSync(backupDir, { recursive: true, force: true });
    fs.mkdirSync(backupDir, { recursive: true });
    // Back up only what is about to be overwritten. Backing up the whole folder would sweep up
    // unrelated files in a developer checkout.
    for (const entry of releaseEntries) {
      const from = path.join(ROOT, entry);
      if (fs.existsSync(from)) fs.cpSync(from, path.join(backupDir, entry), { recursive: true });
    }

    try {
      for (const entry of releaseEntries) {
        const from = path.join(releaseRoot, entry);
        if (!fs.existsSync(from)) continue;
        const to = path.join(ROOT, entry);
        fs.rmSync(to, { recursive: true, force: true });
        fs.cpSync(from, to, { recursive: true });
      }
    } catch (swapErr) {
      // Put back what we replaced, so a half-finished update cannot leave a broken install.
      for (const entry of releaseEntries) {
        const from = path.join(backupDir, entry);
        if (!fs.existsSync(from)) continue;
        try {
          const to = path.join(ROOT, entry);
          fs.rmSync(to, { recursive: true, force: true });
          fs.cpSync(from, to, { recursive: true });
        } catch (e) { /* keep restoring the rest */ }
      }
      throw new Error('Installing failed and the previous version was put back. ' + swapErr.message);
    }

    installedAwaitingRestart = manifest.version;
    reply(200, {
      ok: true,
      version: manifest.version,
      previous: APP_VERSION,
      backupDir,
      message: 'Version ' + manifest.version + ' is installed. Stop CodeCraft and start it again to use it.'
    });
  } catch (e) {
    reply(500, { error: e.message });
  } finally {
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) { /* temp dir, not worth reporting */ }
  }
}

function verifyLicense(key) {
  if (typeof key !== 'string' || key.indexOf('.') === -1) return null;
  const dot = key.indexOf('.');
  const body = key.slice(0, dot);
  const sig = key.slice(dot + 1);
  if (!body || !sig) return null;
  try {
    const ok = crypto.verify(
      null,
      Buffer.from(body),
      crypto.createPublicKey(LICENSE_PUBLIC_KEY),
      Buffer.from(sig, 'base64url')
    );
    if (!ok) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload || typeof payload !== 'object' || !payload.e) return null;
    return payload;
  } catch (e) {
    return null;
  }
}

// Always re-verify the stored key rather than trusting a stored "licensed: true" flag -- the
// signature is the only thing that means anything.
function getLicense() {
  return verifyLicense(storedSettings.license);
}

function getTrialUsed() {
  const n = Number(storedSettings.trialUsed);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
}

function noteTrialFunnel() {
  if (getLicense()) return;
  try {
    writeSettings(Object.assign({}, storedSettings, { trialUsed: getTrialUsed() + 1 }));
  } catch (e) {
    console.error('Could not record trial usage:', e.message);
  }
}

function licenseState() {
  const lic = getLicense();
  const used = getTrialUsed();
  return {
    licensed: !!lic,
    name: lic ? lic.n || '' : '',
    email: lic ? lic.e || '' : '',
    order: lic ? lic.o || '' : '',
    issuedAt: lic ? lic.t || null : null,
    trialUsed: used,
    trialLimit: TRIAL_FUNNEL_LIMIT,
    trialRemaining: Math.max(0, TRIAL_FUNNEL_LIMIT - used)
  };
}

// Models the Account tab offers, with list prices so the UI can show what a choice costs.
const AVAILABLE_MODELS = [
  { id: 'claude-opus-5', label: 'Claude Opus 5', inputPerM: 5, outputPerM: 25, note: 'Best output. The default -- highest quality funnels.' },
  { id: 'claude-sonnet-5', label: 'Claude Sonnet 5', inputPerM: 3, outputPerM: 15, note: 'Faster and cheaper. Good output, less nuance.' },
  { id: 'claude-haiku-4-5', label: 'Claude Haiku 4.5', inputPerM: 1, outputPerM: 5, note: 'Cheapest and fastest. Not recommended for full funnels.' }
];

function readSettings() {
  try {
    const parsed = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (e) {
    return {};
  }
}

let storedSettings = readSettings();

function writeSettings(next) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(next, null, 2));
  storedSettings = next;
}

function getApiKey() {
  return storedSettings.apiKey || ENV_API_KEY;
}

function getModel() {
  const m = storedSettings.model || ENV_MODEL || DEFAULT_MODEL;
  return AVAILABLE_MODELS.some((x) => x.id === m) ? m : DEFAULT_MODEL;
}

function getKeySource() {
  if (storedSettings.apiKey) return 'account';
  if (ENV_API_KEY) return 'env';
  return 'none';
}

// Never send a whole key back to the browser -- enough to recognise which key is saved, no more.
function maskKey(k) {
  if (!k) return '';
  if (k.length <= 12) return '****';
  return k.slice(0, 8) + '\u2026' + k.slice(-4);
}
const MOCK_AI = process.env.MOCK_AI === '1';
// Two limits, because they catch different failures. The connect timeout is short: if the TCP
// connection to api.anthropic.com never establishes, that is a dead network, not slow thinking.
// The overall timeout has to be generous -- the AI Funnel calls run non-streaming at
// max_tokens 64000, and nothing comes back over the wire until the whole response is built, so a
// legitimate generation can occupy several minutes of total silence.
const ANTHROPIC_CONNECT_TIMEOUT_MS = Number(process.env.ANTHROPIC_CONNECT_TIMEOUT_MS) || 15000;
const ANTHROPIC_TIMEOUT_MS = Number(process.env.ANTHROPIC_TIMEOUT_MS) || 600000;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};

// The project root holds things that must never be reachable over HTTP: .env (the API key),
// server.js (which carries the generation prompts), the package files, and .claude/. The
// traversal guard below does not help with those -- they live inside ROOT, so a plain
// GET /.env used to return them with a 200. This is an allowlist rather than a blocklist so
// that anything new dropped into the project root is private by default.
const SERVABLE_FILES = new Set(['index.html']);
const SERVABLE_DIRS = ['css', 'js', 'uploads', 'brand'];

function isServablePath(relPath) {
  if (!relPath || relPath.startsWith('..')) return false;
  const parts = relPath.split('/');
  // No dotfiles or dot-directories at any depth (.env, .env.example, .claude/, .impeccable/).
  if (parts.some((seg) => seg === '' || seg.startsWith('.'))) return false;
  if (parts.length === 1) return SERVABLE_FILES.has(parts[0]);
  if (!SERVABLE_DIRS.includes(parts[0])) return false;
  // The uploads manifests are read server-side only (readManifest uses fs, never HTTP). Serving
  // them would let anyone enumerate a business's uploaded filenames, which frequently carry real
  // client names -- so the images stay reachable by URL but the index of them does not.
  if (parts[0] === 'uploads' && parts[parts.length - 1] === 'manifest.json') return false;
  return true;
}

function serveStatic(req, res) {
  let urlPath;
  try {
    urlPath = decodeURIComponent(req.url.split('?')[0]);
  } catch (e) {
    res.writeHead(400);
    res.end('Bad request');
    return;
  }
  if (urlPath === '/') urlPath = '/index.html';
  // Browsers ask for /favicon.ico at the root on their own, whatever the <link> tags say.
  // Without this it is a 404 in every customer's console on every page load.
  if (urlPath === '/favicon.ico') urlPath = '/brand/favicon.ico';
  /* Client photographs live in the data directory now, not under the app folder, so they cannot be
     resolved against ROOT like the rest of the static files. The path check below still runs
     against the URL, so the traversal and dotfile rules are unchanged. */
  const uploadsPrefix = '/uploads/';
  if (urlPath.startsWith(uploadsPrefix)) {
    const relUpload = urlPath.slice(uploadsPrefix.length);
    if (relUpload.includes('..') || relUpload.split('/').some((seg) => !seg || seg.startsWith('.'))) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    if (path.basename(relUpload) === 'manifest.json') {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    const uploadPath = path.normalize(path.join(UPLOADS_DIR, relUpload));
    if (!uploadPath.startsWith(path.normalize(UPLOADS_DIR))) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }
    fs.readFile(uploadPath, (err, data) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': MIME_TYPES[path.extname(uploadPath).toLowerCase()] || 'application/octet-stream' });
      res.end(data);
    });
    return;
  }
  const resolved = path.normalize(path.join(ROOT, urlPath));
  if (!resolved.startsWith(ROOT)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }
  const rel = path.relative(ROOT, resolved).split(path.sep).join('/');
  if (!isServablePath(rel)) {
    // 404 rather than 403 -- do not confirm whether a private file exists.
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
    return;
  }
  fs.readFile(resolved, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    const ext = path.extname(resolved).toLowerCase();
    /* The app's own files must never come from the browser's cache. Without this a customer who
       installs an update keeps being shown the OLD app until they think to hard-refresh, which
       they will not -- it just reads as "the update did not install". The app is served from
       localhost, so re-reading these few files costs nothing worth measuring. Images are left
       cacheable on purpose: they are the heavy part of a page and are not what goes stale. */
    const headers = { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' };
    if (ext === '.html' || ext === '.js' || ext === '.css') {
      headers['Cache-Control'] = 'no-store';
    }
    res.writeHead(200, headers);
    res.end(data);
  });
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let done = false;
    const chunks = [];
    req.on('data', (chunk) => {
      if (done) return;
      size += chunk.length;
      if (size > limit) {
        done = true;
        // Deliberately no req.destroy() here -- destroying the socket at this point kills the
        // connection before the handler can write its 413, so the client just sees a dropped
        // request. Pause instead; endWithBodyError closes the socket once the reply has flushed.
        req.pause();
        reject(new Error('Request body too large'));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => { if (!done) { done = true; resolve(Buffer.concat(chunks).toString('utf8')); } });
    req.on('error', (e) => { if (!done) { done = true; reject(e); } });
  });
}

// readBody rejects on two things: a body over the limit, and the client aborting or the connection
// erroring mid-upload. Every caller must catch it -- an uncaught rejection from an async handler is
// fatal on Node >= 15 and takes the whole server down.
function endWithBodyError(req, res, e, tooLargeMessage) {
  const tooLarge = /too large/i.test((e && e.message) || '');
  if (res.headersSent || res.destroyed) { req.destroy(); return; }
  res.writeHead(tooLarge ? 413 : 400, {
    'Content-Type': 'application/json',
    'Connection': 'close'
  });
  const message = tooLarge
    ? (tooLargeMessage || 'Request body too large.')
    : 'Could not read the request body.';
  // Close the socket only after the reply is on the wire, so a client mid-upload stops sending
  // but still gets a real status code back instead of a dropped connection.
  res.end(JSON.stringify({ error: message }), () => { req.destroy(); });
}

const CHAT_SCHEMA = {
  type: 'object',
  properties: {
    reply: { type: 'string' },
    profile: {
      type: 'object',
      properties: {
        businessName: { type: 'string' },
        industry: { type: 'string' },
        offer: { type: 'string' },
        brandColors: { type: 'string' },
        goal: { type: 'string' },
        tone: { type: 'string' }
      },
      required: ['businessName', 'industry', 'offer', 'brandColors', 'goal', 'tone'],
      additionalProperties: false
    }
  },
  required: ['reply', 'profile'],
  additionalProperties: false
};

const CHAT_SYSTEM_PROMPT = `You are a friendly funnel-building assistant embedded in a landing-page design tool called CodeCraft. Have a natural conversation with a web designer to learn about their client's business, so you can later build a complete funnel automatically.

Ask about, one or two things at a time, conversationally (not a rigid form):
- Business name
- Industry / what they do
- Main product or service offer
- Brand colors (if they have any in mind)
- The goal of this funnel (e.g. get leads, sell a product, book calls)
- Desired tone/style (e.g. playful, premium, minimal, bold)

Only ask about fields still missing. Accept multi-field answers in one message. Keep replies short and conversational -- 1-3 sentences plus at most one follow-up question. Once you have enough to build a good funnel (most fields filled), tell the user they can click "Generate Funnel" whenever they're ready.

Every turn, respond with the "profile" object reflecting everything you know so far (cumulative -- carry forward previously known fields, fill in what changed). Use an empty string "" for any field you don't know yet.`;

/* ---------- Design Commitment ----------

   One small call whose only job is to commit to a look, run before the page is written. The
   reason it is separate: a call that also invents structure and writes copy optimises for internal
   coherence and quietly averages every decision into something safe. A call that can only choose
   colours, a rhythm and one gesture has to actually choose.

   Its output is a contract. The generation prompt receives it as instructions it may not deviate
   from, and the numbers below are checked here rather than hoped for. */

function hexToRgb(hex) {
  const h = String(hex).replace('#', '');
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
}

function relLuminance(hex) {
  const [r, g, b] = hexToRgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contrastRatio(a, b) {
  const l1 = relLuminance(a);
  const l2 = relLuminance(b);
  const hi = Math.max(l1, l2);
  const lo = Math.min(l1, l2);
  return (hi + 0.05) / (lo + 0.05);
}

// Rough perceptual distance. Good enough to answer "would anyone see the difference".
function colourDistance(a, b) {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  const rm = (r1 + r2) / 2;
  return Math.sqrt((2 + rm / 256) * Math.pow(r1 - r2, 2)
    + 4 * Math.pow(g1 - g2, 2)
    + (2 + (255 - rm) / 256) * Math.pow(b1 - b2, 2));
}

const SIGNATURE_MOVES = ['oversized_numerals', 'hard_offset_shadow', 'accent_underline',
  'outlined_type', 'asymmetric_split', 'bordered_blocks', 'accent_bracket', 'mono_eyebrow'];

const SIGNATURE_MOVE_TEXT = {
  oversized_numerals: 'Render numbers -- stats, step numbers, counts, prices -- enormously larger than anything around them.',
  hard_offset_shadow: 'Flat hard-edged offset shadows with no blur, as the page\'s main way of lifting an element.',
  accent_underline: 'A thick accent-coloured rule sitting under key phrases and headings.',
  outlined_type: 'Display headings drawn as outlined/stroked letterforms rather than solid fills.',
  asymmetric_split: 'Deliberate off-centre splits, roughly 40/60, wherever a section has two parts.',
  bordered_blocks: 'Heavy 2 to 3px borders as the primary structural device across the page.',
  accent_bracket: 'Corner brackets in the accent colour framing the page\'s most important blocks.',
  mono_eyebrow: 'A small letterspaced uppercase monospace label above every major heading.'
};

/* SIGNATURE_MOVE_TEXT above says what each move LOOKS like. That is all the page builder needs, but
   it is useless for choosing one: a menu of techniques with no notion of fit just gets the safest
   item picked every time. Banning the current favourite only promotes the next one (numerals went
   from 3-of-3 to 0-of-8 that way, which is its own distortion). So each move also carries when it is
   RIGHT and when it is WRONG, and selection becomes a match rather than a pick. This is only used
   when deciding; it is deliberately not part of the contract handed to the builder. */
const SIGNATURE_MOVE_FIT = {
  oversized_numerals:
    'Right when the argument itself is a quantity someone would repeat out loud -- a fixed price, a count that proves consistency or scarcity, a timescale that IS the offer. Wrong when the numbers are incidental furniture like a founding year or a vague client count. A number earns the size only if removing it would weaken the argument.',
  hard_offset_shadow:
    'Right when the trade is graphic and printed -- screen printing, records, skate and bike shops, zines, street food, anything whose real world contains stickers and flyposting. Wrong when the business sells calm or precision: on a clinic or an accountant a hard shadow reads as a sticker slapped onto a form.',
  accent_underline:
    'Right when the promise is a sentence -- a guarantee, a fixed fee, a plain claim you want the eye to land on and remember. Wrong when the page argues through objects and photographs rather than claims, because then there is nothing to underline and the rule becomes decoration.',
  outlined_type:
    'Right when the business is loud, physical and event-shaped -- classes, fight nights, festivals, late bars, anything sold on atmosphere. Wrong when the reader is anxious or skeptical and needs to read fast, because hollow letterforms trade legibility for attitude.',
  asymmetric_split:
    'Right when the business constantly holds two things in tension -- before and after, the work and the maker, the problem and the fix. Wrong when the content is mostly a straight list, where an off-centre split is just a wonky column.',
  bordered_blocks:
    'Right when the business is about containment and record -- a parts list, a ledger, a docket, a schedule, a menu, anything that in real life arrives ruled off into boxes. Wrong when the page should breathe, or when the business is selling softness.',
  accent_bracket:
    'Right when the business frames, protects or certifies something -- surveys, inspections, insurance, restoration, framing, legal work. Wrong as general decoration: if the brackets are not pointing at evidence they are just corners.',
  mono_eyebrow:
    'Right when the business is spec-driven and technical -- trades, engineering, coaching with a written programme, anywhere knowing exactly where you are matters. Wrong when warmth is the point, because a monospace label above a florist\'s heading reads like a parts catalogue. Note that it is the easiest of all eight to justify for almost any business, which makes it the one most often chosen out of caution rather than fit.'
};


/* The page builder was already ALLOWED soft corners, ambient shadows and inline SVG icons -- the
   doctrine offers all three explicitly and even instructs the icons. Measured across 64 generated
   sections it used none of them: zero icons, zero ambient shadows, and a largest border-radius of
   2px. Permission is not instruction. Every dimension left free has defaulted to the most restrained
   option available, exactly as colour and the signature move did before they were made decisions.
   So shape and component vocabulary become committed decisions too, checked in code afterwards. */


/* Measured across 65 generated sections: 100% flat colour fills, zero repeating gradients, zero
   radial washes, zero SVG pattern backgrounds, zero clip-path fields, and zero REAL gradients -- the
   only gradients found were linear-gradient(x, x), the same colour twice, used as a trick to draw an
   underline. The section rhythm already decides which COLOUR each background is; nothing ever asked
   what is ON it. So the background treatment becomes a decision like the rest. */


/* The shape language decided corners, shadow and icons but never FILL, so every button and card the
   generator has ever made is a flat colour. Gradients are not banned by the doctrine -- it bans the
   weightless pastel SaaS wash and using a gradient to fake a photograph, which are different things.
   A gradient CTA is entirely legitimate; it had simply never been a decision. */
const FILL_LANGUAGES = ['solid', 'gradient', 'outline', 'duotone'];
const FILL_TEXT = {
  solid: 'Flat colour fills on buttons, cards and panels. Correct when the palette is doing the work and the business is plain-spoken; it is also what gets produced when nobody decides, so choose it on purpose.',
  gradient: 'The primary call to action, and at most one or two key panels, filled with a genuine two-colour gradient between colours ALREADY committed above -- the accent into a deepened version of itself, or canvas into canvasAlt. Rich and current when the two colours are close relatives. The pastel purple-into-blue wash is the exception that reads as a page nobody designed; never that.',
  outline: 'Buttons and cards drawn as boxes: transparent fill, a confident border in the accent or ink, the label carrying the weight. Belongs to technical, industrial and editorial registers where a filled blob would look soft.',
  duotone: 'Two-tone fills -- a card split between surface and surfaceAlt, or a button whose hover state flips to the opposite tone. Graphic and deliberate; it needs the two tones to be genuinely different or it reads as a mistake.'
};

const BACKGROUND_TREATMENTS = ['flat', 'dot_grid', 'rule_grid', 'diagonal_field', 'edge_wash',
  'gradient_field', 'ghost_letterform', 'trade_motif'];

const BACKGROUND_TEXT = {
  flat: 'Plain colour fields, nothing behind the content. A real choice when the business is austere and the type is doing all the work -- a law firm, a letterpress studio, a funeral director. It is also what gets produced when nobody decides, so choose it deliberately or not at all.',
  dot_grid: 'A quiet grid of dots tiled behind a section, drawn with a repeating radial-gradient and a background-size. Reads as workshop, drawing board, engineering paper. Keep it faint enough to sit under text without fighting it.',
  rule_grid: 'Hairline graph-paper ruling, drawn with repeating-linear-gradient in both directions. Belongs to ledgers, plans, schedules, architecture, anything measured or recorded.',
  diagonal_field: 'An angled band or diagonal stripes, from clip-path or a repeating-linear-gradient at an angle. Industrial and directional -- haulage, plant hire, scaffolding, anything that moves or warns.',
  edge_wash: 'A soft radial or linear bloom of one palette colour creeping in from an edge or a corner, with no hard boundary. Warm and atmospheric; suits domestic, hospitality and care businesses.',
  gradient_field: 'A genuine two-colour gradient across a whole section, interpolating between two colours ALREADY in the committed palette -- canvas into canvasAlt, or a section into a deepened accent. Rich and modern when the two colours are close relatives, cheap the moment they are not.',
  ghost_letterform: 'One oversized word, numeral or initial set enormous at very low opacity behind the content, usually bleeding off an edge. Editorial and confident; the word must be a real word from this business, never a decorative squiggle.',
  trade_motif: 'A small shape drawn from the trade itself, tiled quietly as an SVG background -- a tooth, a spanner, a leaf, a loaf, a bolt. Charming when the motif is genuinely the trade\'s own object, twee when it is a generic star or blob.'
};

const RADIUS_LANGUAGES = ['sharp', 'tight', 'soft', 'pill'];
const RADIUS_TEXT = {
  sharp: 'Square corners, 0 to 2px. Right for trades, industry, editorial, anything that wants to read as built rather than designed.',
  tight: 'A restrained 6 to 8px on cards, buttons and inputs. The quiet default when the business is neither hard-edged nor soft.',
  soft: 'A generous 12 to 16px everywhere. Right when the business itself is soft, warm, domestic or aimed at families and children.',
  pill: 'Fully rounded ends on buttons and badges, with cards kept tighter. Right when the business is friendly, consumer-facing and informal.'
};

const SHADOW_LANGUAGES = ['none', 'soft_ambient', 'hard_offset'];
const SHADOW_TEXT = {
  none: 'No shadows at all; separation comes from borders, rules and background changes. The most restrained option and the one to justify hardest, because it is where this generator drifts by default.',
  soft_ambient: 'One soft ambient shadow, low opacity and generous blur, reused with identical values everywhere depth is needed. Reads as considered, lifted and slightly premium.',
  hard_offset: 'One flat hard-edged offset shadow with zero blur. Graphic and printed rather than soft; belongs with sharp corners.'
};

const ICON_STYLES = ['outline_svg', 'filled_svg', 'typographic'];
const ICON_STYLE_TEXT = {
  outline_svg: 'Small inline SVG icons drawn as strokes, one consistent stroke width across the whole page.',
  filled_svg: 'Small inline SVG icons drawn as solid shapes, one consistent weight across the whole page.',
  typographic: 'No icons anywhere. Emphasis carried by type, rules and numerals instead. A legitimate choice, but only when the page genuinely reads better bare -- not as a way of avoiding the work.'
};

/* The component kit that separates a working conversion page from a well-set article. Each entry
   says what it is and where it earns its place, so choosing one is a match rather than a pick. */
const COMPONENT_KINDS = ['icon_rows', 'tick_list', 'pill_badges', 'callout_panel', 'faq_accordion',
  'avatar_testimonials', 'star_rating', 'stat_strip', 'pricing_box', 'ribbon_flag', 'headline_highlight'];

const COMPONENT_TEXT = {
  icon_rows: 'A small icon beside each item in a list of steps, features or inclusions. Right where a section explains several parallel things and the eye needs an anchor per row.',
  tick_list: 'A column of ticked items. Right for what is included, what is guaranteed, or what the visitor will walk away with -- anywhere the answer is a list of yeses.',
  pill_badges: 'Small rounded labels: a section eyebrow, a status chip, a category tag, a "free" or "limited" flag. Right for orienting the reader quickly at the top of a section.',
  callout_panel: 'One panel on an accent or tinted background carrying the single line that must not be skimmed past -- a guarantee, a warning, a promise. Use once or twice on a page, never as a general container.',
  faq_accordion: 'Collapsible question and answer rows built with details/summary. Right for an objections section with more than three questions, where a flat grid becomes a wall of text.',
  avatar_testimonials: 'Quotes carrying a small round photo, a name and a role. Right where the proof depends on WHO said it, not just what was said.',
  star_rating: 'Star glyphs against reviews or ratings. Only where ratings genuinely exist in the business profile -- never invented.',
  stat_strip: 'A short row of figures with labels beneath. Right when several numbers together make the argument that no single one makes alone.',
  pricing_box: 'A contained panel stating what it costs, what is included and what happens next. Right anywhere the price is the decision rather than a detail.',
  ribbon_flag: 'A corner ribbon or flag marking the one card the eye should land on first. Right when several options are shown and one is genuinely recommended.',
  headline_highlight: 'The two or three decisive words inside a headline given the accent colour, an italic, or an underline. Right almost everywhere -- a headline where nothing is emphasised is a headline that has not decided what it is about.'
};

function buildDesignCommitmentSchema() {
  const hex = { type: 'string' };
  return {
    type: 'object',
    properties: {
      colorRoles: {
        type: 'object',
        properties: {
          canvas: hex, canvasAlt: hex, surface: hex, surfaceAlt: hex,
          ink: hex, inkAlt: hex, accent: hex, accentInk: hex
        },
        required: ['canvas', 'canvasAlt', 'surface', 'surfaceAlt', 'ink', 'inkAlt', 'accent', 'accentInk'],
        additionalProperties: false
      },
      signatureMove: { type: 'string', enum: SIGNATURE_MOVES },
      signatureRationale: { type: 'string' },
      rejectedMoves: {
        type: 'array',
        items: {
          type: 'object',
          properties: { move: { type: 'string', enum: SIGNATURE_MOVES }, why: { type: 'string' } },
          required: ['move', 'why'],
          additionalProperties: false
        }
      },
      background: {
        type: 'object',
        properties: {
          treatment: { type: 'string', enum: BACKGROUND_TREATMENTS },
          drawnFrom: { type: 'string' },
          where: { type: 'string' }
        },
        required: ['treatment', 'drawnFrom', 'where'],
        additionalProperties: false
      },
      shapeLanguage: {
        type: 'object',
        properties: {
          radius: { type: 'string', enum: RADIUS_LANGUAGES },
          shadow: { type: 'string', enum: SHADOW_LANGUAGES },
          iconStyle: { type: 'string', enum: ICON_STYLES },
          fill: { type: 'string', enum: FILL_LANGUAGES }
        },
        required: ['radius', 'shadow', 'iconStyle', 'fill'],
        additionalProperties: false
      },
      components: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            kind: { type: 'string', enum: COMPONENT_KINDS },
            where: { type: 'string' }
          },
          required: ['kind', 'where'],
          additionalProperties: false
        }
      },
      typeScale: {
        type: 'object',
        properties: {
          displayPx: { type: 'number' }, bodyPx: { type: 'number' }, eyebrowPx: { type: 'number' }
        },
        required: ['displayPx', 'bodyPx', 'eyebrowPx'],
        additionalProperties: false
      },
      rhythm: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            tone: { type: 'string', enum: ['canvas', 'canvasAlt', 'accent'] },
            width: { type: 'string', enum: ['full_bleed', 'wide', 'standard', 'narrow'] },
            density: { type: 'string', enum: ['airy', 'normal', 'tight'] }
          },
          required: ['tone', 'width', 'density'],
          additionalProperties: false
        }
      }
    },
    required: ['colorRoles', 'signatureMove', 'signatureRationale', 'rejectedMoves', 'background', 'shapeLanguage', 'components', 'typeScale', 'rhythm'],
    additionalProperties: false
  };
}

/* Everything a schema cannot express. Returns a list of problems in plain words, which are handed
   straight back to the model on the single retry -- telling it what failed is far more effective
   than asking again and hoping. */
function validateCommitment(c) {
  const p = [];
  const hexOk = (v) => /^#[0-9a-fA-F]{6}$/.test(String(v || ''));
  const r = (c && c.colorRoles) || {};
  for (const k of ['canvas', 'canvasAlt', 'surface', 'surfaceAlt', 'ink', 'inkAlt', 'accent', 'accentInk']) {
    if (!hexOk(r[k])) p.push(k + ' must be a 6-digit hex colour like #1a2b3c, got ' + JSON.stringify(r[k]));
  }
  if (p.length) return p;

  const lumGap = Math.abs(relLuminance(r.canvas) - relLuminance(r.canvasAlt));
  if (lumGap < 0.35) {
    p.push('canvas ' + r.canvas + ' and canvasAlt ' + r.canvasAlt + ' are too close in brightness ('
      + lumGap.toFixed(2) + ', needs 0.35). These are the two backgrounds the whole page alternates '
      + 'between, so one must be clearly light and the other clearly dark.');
  }
  if (colourDistance(r.surface, r.canvas) < 25) {
    p.push('surface ' + r.surface + ' is too close to canvas ' + r.canvas
      + '. A card on the main background would be invisible without a border.');
  }
  if (colourDistance(r.surfaceAlt, r.canvasAlt) < 25) {
    p.push('surfaceAlt ' + r.surfaceAlt + ' is too close to canvasAlt ' + r.canvasAlt + '.');
  }
  for (const [fg, bg, label] of [[r.ink, r.canvas, 'ink on canvas'], [r.inkAlt, r.canvasAlt, 'inkAlt on canvasAlt'],
                                 [r.accentInk, r.accent, 'accentInk on accent']]) {
    const ratio = contrastRatio(fg, bg);
    if (ratio < 4.5) p.push(label + ' has a contrast ratio of ' + ratio.toFixed(1) + ', below the 4.5 needed to be readable.');
  }

  const rhythm = Array.isArray(c.rhythm) ? c.rhythm : [];
  if (rhythm.length < 8) p.push('rhythm needs at least 8 entries so a long page never runs out; got ' + rhythm.length + '.');
  const tones = rhythm.map((x) => x && x.tone);
  for (let i = 2; i < tones.length; i++) {
    if (tones[i] && tones[i] === tones[i - 1] && tones[i] === tones[i - 2]) {
      p.push('three sections in a row use "' + tones[i] + '" (positions ' + (i - 1) + ' to ' + (i + 1)
        + '). The page has to keep alternating or it reads as one flat block.');
      break;
    }
  }
  const nonCanvas = tones.filter((t) => t && t !== 'canvas').length;
  if (tones.length && nonCanvas / tones.length < 0.3) {
    p.push('only ' + nonCanvas + ' of ' + tones.length + ' sections leave the main background. At least 30 percent must.');
  }
  const accents = tones.filter((t) => t === 'accent').length;
  if (accents > 1) p.push(accents + ' sections use the accent as their background. It is punctuation, so at most one may.');

  const ts = c.typeScale || {};
  if (!(ts.displayPx >= 56 && ts.displayPx <= 140)) p.push('typeScale.displayPx must be between 56 and 140, got ' + ts.displayPx + '.');
  if (!(ts.bodyPx >= 15 && ts.bodyPx <= 19)) p.push('typeScale.bodyPx must be between 15 and 19, got ' + ts.bodyPx + '.');
  if (!(ts.eyebrowPx >= 10 && ts.eyebrowPx <= 13)) p.push('typeScale.eyebrowPx must be between 10 and 13, got ' + ts.eyebrowPx + '.');
  if (ts.displayPx && ts.bodyPx && ts.displayPx / ts.bodyPx < 4) {
    p.push('display type is only ' + (ts.displayPx / ts.bodyPx).toFixed(1) + ' times the body size. It needs to be at least 4 times to read as a display face.');
  }

  if (String(c.signatureRationale || '').trim().length < 20) {
    p.push('signatureRationale must actually argue why this move suits THIS business. A generic answer means the whole commitment is generic.');
  }
  const bg = c.background || {};
  if (BACKGROUND_TREATMENTS.indexOf(bg.treatment) === -1) {
    p.push('background.treatment must be one of: ' + BACKGROUND_TREATMENTS.join(', ') + '.');
  }
  /* The treatment has to come from the business's own world or it is wallpaper. A dot grid on a
     children's dentist is as wrong as a tooth motif on a foundry. */
  if (String(bg.drawnFrom || '').trim().length < 20) {
    p.push('background.drawnFrom must say what in THIS business the treatment is drawn from, in a real sentence.');
  }
  if (String(bg.where || '').trim().length < 10) {
    p.push('background.where must name which sections carry the treatment. It is never every section -- a pattern everywhere is wallpaper.');
  }

  const shape = c.shapeLanguage || {};
  if (RADIUS_LANGUAGES.indexOf(shape.radius) === -1) {
    p.push('shapeLanguage.radius must be one of: ' + RADIUS_LANGUAGES.join(', ') + '.');
  }
  if (SHADOW_LANGUAGES.indexOf(shape.shadow) === -1) {
    p.push('shapeLanguage.shadow must be one of: ' + SHADOW_LANGUAGES.join(', ') + '.');
  }
  if (ICON_STYLES.indexOf(shape.iconStyle) === -1) {
    p.push('shapeLanguage.iconStyle must be one of: ' + ICON_STYLES.join(', ') + '.');
  }
  if (FILL_LANGUAGES.indexOf(shape.fill) === -1) {
    p.push('shapeLanguage.fill must be one of: ' + FILL_LANGUAGES.join(', ') + '.');
  }

  /* Four distinct components is the line between a page that argues and a page that is merely set.
     Without a floor here the generator reliably produces headings, paragraphs and plain boxes. */
  const comps = Array.isArray(c.components) ? c.components : [];
  const kinds = [...new Set(comps.map((x) => x && x.kind).filter(Boolean))];
  if (kinds.length < 4) {
    p.push('components must name at least 4 DIFFERENT components from the catalogue, with a specific place for each. A page built only from headings and paragraphs is what this exists to prevent.');
  }
  if (comps.some((x) => !x || COMPONENT_KINDS.indexOf(x.kind) === -1)) {
    p.push('every component must be one of: ' + COMPONENT_KINDS.join(', ') + '.');
  }
  if (comps.some((x) => x && String(x.where || '').trim().length < 10)) {
    p.push('every component needs a specific place in this page, not a word.');
  }
  if (shape.iconStyle === 'typographic' && kinds.indexOf('icon_rows') !== -1) {
    p.push('shapeLanguage.iconStyle is typographic but components include icon_rows, which needs icons. Pick one.');
  }

  /* Naming two moves you turned down forces the choice to be a choice. Without this the same
     safe option gets picked every time and the rationale is written afterwards to fit it. */
  const rejected = Array.isArray(c.rejectedMoves) ? c.rejectedMoves : [];
  if (rejected.length < 2) {
    p.push('rejectedMoves must name at least 2 signature moves you considered and turned down, with a reason for each.');
  }
  if (rejected.some((r) => r && r.move === c.signatureMove)) {
    p.push('rejectedMoves lists the move you actually chose.');
  }
  if (rejected.some((r) => !r || String(r.why || '').trim().length < 15)) {
    p.push('every rejectedMoves entry needs a real reason, not a few words.');
  }
  return p;
}

/* Rendered into the generation prompt. Deliberately worded as a contract rather than advice: the
   whole point of deciding these separately is that they are no longer up for negotiation. */
function commitmentContractText(c) {
  if (!c || !c.colorRoles) return '';
  const r = c.colorRoles;
  const rhythm = (c.rhythm || []).map((x, i) =>
    '  section ' + (i + 1) + ': background ' + x.tone + ', container ' + x.width + ', spacing ' + x.density
  ).join('\n');
  return '\n\n=== THE DESIGN CONTRACT FOR THIS PAGE ===\n'
    + 'These were decided before you were asked to build anything, by a step whose only job was to '
    + 'commit to a look. They are not suggestions and you may not improve on them. Everything below '
    + 'is already checked for contrast and readability, so changing a value will break the page.\n\n'
    + 'COLOURS, BY JOB. Use these exact hex values for these exact purposes and introduce no others '
    + 'beyond photography:\n'
    + '  canvas ' + r.canvas + ' -- the dominant page background\n'
    + '  canvasAlt ' + r.canvasAlt + ' -- the contrasting background for sections that break the rhythm\n'
    + '  surface ' + r.surface + ' -- what a card, panel or quote sits on when it is on canvas\n'
    + '  surfaceAlt ' + r.surfaceAlt + ' -- what a card sits on when it is on canvasAlt\n'
    + '  ink ' + r.ink + ' -- body text on canvas\n'
    + '  inkAlt ' + r.inkAlt + ' -- body text on canvasAlt\n'
    + '  accent ' + r.accent + ' -- the single saturated colour, for actions and emphasis\n'
    + '  accentInk ' + r.accentInk + ' -- text placed on the accent\n\n'
    + 'SECTION RHYTHM. Apply these in order to the sections you invent. If you write fewer sections '
    + 'than there are lines here, use the first ones and stop. Never give a section a background of '
    + 'your own choosing.\n' + rhythm + '\n\n'
    + 'Put the tone you used on each section\'s ROOT element as a plain attribute, exactly like '
    + 'data-tone="canvas" or data-tone="canvasAlt" or data-tone="accent". It changes nothing '
    + 'visually -- it is how the finished page gets checked against this contract. A section whose '
    + 'marker disagrees with the background it actually paints will be sent back.\n\n'
    + 'Container widths: wide is about 1280px, standard about 1080px, narrow about 680px. '
    + 'full_bleed means the BACKGROUND of that section runs edge to edge -- it does NOT mean the '
    + 'content does. Text inside a full-bleed section still sits in a centred container of one of the '
    + 'widths above, because a sentence stretched across a 1920px monitor is unreadable however well '
    + 'it is set. Never write max-width:none on anything holding text. Give every image, figure and '
    + 'media plate a max-width too, so a photograph cannot grow past the column it belongs to. '
    + 'Varying the width is half of what makes a page feel paced.\n\n'
    + 'TYPE SCALE. Display headings around ' + c.typeScale.displayPx + 'px at desktop (use clamp() so '
    + 'they shrink sensibly), body text ' + c.typeScale.bodyPx + 'px, small labels '
    + c.typeScale.eyebrowPx + 'px.\n\n'
    + 'BACKGROUND TREATMENT: ' + (c.background || {}).treatment + '. '
    + (BACKGROUND_TEXT[(c.background || {}).treatment] || '') + '\n'
    + '  drawn from: ' + (c.background || {}).drawnFrom + '\n'
    + '  carried by: ' + (c.background || {}).where + '\n'
    + '  Build it in CSS on those sections and nowhere else. It sits BEHIND the content and must '
    + 'never reduce text contrast -- if it competes with the words, it is too strong. Every colour '
    + 'in it comes from the palette above; introduce no new hue for decoration.\n\n'
    + 'SHAPE LANGUAGE. Pick these values once and reuse them on every card, button, input, image and '
    + 'panel across every section. Mixing them is what makes a page read as assembled by several people.\n'
    + '  corners: ' + (c.shapeLanguage || {}).radius + ' -- ' + (RADIUS_TEXT[(c.shapeLanguage || {}).radius] || '') + '\n'
    + '  shadow: ' + (c.shapeLanguage || {}).shadow + ' -- ' + (SHADOW_TEXT[(c.shapeLanguage || {}).shadow] || '') + '\n'
    + '  fill: ' + (c.shapeLanguage || {}).fill + ' -- ' + (FILL_TEXT[(c.shapeLanguage || {}).fill] || '') + '\n'
    + '  icons: ' + (c.shapeLanguage || {}).iconStyle + ' -- ' + (ICON_STYLE_TEXT[(c.shapeLanguage || {}).iconStyle] || '') + '\n\n'
    + 'COMPONENTS YOU MUST ACTUALLY BUILD. These were chosen for this page and each one has a place. '
    + 'Build every one of them, as real markup and CSS, in roughly the place named. A section made of a '
    + 'heading and two paragraphs where one of these belongs is the failure this list exists to prevent. '
    + 'Do not use any single one of them in more than two sections.\n'
    + (c.components || []).map((x) => '  ' + x.kind + ' -- ' + (COMPONENT_TEXT[x.kind] || '')
        + '\n      here: ' + x.where).join('\n') + '\n\n'
    + 'THE SIGNATURE MOVE: ' + c.signatureMove + '. ' + (SIGNATURE_MOVE_TEXT[c.signatureMove] || '')
    + '\nWhy it suits this business: ' + c.signatureRationale + '\n'
    + 'Use it in at least three separate sections. Distinctiveness comes from repeating one gesture '
    + 'with conviction, not from scattering several. Do not invent additional signature devices.';
}

/* The commitment's rhythm was validated as a PLAN, but nothing checked that the finished page
   obeyed it -- which is how a page shipped with three navy sections in a row while its own contract
   said to alternate. This reads the data-tone markers back out of the generated HTML and compares
   them with what was promised. Findings go to the revise pass, which already runs on every
   generation, so enforcement costs no extra AI call. */
function auditRhythm(sections, c) {
  if (!c || !c.colorRoles || !Array.isArray(c.rhythm) || !c.rhythm.length) return [];
  if (!Array.isArray(sections) || !sections.length) return [];
  const toneHex = { canvas: c.colorRoles.canvas, canvasAlt: c.colorRoles.canvasAlt, accent: c.colorRoles.accent };
  const problems = [];
  const actual = [];
  sections.forEach((sec, i) => {
    const html = String((sec && sec.html) || '');
    const css = String((sec && sec.css) || '');
    const label = 'Section ' + (i + 1) + ' (' + ((sec && sec.type) || 'unknown') + ')';
    const planned = c.rhythm[i] ? c.rhythm[i].tone : null;
    const found = html.match(/data-tone\s*=\s*["']([A-Za-z]+)["']/);
    const got = found ? found[1] : null;
    actual.push(got);
    // Writing more sections than the contract planned is explicitly allowed, so stop checking there.
    if (!planned) return;
    if (!got) {
      problems.push(label + ' is missing its data-tone marker on the root element. The contract gives it ' + planned + '.');
      return;
    }
    if (got !== planned) {
      problems.push(label + ' is marked data-tone="' + got + '" but the contract gives it ' + planned + '. Repaint it as ' + planned + '.');
    }
    const want = toneHex[got];
    if (want && css.toLowerCase().indexOf(want.toLowerCase()) === -1) {
      problems.push(label + ' claims tone ' + got + ' but its CSS never uses ' + want + ', so the marker and the real background disagree.');
    }
  });
  /* Backstop: a missing or wrong marker can still produce a visible run even when each line was
     checked on its own. Report the first section of each run only, so the list stays readable. */
  let run = 1;
  for (let i = 1; i < actual.length; i++) {
    if (actual[i] && actual[i] === actual[i - 1]) {
      run += 1;
      if (run === 3) {
        problems.push('Sections ' + (i - 1) + ' to ' + (i + 1) + ' all sit on ' + actual[i]
          + '. Three backgrounds the same in a row is exactly the flatness the rhythm exists to prevent -- break the middle one.');
      }
    } else {
      run = 1;
    }
  }
  return problems;
}

/* An underline drawn as a border-bottom on an INLINE element hangs off the bottom of its line box.
   Put that inside a display heading with a line-height below 1 and the border lands on top of the
   next line -- which is how a page shipped with a white bar cutting through its own headline. Each
   rule is fine alone; only the combination breaks, so neither is catchable by reading one rule.
   Measured here rather than asked for in the prompt, because this is arithmetic and technique rules
   have a poor record of sticking. */

function cssDeclBlocks(css) {
  // Drop @media wrappers so their inner rules parse as ordinary ones; the stray closing brace left
  // behind produces an empty rule, which is harmless.
  const flat = String(css || '').replace(/@media[^{]*\{/g, '');
  const out = [];
  const re = /([^{}]+)\{([^{}]*)\}/g;
  let m;
  while ((m = re.exec(flat))) out.push({ selector: m[1].trim(), decls: m[2] });
  return out;
}

function declValue(decls, prop) {
  const m = new RegExp(prop + '\\s*:\\s*([^;]+)').exec(decls);
  return m ? m[1].trim() : null;
}

// clamp(44px, 9.5vw, 104px) -> 104. A plain 72px -> 72. Anything else -> null.
function largestPx(value) {
  if (!value) return null;
  const clamp = /clamp\s*\(([^)]*)\)/i.exec(value);
  const src = clamp ? clamp[1] : value;
  const px = [...String(src).matchAll(/(-?\d*\.?\d+)px/g)].map((x) => parseFloat(x[1]));
  return px.length ? Math.max.apply(null, px) : null;
}

function classesInSelector(selector) {
  return [...String(selector).matchAll(/\.([A-Za-z0-9_-]+)/g)].map((m) => m[1]);
}

/* ".card .title" styles .title, not .card. Taking every class in the selector reports the same
   collision once per ancestor. */
function targetClasses(selector) {
  return String(selector).split(',').map((part) => {
    const cls = classesInSelector(part);
    return cls.length ? cls[cls.length - 1] : null;
  }).filter(Boolean);
}

// Find the span of html covered by the first element carrying `className`, so we can tell whether
// the underline actually sits inside the oversized heading rather than merely nearby.
function elementRange(html, className) {
  const safe = className.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const open = new RegExp('<([a-zA-Z0-9]+)\\b[^>]*class\\s*=\\s*["\'][^"\']*\\b' + safe + '\\b[^"\']*["\'][^>]*>', 'i');
  const m = open.exec(html);
  if (!m) return null;
  const tag = m[1];
  const token = new RegExp('<(/?)' + tag + '\\b', 'gi');
  token.lastIndex = m.index + m[0].length;
  let depth = 1, t;
  while ((t = token.exec(html))) {
    depth += t[1] ? -1 : 1;
    if (depth === 0) return { start: m.index, end: t.index };
  }
  return { start: m.index, end: html.length };
}

const INLINE_TAGS = ['span', 'em', 'strong', 'a', 'b', 'i', 'mark', 'u'];

function auditTypeCollisions(sections) {
  if (!Array.isArray(sections)) return [];
  const problems = [];
  sections.forEach((sec, i) => {
    const html = String((sec && sec.html) || '');
    const css = String((sec && sec.css) || '');
    if (!html || !css) return;
    const rules = cssDeclBlocks(css);

    // Inline elements carrying a visible bottom border -- the underline device.
    const underlines = [];
    rules.forEach((r) => {
      const border = declValue(r.decls, 'border-bottom') || declValue(r.decls, 'border-bottom-width');
      if (!border) return;
      const width = largestPx(border);
      if (!(width >= 2)) return;
      // An element explicitly made block-level clears the next line on its own.
      const display = declValue(r.decls, 'display');
      if (display && /block|flex|grid|table/.test(display) && !/inline-block/.test(display)) return;
      targetClasses(r.selector).forEach((cls) => {
        const tagOk = new RegExp('<(' + INLINE_TAGS.join('|') + ')\\b[^>]*class\\s*=\\s*["\'][^"\']*\\b'
          + cls.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(html);
        if (tagOk) underlines.push({ cls, width });
      });
    });
    if (!underlines.length) return;
    // A media query redefining the same underline is not a second underline; keep the widest.
    const widest = new Map();
    underlines.forEach((u) => {
      if (!widest.has(u.cls) || widest.get(u.cls).width < u.width) widest.set(u.cls, u);
    });
    const uniqueUnderlines = [...widest.values()];

    // Oversized headings packed tighter than their own text is tall.
    rules.forEach((r) => {
      const lh = declValue(r.decls, 'line-height');
      const fs = largestPx(declValue(r.decls, 'font-size'));
      if (lh === null || fs === null) return;
      const lhNum = parseFloat(lh);
      // Only unitless or em line-heights are ratios; a px line-height is compared against font-size.
      const ratio = /px/.test(lh) ? (largestPx(lh) || 0) / fs : lhNum;
      if (!(ratio > 0) || ratio >= 1.05 || fs < 40) return;

      targetClasses(r.selector).forEach((cls) => {
        const range = elementRange(html, cls);
        if (!range) return;
        const inner = html.slice(range.start, range.end);
        uniqueUnderlines.forEach((u) => {
          if (inner.indexOf(u.cls) === -1) return;
          problems.push('Section ' + (i + 1) + ' (' + ((sec && sec.type) || 'unknown') + '): "."'
            .replace('"."', '.' + cls) + ' sets line-height ' + lh + ' at ' + fs
            + 'px and contains the inline underline .' + u.cls + ' with a ' + u.width
            + 'px bottom border. A line-height this tight leaves no room beneath the text, so that'
            + ' border is drawn into the following line as soon as the heading wraps. Give this heading a'
            + ' line-height of at least 1.05, or draw the underline so it cannot overlap (padding-bottom on the'
            + ' span, or a background/box-shadow rule), keeping the same look.');
        });
      });
    });
  });
  return [...new Set(problems)];
}

/* A committed component that never gets built is just a good intention. This reads the finished page
   back and reports what was promised but is missing, plus a shape language that was not held. The
   detectors are deliberately forgiving: a false "you did not build this" would send the revise pass
   off to add something already there, which is worse than missing one. */

const COMPONENT_DETECTORS = {
  icon_rows: (h) => /<svg[\s>]/i.test(h),
  tick_list: (h) => /[✓✔]/.test(h) || /\b(tick|check)[a-z0-9-]*\s*["'>]/i.test(h),
  pill_badges: (h, c) => /border-radius\s*:\s*(999|9999|100)/i.test(c)
    || /\b(pill|badge|chip|tag)[a-z0-9-]*\s*["'>]/i.test(h),
  callout_panel: (h, c) => /\b(callout|notice|warning|alert|promise|guarantee)[a-z0-9-]*\s*["'>]/i.test(h)
    || /border-left\s*:\s*[4-9]px|border-left\s*:\s*[0-9]{2}px/i.test(c),
  faq_accordion: (h) => /<details[\s>]|<summary[\s>]/i.test(h),
  avatar_testimonials: (h, c) => /border-radius\s*:\s*50%/i.test(c)
    || /\bavatar[a-z0-9-]*\s*["'>]/i.test(h),
  star_rating: (h) => /[★☆]/.test(h) || /\bstar[a-z0-9-]*\s*["'>]/i.test(h),
  stat_strip: (h) => /\b(stat|metric|figure|counter)[a-z0-9-]*\s*["'>]/i.test(h),
  pricing_box: (h) => /\b(pricing|price|plan|tier|cost)[a-z0-9-]*\s*["'>]/i.test(h),
  ribbon_flag: (h) => /\b(ribbon|flag|corner|sticker|recommended|popular)[a-z0-9-]*\s*["'>]/i.test(h),
  headline_highlight: (h) => /<h[1-3][^>]*>(?:(?!<\/h[1-3]>)[\s\S])*<(span|em|i|mark|u)\b/i.test(h)
};

function auditComponents(sections, c) {
  if (!c || !Array.isArray(sections) || !sections.length) return [];
  const problems = [];
  const html = sections.map((s) => String((s && s.html) || '')).join('\n');
  const css = sections.map((s) => String((s && s.css) || '')).join('\n');

  // 1. Everything promised has to exist somewhere on the page.
  const kinds = [...new Set((c.components || []).map((x) => x && x.kind).filter(Boolean))];
  kinds.forEach((kind) => {
    const detect = COMPONENT_DETECTORS[kind];
    if (!detect || detect(html, css)) return;
    const entry = (c.components || []).find((x) => x && x.kind === kind) || {};
    problems.push('The design contract commits to the component "' + kind + '" ('
      + (entry.where || 'see the contract') + ') and the page does not contain it. Build it as real markup and CSS'
      + ' in that place, replacing whatever plain heading-and-paragraph block is standing in for it.');
  });

  /* 2. No single STRUCTURAL component may carry the whole page. Small inline parts are exempt:
     reusing one chip or one highlight style across a page is consistency, which the shape language
     asks for elsewhere -- capping them made this audit argue with itself. */
  const CAP_EXEMPT = ['pill_badges', 'headline_highlight', 'tick_list'];
  kinds.forEach((kind) => {
    const detect = COMPONENT_DETECTORS[kind];
    if (!detect || CAP_EXEMPT.indexOf(kind) !== -1) return;
    const used = sections.filter((s) => detect(String((s && s.html) || ''), String((s && s.css) || ''))).length;
    if (used > 2) {
      problems.push('The component "' + kind + '" appears in ' + used
        + ' sections. Using one component everywhere is the same flatness as using none -- keep it to at most two and build a different one from the contract in the others.');
    }
  });

  const shape = c.shapeLanguage || {};

  // 3. Corners. Circles and pills are their own thing, so only square-ish radii are judged.
  const radii = [...String(css).matchAll(/border-radius\s*:\s*([0-9]+)px/g)]
    .map((m) => parseInt(m[1], 10)).filter((v) => v < 100);
  if (radii.length) {
    const biggest = Math.max.apply(null, radii);
    if (shape.radius === 'soft' && biggest < 12) {
      problems.push('The contract commits to soft corners (12 to 16px) and the largest border-radius on the page is '
        + biggest + 'px. Apply the committed radius to cards, buttons, inputs and images.');
    }
    if (shape.radius === 'tight' && (biggest < 5 || biggest > 11)) {
      problems.push('The contract commits to tight corners (6 to 8px) and the page uses ' + biggest
        + 'px. Use the committed radius consistently.');
    }
    if (shape.radius === 'sharp' && biggest > 4) {
      problems.push('The contract commits to sharp corners (0 to 2px) and the page uses ' + biggest
        + 'px. Square the corners.');
    }
  } else if (shape.radius === 'soft' || shape.radius === 'tight') {
    problems.push('The contract commits to ' + shape.radius
      + ' corners and the page sets no border-radius at all. Apply it to cards, buttons, inputs and images.');
  }

  // 4. Shadow.
  const shadows = [...String(css).matchAll(/box-shadow\s*:\s*([^;}]+)/g)].map((m) => m[1].trim())
    .filter((v) => !/^none$/i.test(v));
  /* box-shadow is "offsetX offsetY blur spread colour", and a zero is usually written without a
     unit, so matching only Npx misses the blur entirely. Strip the colour first, then the third
     number is the blur. */
  const blurOf = (v) => {
    const nums = String(v)
      .replace(/(rgba?|hsla?)\([^)]*\)/gi, ' ')
      .replace(/#[0-9a-fA-F]{3,8}/g, ' ')
      .match(/-?[0-9.]+/g) || [];
    return nums.length >= 3 ? parseFloat(nums[2]) : 0;
  };
  const blurry = shadows.filter((v) => blurOf(v) > 0);
  if (shape.shadow === 'soft_ambient' && !blurry.length) {
    problems.push('The contract commits to one soft ambient shadow and the page has no blurred box-shadow anywhere. '
      + 'Add it, with identical values, wherever an element needs lifting off its background.');
  }
  if (shape.shadow === 'none' && shadows.length) {
    problems.push('The contract commits to no shadows and the page uses box-shadow. Remove it and separate with borders, rules or background changes.');
  }
  if (shape.shadow === 'hard_offset' && shadows.length && blurry.length === shadows.length) {
    problems.push('The contract commits to a hard offset shadow with zero blur and every shadow on the page is blurred. Set the blur to 0.');
  }

  /* 5. Fill. Reuses hasRealGradient so that linear-gradient(x, x) -- the same colour twice, which
     is the only "gradient" this generator has ever written -- cannot pass as a gradient fill. */
  if (shape.fill === 'gradient' && !hasRealGradient(css, /(linear|radial)-gradient/)) {
    problems.push('The contract commits to gradient fills and no button, card or panel on the page uses a real '
      + 'two-colour gradient. Fill the primary call to action, and at most one or two key panels, with a gradient '
      + 'between two colours already in the committed palette.');
  }
  if (shape.fill === 'outline') {
    const buttonish = String(css).match(/[^{}]*(btn|button|cta)[^{}]*\{[^}]*\}/gi) || [];
    const anyBorder = buttonish.some((r) => /border\s*:\s*[1-9]/i.test(r) || /border-width/i.test(r));
    if (buttonish.length && !anyBorder) {
      problems.push('The contract commits to outline fills and the buttons carry no border. Draw them as boxes: '
        + 'transparent fill, a confident border, the label carrying the weight.');
    }
  }

  // 6. Icons.
  const hasSvg = /<svg[\s>]/i.test(html);
  if ((shape.iconStyle === 'outline_svg' || shape.iconStyle === 'filled_svg') && !hasSvg) {
    problems.push('The contract commits to inline SVG icons (' + shape.iconStyle
      + ') and the page contains no <svg> element. Draw them inline; do not substitute emoji or an icon font.');
  }
  if (shape.iconStyle === 'typographic' && hasSvg) {
    problems.push('The contract commits to no icons and the page contains inline SVG icons. Remove them and carry the emphasis with type.');
  }

  return [...new Set(problems)];
}

/* Checks the committed background treatment was actually drawn, and on the right number of sections.
   The one subtlety worth encoding: linear-gradient(#0f7a3d, #0f7a3d) is not a gradient. Every
   "gradient" this generator has ever produced was that -- the same colour twice, used as a trick to
   draw an underline -- so a naive /gradient/ test would report a flat page as richly treated. */

function gradientStops(value) {
  const inner = String(value).replace(/^[a-z-]*gradient\s*\(/i, '').replace(/\)\s*$/, '');
  const stops = inner.match(/#[0-9a-fA-F]{3,8}|rgba?\([^)]*\)|hsla?\([^)]*\)/g) || [];
  return stops.map((x) => x.toLowerCase().replace(/\s+/g, ''));
}

function hasRealGradient(css, kindRe) {
  const found = String(css).match(new RegExp(kindRe.source + '\\s*\\([^;{}]*\\)', 'gi')) || [];
  return found.some((g) => {
    const stops = gradientStops(g);
    return stops.length >= 2 && new Set(stops).size >= 2;
  });
}

const BACKGROUND_DETECTORS = {
  flat: () => true,
  dot_grid: (css) => (/radial-gradient/i.test(css) && /background-size/i.test(css))
    || /repeating-radial-gradient/i.test(css),
  rule_grid: (css) => /repeating-linear-gradient/i.test(css)
    || (/linear-gradient/i.test(css) && /background-size/i.test(css)),
  diagonal_field: (css) => /clip-path/i.test(css)
    || /repeating-linear-gradient\s*\(\s*-?\d+deg/i.test(css),
  edge_wash: (css) => hasRealGradient(css, /radial-gradient/)
    || /radial-gradient[^;{}]*(transparent|rgba\([^)]*,\s*0\s*\))/i.test(css),
  gradient_field: (css) => hasRealGradient(css, /linear-gradient/)
    || hasRealGradient(css, /radial-gradient/),
  ghost_letterform: (css, html) => (/opacity\s*:\s*0?\.\d+/i.test(css)
    && /font-size\s*:\s*(clamp\([^)]*\)|\d{3,}px)/i.test(css)) || /::(before|after)[^{]*\{[^}]*content\s*:\s*['"][^'"]+['"]/i.test(css),
  trade_motif: (css) => /background[^;]*data:image\/svg/i.test(css)
    || (/background-repeat\s*:\s*repeat/i.test(css) && /background-image/i.test(css))
};

function auditBackground(sections, c) {
  if (!c || !c.background || !Array.isArray(sections) || !sections.length) return [];
  const treatment = c.background.treatment;
  const detect = BACKGROUND_DETECTORS[treatment];
  if (!detect || treatment === 'flat') return [];

  const carrying = sections.filter((s) => detect(String((s && s.css) || ''), String((s && s.html) || '')));
  const problems = [];

  if (!carrying.length) {
    problems.push('The design contract commits to a "' + treatment + '" background ('
      + c.background.drawnFrom + '), to be carried by: ' + c.background.where
      + '. No section on the page implements it -- every background is a plain colour fill. Build it in CSS on those'
      + ' sections, behind the content, using only colours from the committed palette.');
  } else if (carrying.length > Math.max(3, Math.ceil(sections.length / 2))) {
    problems.push('The "' + treatment + '" background treatment appears on ' + carrying.length
      + ' of ' + sections.length + ' sections. A treatment on everything is wallpaper -- keep it to the two or three'
      + ' named in the contract (' + c.background.where + ') so it still reads as a deliberate accent.');
  }

  /* A gradient between two unrelated hues is the tell this exists to prevent, so if a gradient
     treatment was chosen, at least one real two-colour gradient has to be present. */
  if ((treatment === 'gradient_field' || treatment === 'edge_wash') && carrying.length) {
    const anyReal = sections.some((s) => hasRealGradient(String((s && s.css) || ''), /(linear|radial)-gradient/));
    if (!anyReal) {
      problems.push('The contract commits to ' + treatment + ' but every gradient on the page repeats the same colour'
        + ' twice, which paints a flat block rather than a gradient. Interpolate between two DIFFERENT colours from'
        + ' the committed palette.');
    }
  }

  return [...new Set(problems)];
}

/* Two width faults measured on real generated pages, both invisible at laptop width and obvious on a
   1920px monitor: a headline band whose text container was given max-width:none and ran 1857px wide,
   and hero image slots at 968px and 1600px because their rule set width:100% with no cap. The prompt
   now says not to, but saying is not enforcing -- this is the part that checks. */

/* Remove @media blocks and everything inside them, matching braces so nested rules go with them.
   Flattening instead of removing was reporting a mobile "max-width:none" reset -- which is correct
   CSS -- as a desktop-width fault. Only the base rules are judged here. */
function stripMediaBlocks(css) {
  let out = String(css || '');
  for (;;) {
    const at = out.search(/@media[^{]*\{/i);
    if (at === -1) return out;
    const open = out.indexOf('{', at);
    let depth = 1, i = open + 1;
    while (i < out.length && depth > 0) {
      if (out[i] === '{') depth += 1;
      else if (out[i] === '}') depth -= 1;
      i += 1;
    }
    out = out.slice(0, at) + out.slice(i);
  }
}

function styleRules(css) {
  const base = stripMediaBlocks(css);
  const out = [];
  const re = /([^{}]+)\{([^{}]*)\}/g;
  let m;
  while ((m = re.exec(base))) out.push({ selector: m[1].trim(), decls: m[2] });
  return out;
}

const IMAGEY = /(img|image|photo|figure|media|plate|slot|shot|frame|thumb)/i;

function auditWidths(sections) {
  if (!Array.isArray(sections) || !sections.length) return [];
  const problems = [];

  sections.forEach((sec, i) => {
    const css = String((sec && sec.css) || '');
    const label = 'Section ' + (i + 1) + ' (' + ((sec && sec.type) || 'unknown') + ')';

    styleRules(css).forEach((r) => {
      // 1. Explicitly switching the container off. The default is already none, so writing it is
      //    always a deliberate override of a constraint that should have stayed.
      if (/max-width\s*:\s*none/i.test(r.decls)) {
        problems.push(label + ': "' + r.selector.slice(0, 60) + '" sets max-width:none, which lets its'
          + ' content run the full width of the monitor -- on a 1920px screen that is a single line nearly two'
          + ' metres of pixels wide. Give it one of the committed container widths instead. A full-bleed section'
          + ' means the BACKGROUND spans edge to edge, never the text.');
      }

      // 2. An image told to fill its parent with nothing stopping it.
      const fills = /(^|[;\s])width\s*:\s*100%/i.test(r.decls);
      const capped = /max-width\s*:\s*[0-9]/i.test(r.decls) || /max-width\s*:\s*100%/i.test(r.decls);
      if (fills && !capped && IMAGEY.test(r.selector)) {
        problems.push(label + ': the image rule "' + r.selector.slice(0, 60) + '" sets width:100% with no'
          + ' max-width, so the picture grows without limit on a wide screen. Cap it at the width of the column'
          + ' it belongs to.');
      }
    });
  });

  return [...new Set(problems)];
}

function buildAiFunnelSchema() {
  return {
    type: 'object',
    properties: {
      fonts: { type: 'array', items: { type: 'string' } },
      sections: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            type: { type: 'string' },
            html: { type: 'string' },
            css: { type: 'string' }
          },
          required: ['type', 'html', 'css'],
          additionalProperties: false
        }
      }
    },
    required: ['fonts', 'sections'],
    additionalProperties: false
  };
}

function buildAiFunnelReviseSchema() {
  return {
    type: 'object',
    properties: {
      critique: {
        type: 'object',
        properties: {
          philosophy: { type: 'integer' },
          hierarchy: { type: 'integer' },
          execution: { type: 'integer' },
          specificity: { type: 'integer' },
          restraint: { type: 'integer' },
          variety: { type: 'integer' },
          notes: { type: 'string' }
        },
        required: ['philosophy', 'hierarchy', 'execution', 'specificity', 'restraint', 'variety', 'notes'],
        additionalProperties: false
      },
      changesSummary: { type: 'string' },
      fonts: { type: 'array', items: { type: 'string' } },
      sections: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            type: { type: 'string' },
            html: { type: 'string' },
            css: { type: 'string' }
          },
          required: ['type', 'html', 'css'],
          additionalProperties: false
        }
      }
    },
    required: ['critique', 'changesSummary', 'fonts', 'sections'],
    additionalProperties: false
  };
}

function aiFunnelMarkupInstructionText() {
  return `You are writing REAL, production HTML and CSS by hand for each section -- not selecting values from a menu of pre-built options. There is no component library and no fixed set of layouts behind this call: whatever structure, markup, and styling you write is exactly what ships. Each section object's "html" is the complete markup for that section only (choose the semantic root tag yourself -- <header> for a navbar-equivalent, <footer> for a footer-equivalent, <section> for everything else -- do not wrap it in <html>/<body>). Each section's "css" is the complete stylesheet for that section only, written as normal CSS rules (no <style> tag, just the rules). Use single quotes for HTML attribute values (e.g. class='hero-lead') so you rarely need to escape a double quote inside the JSON string.

Self-scoping is mandatory: give each section's root element one unique class name that does not appear in any other section (e.g. "pricing-cta-9f3", "hero-lead"), and write EVERY selector in that section's CSS starting from that class (e.g. ".pricing-cta-9f3 .plan-card", never a bare ".plan-card"). This is the only thing preventing one section's styles from leaking into another, since every section is concatenated into one shared document -- treat it as a hard rule. Two exceptions, both still namespaced by that same class rather than by selector nesting: (1) CSS custom properties belong on the section's own root class (e.g. ".hero-lead { --accent: #ff6b35; }"), never on ":root" or "*". (2) @keyframes names are global across the whole document regardless of selector scoping, so prefix every @keyframes name you define with that section's own class name (e.g. "@keyframes hero-lead-fade-up") so two sections can never collide. Never write a bare "html", "body", "*", or ":root" selector in a section's CSS -- the page shell already handles global resets.

Compose each section's structure yourself -- vary the underlying shape across the page (grid vs. stacked vs. split vs. bordered-frame vs. asymmetric), so the page doesn't read as a repeated template. The hero's composition matters most of all -- it is the first thing every visitor sees. Hard rule: never let 3 sections in a row share the same underlying composition shape (e.g. three consecutive image-plus-text-split sections, or three consecutive plain grid-of-cards sections) even if they serve different roles -- break the run with a different composition before the 3rd repeat. Where a section uses an icon/number/initials badge, vary its containment treatment deliberately across the page (a solid filled circle, a hollow ring/outline, a square, or no container at all, just a larger glyph) written directly as CSS (border-radius, border, background) -- filled-circle-in-every-section is the single most recognizable "AI page builder" visual tell that exists, so treat it as a default to actively reconsider, not reach for out of habit.

Let the layout carry an argument at least once. Somewhere on the page, choose a section where the arrangement itself does the persuading rather than merely holding the text: a comparison that is physically two columns because it IS a comparison, and where the side you want chosen is visibly heavier; a sequence laid out as a run across or down the page because the order is the point; a single claim given a whole section with nothing beside it because isolation is what makes it land; a set of items staggered rather than aligned because they are not equivalent. Decide what that section is arguing, then build the shape that argues it -- so that someone who read none of the words would still take the point from the arrangement alone. Everywhere else, a plain centred column is fine and often correct; this is about one section doing more than holding content.

One memorable moment per page. Before you write any CSS, decide which single thing on this page the visitor should still be able to picture an hour after they close the tab -- one number set enormous, one photograph run full-bleed to the viewport edge, one sentence at display size with nothing else near it, one element deliberately overlapping the boundary between two sections. Commit to that one moment, make it genuinely bigger or bolder or more spatially confident than anything else on the page, then deliberately quieten everything around it so it has room to land.

This matters more than it sounds. Distributing emphasis evenly across every section -- each one equally well-composed, equally padded, equally sized, every band carrying the same weight as the last -- is the most reliable structural signature of a machine-made page. A human designer is decisive: they pick a favourite, spend the page’s attention budget on it, and let everything else recede into support. Evenness reads as competent and forgettable; hierarchy reads as authored.

Three habits follow from committing to that moment, and all three are wanted. Contrast the type scale violently rather than timidly -- a 14px caption sitting beside 90px display type, not a page where every size lives between 11px and 24px. Vary section weight -- at least one section unusually short (a single line, a thin strip) and at least one unusually tall or full-bleed, rather than every band carrying the same comfortable vertical padding. And exactly once per page, let one element break its container: bleed off an edge, overlap the section above, hang into the margin. Once is a decision and reads as confidence; three times is noise and reads as an accident.

Forms: if the page needs one, write a real <form> with real fields -- never a decorative arrangement of inputs. Every input, textarea and select MUST carry a name attribute in snake_case describing the data (name='full_name', name='phone', name='service_needed'), because the form's submissions are delivered by whatever service the designer connects it to, and a field without a name arrives empty or not at all. Give every field the right type (type='tel' for phone, type='email' for email), mark the genuinely required ones required, and pair each with a real <label for> or an aria-label -- never rely on placeholder text as the only label. Do NOT put an action or method on the <form> tag and do NOT invent an endpoint URL: the designer wires the destination up afterwards in CodeCraft's Page Editor, and a made-up action silently sends real leads nowhere.`;
}

function aiFunnelDoctrineText(fontOptions) {
  return `Copywriting principles for every section:
- Hero headline: lead with the transformation/outcome the visitor wants, not just a feature list or the product name.
- CTA button text: describe the action or result, not a generic verb -- avoid bare "Submit" / "Click Here" / "Learn More" / "Get Started" in favor of something specific to the offer. Keep it to 2-5 words that fit on one line -- a CTA label that would wrap to two lines at desktop width is a fail, shorten it rather than widen the button.
- One label per intent, reused verbatim everywhere that intent appears on the page: if the primary action is "booking a call," every button/link for it uses the exact same words (navbar, hero, final CTA, guarantee) -- do not vary it into synonyms like "Book Now" in one spot and "Schedule a Call" in another, that reads as two different actions, not one consistent one.
- Features/benefits: never list a raw feature alone -- connect it to the mechanism and the outcome (FEATURE -> MECHANISM -> BENEFIT).
- Address the strategy brief's real objections directly in FAQ/guarantee/trust copy rather than generic reassurance.
- Keep every CTA across the page pointed at the same single primary action -- secondary or micro-copy text should never visually or verbally compete with it.
- Never open a section's copy with "We" or the company name -- lead with the customer's outcome or problem instead.
- Vague value propositions are a conversion risk, not just a style issue -- push every claim toward specificity: who exactly, what outcome exactly, how fast/how much exactly.
- Hero discipline: the headline is max 2 lines at desktop and the subheading is max ~20 words. An eyebrow line above the headline is optional and only earns its place when it adds real information; never stack an eyebrow AND extra trust/pricing microcopy into the hero.
- Eyebrow-style labels are rationed, not automatic -- use one on at most every third section, never on every section.
- A numbered marker (1/2/3, Step 1/Step 2) is only correct when the content is a genuine ordered sequence the reader needs to follow in that order. Never apply numbering to content that isn't actually sequential.
- Testimonial/review quotes: 1-3 sentences max, short enough to read in a glance.

Writing style -- clarity over cleverness: simple words over complex ones, active voice over passive, confident statements over hedged ones (cut "almost," "very," "really," "just," "simply," "actually"), and no exclamation points.

Conversational register -- the rules above say what to strip out; this says what the copy has to sound like once it is stripped. It must read like a person talking, not a brochure. Use contractions ("it's", "you'll", "won't", "doesn't", "they're") -- writing them out in full is the single loudest signal that copy was composed rather than spoken, and a page without a contraction in it reads as a form letter no matter how sharp the individual lines are. Vary sentence length deliberately: a longer sentence that carries an idea, then a short one that lands it. A page of uniformly clipped sentences does not read as confidence, it reads as a telegram, and visitors leave halfway down. Ask a direct question where a real person would ask one instead of asserting through every single line. Before you commit any paragraph, read it aloud in your head -- if you would not say it that way to someone sitting across a table from you, rewrite it. None of this licenses hedging, filler or exclamation points; cutting those remains mandatory. Warmth and precision are not in tension here, and the goal is both at once.

Treat the business profile's "tone" field as a hard instruction rather than a hint, second in authority only to the rules above. Two businesses with different tone values must not come out sounding like the same writer: an anxious-patient dental practice asking for a warm, unhurried voice and a mobile welder asking to sound like a tradesman talking to tradesmen should differ in vocabulary, sentence rhythm and how directly they address the reader -- not merely in which nouns appear.

Treat the business profile's "visualWorld" field with that same authority, but for how the page LOOKS rather than how it sounds. It is the closest thing you have to the client sitting across a table describing their actual world: the materials they handle, the objects and textures around them, the colours already in that setting, the quality of light in the room where the work happens. Read it before you choose a palette, a shape language, or a single section background, and let what it names turn into real decisions -- colour drawn from the materials it mentions, corner and border treatment drawn from the objects it describes, imagery drawn from the setting it names, spacing and weight drawn from the mood it ends on. Two businesses with different visualWorld values must not arrive looking like one designer's house style with the nouns swapped.

Where this field contradicts a general default stated anywhere in this doctrine -- including the section pacing advice about alternating light and dark treatments -- the field wins, and it is not close. A general rule describes what usually works for an unknown business. This field describes what this specific client actually asked for, in their own words, about their own premises. A page that overrules it has ignored the brief, however handsome the result. Where the field is empty, infer that world from the trade itself rather than defaulting to whatever currently reads as modern web design.

Avoid these specific phrases and sentence-opener patterns -- they are the most overused AI-writing tells and instantly signal generated copy regardless of how good the underlying idea is: ${AI_TELL_PHRASES_TEXT}. If a sentence would read naturally with one of these removed, remove it.

Never use an em dash (—) or an en dash used as a punctuation separator (–) anywhere in any copy field -- not in headlines, eyebrows, button text, quotes, captions, or body copy. This is a hard rule, not a style preference: it is the single most recognizable LLM-writing tell that exists, more than any banned phrase above. Use a period, a comma, or a regular hyphen (-) instead. Date/number ranges also use a regular hyphen, not an en dash.

Never fabricate specific proof: do not invent review counts, revenue numbers, conversion rates, "500+ customers"-style stats, awards, or media mentions that aren't present in the saved business profile or strategy brief, and never attach a fabricated specific outcome or backstory to a testimonial (a made-up dollar figure, a made-up before/after result, a claim that reads as a verifiable fact rather than a generic sentiment).

For testimonial attribution specifically, use the same convention real sites actually use, even for placeholder-style entries: a first name plus last initial, paired with a short role or context tag on its own line -- e.g. "Wilson S. | Business Owner", "Maria T. | Verified Customer", "A First-Time Order" is the wrong shape; a first-name-plus-initial format is the right one. This is NOT the fabrication this rule bans -- an invented first-name-plus-initial reads as an anonymized real customer, the standard convention on every professional site, not as a specific identifiable, verifiable person. What's still banned is a fabricated full name, a fabricated company/employer name, or a fabricated specific quantifiable result inside the quote itself.

Video testimonials: real testimonials/reviews sections aren't all-text on every site -- some of the strongest social proof on the web is a short video testimonial, and this tool supports that. In a reviews/testimonials section, sometimes (not every generation, and never the whole section) render one of the testimonial entries as a video testimonial instead of a text quote: a \`<div>\` carrying the exact attribute \`data-ai-video-slot="true"\` (the same bounded-video convention as the general Video rule above), sized as a responsive box matching the other testimonial cards in that section (a 4:5 or 1:1 aspect ratio often reads more like a real customer-filmed clip than a 16:9 box, though 16:9 is fine too), with a short line of copy inside naming who it's from (e.g. "Watch Maria's story"), plus the same "Firstname L. | Role" attribution caption below it. Reach for this specifically when video proof is a natural fit for how this business is actually experienced or sold -- fitness, beauty, food/hospitality, home services, coaching, events, physical products people show off on camera -- and skip it for businesses where a customer filming a video testimonial would be unusual (most B2B software, professional/legal/financial services, quiet back-office tools). When you do use it, mix it into a section that's still mostly text quotes (one video among several text cards reads as authentic; a wall of video slots reads as an unbuilt placeholder page) -- never convert every testimonial in a section to video, and don't force a video slot into every business's reviews section just for variety.

Real reviews and awards: check the saved business profile's "reviews" and "awards" arrays before writing anything for a testimonials or trust/credibility section. If real reviews are present, use THEM as the primary content of that section (their real quote/name/role, verbatim) instead of inventing anonymized ones -- only invent additional generic entries to round out the section if there are fewer real reviews than the section needs, and never invent one that reads as more specific or more impressive than the real ones already provided. A real review's "photoUrl", when present, is an already-real photo, not a placeholder to be swapped later -- render it directly as \`<img src="[that exact photoUrl]" alt="[the reviewer's name]">\` (no SVG placeholder, no \`data-ai-image-slot\` attribute) sized as a small round or square avatar next to the quote. A real review's "videoUrl", when present, is an already-real video, not something the designer adds later -- embed it directly instead of using the \`data-ai-video-slot\` placeholder convention: for a YouTube link, \`<iframe src="https://www.youtube.com/embed/[video id]" style="width:100%;height:100%;border:0;display:block;" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>\`; for a Vimeo link, the equivalent \`https://player.vimeo.com/video/[id]\` iframe; for a direct file URL (.mp4/.webm/.ogg/.mov), \`<video src="[that exact videoUrl]" controls style="width:100%;height:100%;display:block;"></video>\`; for any other URL, a plain iframe pointed at it. Wrap whichever embed you use in a responsive aspect-ratio box the same way the placeholder convention does. Real "awards" entries with an "imageUrl" are real badge/logo images -- when a trust or credibility section calls for showing them, render each directly as \`<img src="[that exact imageUrl]" alt="[the award's name]" style="height:44px;width:auto;object-fit:contain;">\` (or a similar small logo-strip treatment), never invent a placeholder graphic for an award that has no imageUrl -- just state its name as text instead.

Color identity: commit to a bold, distinctive 2-3 color identity across the page's own background, text, border, and accent colors in your CSS -- a genuinely dominant color plus one strong contrasting accent, not muted tints of the same safe blue/navy. If the saved business profile includes brand colors, build the identity around them; otherwise pick a real point of view that fits the industry and tone. Keep every color combination readable (strong contrast between text and background).

Give every colour a JOB before you write a line of CSS, rather than choosing a few colours you like and deciding as you go. Settle all of these first, and then hold to them for the whole page: the dominant page background; the contrasting background used for the sections that break the rhythm; what a card or panel sits on when it is on the dominant background, and what it sits on when it is on the contrasting one; the body text colour for each of those two backgrounds; the single saturated accent; and the text colour that sits on that accent. This is not more colours than the identity above allows. Several of these are tints of the same two or three colours -- a surface can be a shade away from the background it sits on and still do its job. What matters is that every one of those questions has an answer before you start, because the ones you have not answered are the ones that get skipped.

The one that goes wrong, reliably, is the surface. When a card, a panel, a quote block or a stat tile is meant to read as a distinct object lifted off the page, it must sit on a background of its own that differs from the section behind it. Reaching for a border instead is the specific failure this rule exists to prevent: a bordered block sharing its section's background does not read as an object, it reads as some text with a line near it, and a page full of those reads as flat no matter how good the type is. A border ON TOP of a distinct surface is good. A border INSTEAD of one is the thing to stop doing. If you cannot say what colour a card sits on, you have not finished choosing the palette.

This is about objects, not about every rule on the page. A list of questions separated by hairlines, a spec list, a row of steps divided by rules: those are typographic devices and are right as they are. Do not give them backgrounds. The test is whether the thing is meant to look like a card. If it is, it needs a surface. If it is meant to look like a well-set list, leave it alone.

Avoid the three most overused AI-generated identity clichés regardless of industry: ${CLICHE_PALETTE_TEXT}. Every accent/CTA color across the page is a single, deliberate role, not decoration -- do not let a section smuggle in a second competing accent hue.

Color consistency lock: once the page's accent hex value is established, reuse that EXACT hex in every color/background/border/box-shadow declaration across every other section that needs an accent -- never a different, unrelated hue in a later section. This applies to any gradient pair too -- build every gradient from the page's own established colors, never introduce a new color family that isn't part of the committed palette.

Typography: choose the page's font-family value(s) ONLY from this list of fonts this tool can actually load -- pick ONE (or at most two, if a section genuinely needs a different register) to carry every heading and every paragraph of body copy on the page: ${JSON.stringify(fontOptions)}
Use the exact string from that list in every section's own "font-family" CSS declaration (set it explicitly wherever you set typography, don't just rely on inheritance), and echo every value you actually used, verbatim, in the top-level "fonts" array so it can be loaded. Reach for a serif face only when the mood genuinely calls for it -- never as a reflexive default.
Optional third face, utility/mono only: on top of that one-or-two-font system, you may ALSO reach for a single monospace face from the same list (e.g. a mono font) strictly for small "stamped" utility text that is never a heading or a sentence of body copy -- a step number, a timestamp-style caption, a data label, a price tag. Never use it for a headline, a paragraph, or a CTA button label, and never introduce a second non-mono third face on top of your heading/body pair.

Images: this tool now supports real uploaded photos, so don't avoid image-dependent layouts -- place a real \`<img>\` element wherever a photo would genuinely strengthen a section (a hero, a team/about photo, a product shot, a location or workspace shot), the same way a real design agency would. Give every image slot: a placeholder \`src\` (an SVG data URI rectangle sized to roughly match the slot, e.g. \`data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='600'%3E%3Crect width='800' height='600' fill='%23e5e0d8'/%3E%3C/svg%3E\`) whose fill is a tone from THIS page's own palette rather than a generic grey -- swap that hex for one of your own committed colours, a quiet one that sits with the section it lands in, a descriptive \`alt\` naming what the photo should actually show, the exact attribute \`data-ai-image-slot="true"\` (so the designer can click it later to upload a real photo -- always this literal attribute and value, never a different name or a numeric id), and normal responsive CSS (\`width:100%;height:auto;object-fit:cover\` plus whatever border-radius/shadow matches the section's own style) targeting that image through its own section-scoped class.\n\nDesign what an UNFILLED slot looks like, because that is the state the page will actually be seen in first. Almost nobody uploads photographs before they look at the page, so the designer and their client meet a version of it where every photo is still missing. A bare rectangle in that state reads as a broken page rather than an unfinished one, and it makes an otherwise well-composed layout look cheap. So build the slot as a composed plate rather than a naked box: give it a mount that belongs to the section's own visual language -- a framing rule, corner marks, a tinted field, a caption line naming what will sit there -- so that a page with no photographs in it yet still reads as deliberate and merely unfilled. Aim for what a good print layout looks like before the plates are pasted in, not for a wireframe.\n\nTwo hard constraints on that. First, whatever you build has to look right in BOTH states: the mount stays on the page after a real photograph is dropped into the slot, so it must frame an actual photo at least as well as it frames an empty field. Second, never put the explanatory text INSIDE the image element itself -- the \`src\` is replaced wholesale when a real photo arrives, so anything drawn into that SVG vanishes with it. Put it in a caption, a label or a small mark beside the image, where it survives and still reads correctly once the photograph is there. Don't force an image into every section -- many sections (FAQ, a stat strip, a short CTA band) are stronger with zero images; place one only where a photo is genuinely the strongest way to make the point, and vary WHERE it sits across the page (hero, about, a card grid, a testimonial) rather than repeating the identical split-image-left/right shape in three different sections.\n\nSome trades are believed on what you can see. A welder, a roofer, a landscaper, a detailer, a joiner, a baker, a tattooist, a groomer, a stonemason: the only question the visitor actually has is "is this person any good", and the honest answer is the finished work. When that is the business, the photographs ARE the argument and the words sit alongside them -- so decide what the page has to prove, then let the pictures carry it. In practice that means the hero shows the work rather than a flat colour field, and at least one section is a RUN of several jobs rather than one lonely shot, because a single photo reads as a stock image while four read as somebody's portfolio. The restraint above still governs the rest of the page -- an FAQ and a price band are still stronger with none -- but do not ration the proof section itself. This is about which businesses live or die on visible craft, NOT about photogenic subjects: a clinic, a solicitor, an accountant, an insurance broker or a SaaS is trusted on credentials, plain speaking and explanation, and pouring photographs into one of those makes it look like a brochure.\n\nA consequence worth stating plainly: a video-background hero shows a flat dark rectangle until somebody supplies footage. A national brand has footage. A one-van tradesman does not, and never will. So for any small local operator, prefer a real photo behind the hero over a video background -- choosing video there means shipping a page whose first screen is an empty black box, which is worse than the plainest honest photograph.

Video: only when a video genuinely fits (a product demo, a walkthrough, a founder or testimonial clip) -- never force one in, most funnels need zero. Wrap it in a \`<div>\` carrying the exact attribute \`data-ai-video-slot="true"\` (always this literal attribute and value), sized as a responsive 16:9 box (\`aspect-ratio:16/9;width:100%;\` plus your section's own border-radius/shadow/background), with a short line of copy inside naming what the video will show (e.g. "See the darkroom in 60 seconds") so the section still reads correctly before a real video is added. Do not put a \`<video>\` or \`<iframe>\` element inside it yourself -- the designer adds the real embed afterward.

Video-background hero (optional, Hero only, use sparingly): when a full-bleed video behind the hero's headline genuinely fits the business (e.g. a before/after transformation clip, footage of the actual work or space, a live-action mood shot) -- not a default, only reach for this when a real video like that would clearly outperform a static hero. Build it as: the hero's own root element gets \`position:relative;overflow:hidden;\`; its FIRST child is a \`<div>\` carrying the exact attribute \`data-ai-video-bg-slot="true"\` (always this literal attribute and value, never combined with \`data-ai-video-slot\` on the same element) styled \`position:absolute;inset:0;z-index:0;background:#0c0c0f;\` (a plain dark placeholder fill, no text or icon inside it); immediately after it, a scrim \`<div>\` styled \`position:absolute;inset:0;z-index:1;pointer-events:none;background:linear-gradient(180deg, rgba(0,0,0,0.55), rgba(0,0,0,0.4));\` (adjust the darkness to whatever keeps your heading/subhead/CTA at WCAG AA contrast against a real video playing under it -- err darker, not lighter); then the hero's actual headline/subhead/CTA content wrapped in its own \`<div>\` styled \`position:relative;z-index:2;\` so it sits above both layers. This only supports a direct video file or a YouTube link the designer adds afterward (never Vimeo or other embeds) -- so only choose it when that's a realistic fit for the business, not for every hero.

Section pacing: don't make every section the same light background -- alternate light and dark section treatments deliberately in your CSS to create visual rhythm. Treat a dark section as a deliberately composed dark surface, not a simple inversion of a light section.

Contrast is a hard requirement, not a suggestion: every section's text/heading color against its own background must clear WCAG AA for body text (roughly 4.5:1).

The rules above are the baseline every CodeCraft copy-drafting call already follows. Because this is the fully autonomous "AI Funnel" pass authoring real markup with no library to anchor structure or identity, apply this additional design doctrine -- organized below by source, so every rule traces back to a real design discipline, not a vague "be tasteful":

=== From Frontend Design ===
Before settling on anything, reason like a design lead: name the one thing that is actually specific to THIS business's own world (its materials, its actual work, its real differentiator below) -- then let that be the source of at least one deliberate, memorable choice on the page (a headline built from the business's own vocabulary, a structural emphasis on the thing that makes them different, a color choice justified by something real about them, not "because it's on-trend"). Treat this choice as the page's signature element. The hero is a thesis for the whole page, not just a headline slot -- open with the single most characteristic thing about this specific business. The first screen also has to carry the argument on its own, because plenty of visitors read it and nothing else. Someone who sees only the hero should meet the claim AND at least one concrete reason to believe it -- not merely what this business does, but why they are worth taking seriously. The saved profile usually already holds that reason in its credibility, guarantee and USP fields: years in the trade, a certification, a licence, a count of jobs done, a guarantee worth naming out loud. Give some of that real visual weight inside the first screen rather than saving all of it for a credentials strip further down the page, where a visitor who never scrolls never meets it. This licenses nothing invented: use only what is actually on file, and where there is no number to use, lead with the most concrete verifiable fact there is instead of reaching for a plausible-sounding one. Match execution complexity to the vision: a quiet, minimal business earns precision in spacing and restraint, not more decoration; a bold, energetic business earns real boldness, not a timid version of it.

Ground the VISUAL VOCABULARY in this business's real-world industry, not just the copy and the one signature element -- this applies to every shape and interaction-pattern choice on the page, not only the hero. The specific thing to avoid is the software-marketing costume: floating phone or app-notification mockups, chat-bubble motifs, browser-frame screenshot illustrations, and the weightless pastel gradient every SaaS landing page shares. Those are borrowed from a tech product's marketing site and belong only on a business that genuinely is a software product or app, never as a default "modern web design" register.

What is NOT that costume, and is not discouraged: depth, layering, shadow, generous curvature, tinted panels, a card that overlaps the thing behind it, a badge sitting proud of an image, a decorative field behind the type, a framing device around a photograph. Those are ordinary tools of graphic design and predate the web by a century. A print designer laying out an estate agent's brochure, a private clinic's mailer or a hotel's rate card reaches for every one of them. Whether a page reads as expensive or as cheap has almost nothing to do with whether its elements overlap, and almost everything to do with whether the ornament came from this business's own world or from a template.

So the question to ask before finalising the shape language is not "is this decorated?" but "is this decoration THIS client's?". A mobile welder earns hard edges, structural geometry and material honesty, because that is the trade's real visual culture and a floating pastel card would be a costume on it. A luxury estate agent, a private aesthetic clinic, a jeweller, a fine-dining room or a premium salon earns the opposite: layered composition, real depth, considered ornament, a metallic or jewel accent, generous framing -- because THAT is those trades' actual visual culture, in their print work and in their own premises. Stripping it out to look restrained does not make such a page tasteful, it makes it read as a cheap version of the business. Match the level of richness to the register the business actually occupies, and take that register from the visualWorld field and the trade itself rather than from a default setting of your own. Then ask the check that still matters: would a designer who actually specialises in this specific industry make these exact border-radius, depth, container and layout choices, or is this simply "how the internet designs things by default right now" applied regardless of who the client is?

Light, warm and playful registers are not lesser. The rule above bans reaching for rounded-everything, pastel-tinted, floating-card SaaS vocabulary as a DEFAULT dressed up as "modern web design" -- it does not ban lightness, softness or warmth themselves. Some businesses genuinely live in that register, and for them a dark, dense, editorial page is exactly the same failure as a pastel gradient on a welding company: a house style imposed over the client's actual world. A children's dentist, a bakery, a florist, an ice cream shop, a party planner, a nursery, a toy shop, a craft class for kids -- these are light by nature. Give them light. Rounded corners are correct when the business itself is soft; generous pale space is correct when the business is calm; a genuinely bright, high-key palette is correct when the business is cheerful. Withholding those because they superficially resemble software marketing is its own kind of template. What separates a warm page that works from pastel slop is the same thing that separates good copy from filler: specificity. A bakery's warmth should come from what a bakery actually contains -- flour-dusted surfaces, brown paper, enamel trays, hand-lettered prices, the colour of crust -- not from a generic mint-and-blush gradient behind floating cards with soft drop shadows. Draw the palette, the shapes and the textures from that trade's real materials, the same way an industrial business draws from steel and a law firm draws from paper and ink. Before settling on a dark or heavily restrained treatment, ask whether it is genuinely right for this business or merely the safest-looking option: seriousness is not a synonym for quality, and a page can be warm, bright and even funny while still being precise, well-composed and free of every tell listed above.

=== From Taste ===
Split-header ban: never use "big headline on the left, small explainer paragraph floating on the right" as a section header -- if a section needs both a headline and body copy, stack them vertically. Content density discipline: default section shape is a short headline (roughly 8 words or fewer) plus a short sub-paragraph (roughly 25 words or fewer) plus one visual/CTA moment -- no data-dump sections. No fake-precise stats: never invent numbers like "99.9%" or "500+ customers" that aren't grounded in the business/strategy data actually provided. No startup-slop invented names: if the page needs to reference a plan tier, program, or feature not in the business profile, give it a plausible, specific, on-brand name, not a generic placeholder like "Premium Plan." Palette direction: pick ONE of these named directions -- do not invent a palette outside this list, and do not fall back to a generic purple/violet/magenta accent, which is banned above regardless of background color: Cold Luxury (silver-grey, chrome, smoke), Forest (deep green, bone, amber accent), Black and Tan (true off-black plus warm tan, sharp contrast, no beige), Cobalt + Cream (saturated blue against one warm neutral), Terracotta + Slate (warm rust against cool grey), Olive + Brick + Paper (muted olive plus brick-red accent), or Pure Monochrome + One Saturated Pop (off-white, off-black, one bright accent -- the accent must be a real, deliberate hue chosen for the business, e.g. amber, emerald, cobalt, or brick-red, never a default purple/violet). Adapt the chosen direction's specific hues to the business (exact shade, not the literal example hex), but the direction itself and its hue family are not optional.

=== From Impeccable ===
Hero-metric-template ban: never default to "big number + small label + stat row + gradient accent" as the hero shape -- it is its own recognizable AI-page-builder tell, independent of the palette clichés above. Uniform-icon-card-grid-as-structure ban: a same-size icon-in-a-card grid may appear as one section, never as the page's dominant repeated structural device across multiple sections. Gradient-text ban: never apply a gradient fill to heading or body text -- emphasis comes from weight or size. Eyebrow ceiling: the "max 1 per 3 sections" rule above is a hard ceiling, not a target to hit.

=== From Emil Kowalski's design-eng philosophy ===
Write real CSS transitions and, where genuinely warranted, small keyframe animations -- interaction and motion are a deliberate design lever now, not a value picked from a list, so choose restraint or expressiveness per the business's actual personality: a serious professional-services or trust-first business should default toward quiet, low-amplitude transitions (a subtle color/shadow shift on hover, no movement) or none at all; a playful or energetic consumer brand can earn real motion (a lift, a scale, a glow) with an easing curve and duration that feels considered rather than default (avoid the browser's default linear/ease timing for anything meant to feel polished -- reach for a deliberate cubic-bezier or a duration that matches the weight of what's moving). Never let an interaction state introduce a color outside the committed palette. The unseen details compound -- small, consistent, deliberate choices (a considered transition duration, a hover state that respects the section's mood) read as considered work even when no single one is individually noticed.

=== From UI/UX Pro Max ===
Touch target discipline: when two CTAs sit side by side, leave clearly visible breathing room between them in your CSS rather than packing them edge to edge. Contrast and text-size floor: if a section's content is dense enough to tempt shrinking the text to fit, shorten the copy instead of shrinking the type. Font pairing by mood, not by habit: choose the font-family value (from the list above) by deliberately matching this specific business's register rather than reaching for whichever font you used last. Icon-as-decoration discipline: where a section uses an icon or emoji as a visual marker, don't default to the same generic emoji set every time -- pick one actually specific to what this business does, or favor plain typography emphasis over an icon crutch when nothing specific fits.

=== From Hallmark's anti-slop craft floor ===
Hero shape: never center every one of eyebrow, headline, subheading, and CTA on the same vertical axis -- pick at most two of those elements to center and give the rest a deliberate off-axis position (margin-aligned, right-flush, or asymmetric), and never combine a full-viewport-height hero with a fully centered stack. Confirm the hero's real content (eyebrow, headline, subheading, primary CTA) would fit above the fold on a 1280x800 viewport without scrolling -- if the display heading's size or line-height would make it run long, tighten the type scale rather than letting the hero bleed past the fold. Bottom hero padding should be visibly heavier than top padding (roughly 1.3x or more), never symmetric or top-heavy.

Never use pure #000000 or #ffffff as a base background/text color -- tint every near-black or near-white neutral toward the section's own accent hue by a small amount so it never reads as flat. Never build a fake browser-chrome bar (URL pill plus traffic-light dots), a fake phone frame (rounded rectangle plus notch), or a fake code-editor window around a code block or screenshot -- this is one of the most recognizable "AI built this" tells; use a real image slot instead, or drop the chrome and let the content stand alone. Icon discipline, sharpened: never mix two different icon visual styles (e.g. outline and filled) on the same page, and never use a raw emoji glyph as a feature-card, pricing-tier, or numbered-step icon -- build a small inline SVG or drop the icon in favor of typography emphasis. Give any decorative SVG or CSS-drawn shape with no informational content \`aria-hidden="true"\`.

CSS motion and interaction discipline: never write \`transition: all\` -- name the exact properties transitioning. Only animate \`transform\` and \`opacity\` for hover/interaction effects -- never animate \`width\`, \`height\`, \`top\`, \`left\`, \`margin\`, or \`padding\`. Never stack more than one hover effect on the same element (pick one of translate/scale/shadow/color, not several at once), and never apply the identical hover-scale value across many unrelated elements on the page -- that reads as a copy-pasted utility class, not a considered choice. Every \`:focus-visible\` style must appear instantly (no transition-delay on the ring itself), and every \`transform\`/\`@keyframes\` animation you write should have a \`@media (prefers-reduced-motion: reduce)\` fallback that removes or shortens it. Every interactive element (button, link, input) needs distinct default, hover, \`:focus-visible\`, \`:active\`, and disabled styling -- not just default and hover. Keep every padding/gap/margin value on a consistent scale (multiples of 4px) rather than arbitrary numbers, and keep any prose paragraph's \`max-width\` in the 45-75ch range so lines stay readable.

Structural fingerprints to actively avoid: a navbar that is wordmark-left, four to five plain text links, a CTA button right, with a thin hairline bottom border on a plain white bar is the single most recognized AI-default nav -- vary at least one of logo position, link treatment, or background from that shape. A footer that is exactly four link columns (labeled like Product/Company/Resources/Legal) over a social-icon row over a copyright line is the equivalent AI-default footer -- vary its column count, structure, or content mix. Never let heading or display-size text be italic (\`font-style: italic\` on any heading-level element) -- headings are always roman; italics belong only on a single emphasized word inside a body-copy sentence, never a whole heading. Any flex row mixing a button with plain text (e.g. a nav's link row plus its CTA) needs explicit \`align-items:center\` so the button doesn't stretch taller than its sibling text.

Contrast, sharpened: never let button text sit within roughly 5% lightness of its own button-fill color -- that is the specific washed-out/black-on-black button failure mode. When a section's background is dark, explicitly set every one of its text elements to a light color in that same rule -- never rely on inheritance from a lighter ancestor. Any clickable text -- not just CTA buttons, also nav links, footer links, and tab labels -- must never wrap to two lines at any width; shorten the label rather than letting it wrap. If a video slot is the largest element in the hero, never suggest autoplay-with-sound in its caption copy, and keep its placeholder box visually complete on its own (per the video instructions above) so nothing renders as an empty gap before a real embed is added.

=== Design-system discipline (commit before drafting, hold for the whole page) ===
Before drafting any section, commit to a small design-token system and hold it for the entire page, the same way a paid design agency shows a client one consistent system rather than a different look per section. (1) Border-radius language: pick one scale (sharp/0px, tight/6-8px, soft/12-16px, or pill/999px reserved for pill-shaped elements only) and reuse that exact radius on every card, button, image, and input across every section -- never mix sharp and heavily rounded corners without a deliberate reason tied to the business. (2) Shadow language: pick one treatment -- no shadow at all, one soft ambient shadow, or one hard offset/bordered shadow -- and reuse it with the same blur/spread/offset values everywhere a shadow appears; never let one section use a soft shadow and another use a hard offset shadow. (3) Shared content width: pick ONE max-width value (commonly 1100-1280px) and use it as every section's own content-container width, so the page reads as one continuous document instead of sections with an inconsistent measure. (4) Spacing scale: pick a small set of spacing values (e.g. 8/16/24/32/48/64/96px) and draw every padding, gap, and margin from that set only, never an arbitrary one-off number.

=== Persuasion-narrative sequencing ===
Sequence sections as a persuasion argument, not just a set of relevant types. For cold or low-trust traffic, establish credibility (trust/about/proof) before or immediately after the hero, ahead of any hard ask. Place proof/testimonials where skepticism peaks, typically right before pricing or the final commitment. Resolve the strategy brief's real objections (via FAQ, guarantee, or a dedicated objection-handling section) before the final CTA, not after it. Let the final section close on the single strongest reason to act now, not a repeated generic recap. Reason about this order explicitly before finalizing the section list -- a technically well-styled page that asks for the sale before it has earned trust is a strategy failure, not just a design one.

=== Micro-typography ===
Large display type (any heading above roughly 32px) reads more considered with slightly tightened letter-spacing (around -0.01em to -0.03em) rather than default or loose tracking -- apply this to hero headlines and major section headings. Body copy and small labels keep normal or slightly open tracking as already covered above.

Treat the business's real differentiator below as the actual design brief, not background trivia -- every structural, palette, and copy choice above must be traceable back to it, not to the business's industry category alone.`;
}

function buildPageSectionEditSchema() {
  return {
    type: 'object',
    properties: {
      html: { type: 'string' },
      css: { type: 'string' },
      message: { type: 'string' }
    },
    required: ['html', 'css', 'message'],
    additionalProperties: false
  };
}

/* Same shape as the edit schema plus "type": a new section has no type yet, and the canvas uses it
   for the little label on hover, so the model names its own section rather than everything arriving
   as "section". */
function buildPageSectionAddSchema() {
  return {
    type: 'object',
    properties: {
      type: { type: 'string' },
      html: { type: 'string' },
      css: { type: 'string' },
      message: { type: 'string' }
    },
    required: ['type', 'html', 'css', 'message'],
    additionalProperties: false
  };
}

/* The funnel interview is a conversation, but the client needs three things back from every turn
   rather than prose: the next question to put on screen, whether the expert has heard enough, and
   the running brief. The brief is rebuilt on EVERY turn, not just the last one, because the
   designer can hit "Generate My Funnel" mid-interview -- so there has to always be a complete,
   usable brief on hand, never a half-finished one. */
function buildFunnelInterviewSchema() {
  return {
    type: 'object',
    properties: {
      question: { type: 'string' },
      done: { type: 'boolean' },
      brief: { type: 'string' }
    },
    required: ['question', 'done', 'brief'],
    additionalProperties: false
  };
}

/* The interview is passed as question/answer pairs rather than as an Anthropic message history.
   Every other mode here sends structured data and lets the server compose the prompt, and a real
   message array would have to open with a user turn the designer never actually typed. */
function interviewTranscriptBlock(transcript) {
  if (!transcript.length) {
    return '\n\nTHE INTERVIEW SO FAR\nNothing yet. This is the very start -- ask your opening question.';
  }
  const lines = transcript.map((t, i) => `Q${i + 1}, you asked: ${t.question}\nA${i + 1}, the designer answered: ${t.answer}`);
  return `\n\nTHE INTERVIEW SO FAR\n${lines.join('\n\n')}\n\nYou have asked ${transcript.length} question(s) so far.`;
}

function briefSchema() {
  return {
    type: 'object',
    properties: {
      key: { type: 'string' },
      title: { type: 'string' },
      audience: {
        type: 'object',
        properties: {
          whoTheyAre: { type: 'string' },
          corePain: { type: 'string' },
          coreDesire: { type: 'string' }
        },
        required: ['whoTheyAre', 'corePain', 'coreDesire'],
        additionalProperties: false
      },
      offer: {
        type: 'object',
        properties: {
          description: { type: 'string' },
          price: { type: 'string' },
          priceTag: { type: 'string' },
          xFactor: { type: 'string' },
          conversionGoal: { type: 'string' }
        },
        required: ['description', 'price', 'priceTag', 'xFactor', 'conversionGoal'],
        additionalProperties: false
      },
      objections: {
        type: 'object',
        properties: {
          primary: { type: 'array', items: { type: 'string' } },
          proofAssets: {
            type: 'array',
            items: {
              type: 'object',
              properties: { text: { type: 'string' } },
              required: ['text'],
              additionalProperties: false
            }
          }
        },
        required: ['primary', 'proofAssets'],
        additionalProperties: false
      },
      traffic: {
        type: 'object',
        properties: {
          source: { type: 'string' },
          trustLevel: { type: 'string', enum: ['Low', 'Medium', 'High'] },
          microWinEntryPoint: { type: 'string' }
        },
        required: ['source', 'trustLevel', 'microWinEntryPoint'],
        additionalProperties: false
      },
      messaging: {
        type: 'object',
        properties: {
          angleName: { type: 'string' },
          angleDescription: { type: 'string' },
          primaryAngle: { type: 'string' },
          tone: { type: 'string' },
          copyApproach: { type: 'string' },
          keyMessages: { type: 'array', items: { type: 'string' } },
          copyStructure: { type: 'string' }
        },
        required: ['angleName', 'angleDescription', 'primaryAngle', 'tone', 'copyApproach', 'keyMessages', 'copyStructure'],
        additionalProperties: false
      },
      funnelType: {
        type: 'object',
        properties: {
          type: { type: 'string' },
          reasoning: { type: 'string' }
        },
        required: ['type', 'reasoning'],
        additionalProperties: false
      }
    },
    required: ['key', 'title', 'audience', 'offer', 'objections', 'traffic', 'messaging', 'funnelType'],
    additionalProperties: false
  };
}

function buildStrategySchema() {
  return {
    type: 'object',
    properties: {
      candidates: { type: 'array', items: briefSchema() },
      recommendedKey: { type: 'string' },
      recommendedReason: { type: 'string' }
    },
    required: ['candidates', 'recommendedKey', 'recommendedReason'],
    additionalProperties: false
  };
}

function buildStrategySetSchema() {
  return {
    type: 'object',
    properties: {
      items: {
        type: 'array',
        items: {
          type: 'object',
          properties: { productName: { type: 'string' }, brief: briefSchema() },
          required: ['productName', 'brief'],
          additionalProperties: false
        }
      }
    },
    required: ['items'],
    additionalProperties: false
  };
}

function buildStrategySetItemSchema() {
  return {
    type: 'object',
    properties: { brief: briefSchema() },
    required: ['brief'],
    additionalProperties: false
  };
}

// Anti-cliché standard the aiFunnel system prompt grades its own output against.
const CLICHE_PALETTE_TEXT = `(1) a warm cream/off-white background paired with a serif display face and a terracotta accent, (2) a near-black background with a single neon-green, vermilion, purple, violet, or magenta accent (any saturated purple/violet/magenta hex, e.g. the #a855f7-to-#e879f9 family, reads as an AI-page-builder default the instant it appears on a dark surface -- this applies even when used as a single flat solid color with no gradient at all), and (3) an indigo-to-violet or blue-to-purple gradient (roughly the #4f46e5-to-#7c3aed family) -- this is the default palette of countless AI page builders and generic SaaS templates, and it is now instantly recognizable as machine-generated. Purple/violet/magenta in general is the single most overused "AI chose this" accent hue -- treat it as off-limits by default regardless of background color, not just on near-black surfaces, unless the business's own saved brand colors specifically call for it.

Check this by HUE, not just by matching a specific hex: convert your chosen accent to HSL in your own reasoning before committing to it. Any accent whose hue falls roughly between 235 and 275 degrees (this entire band reads as indigo/violet/purple regardless of exact saturation or lightness -- it includes hexes like #6a5cff and #7c6cf5 just as much as #a855f7, even though they look like "corporate blue" at a glance) is banned by this rule, full stop. This band is a common drift trap specifically for "professional," "trustworthy," or B2B-feeling businesses reaching for a safe corporate blue -- that instinct is correct, but the execution must land as genuine blue, not indigo. True blue/cobalt (hue roughly 200-225 degrees, e.g. #1d4ed8, #2563eb, #0057c2) is NOT banned and is a legitimate, distinctive choice for exactly those trust-first businesses -- when in doubt between a blue that might be drifting warm toward violet and one that reads unambiguously blue, choose the one that reads unambiguously blue.

The same hue-band check applies on the magenta/pink side: any accent whose hue falls roughly between 270 and 340 degrees (violet through magenta through saturated hot pink) is banned by this rule too, not just the narrower violet band named above -- this specifically includes #ff6ac1, a hex that keeps recurring across unrelated businesses in this tool's own output and is exactly the kind of memorized "AI accent" this rule exists to stop, regardless of how well it might seem to fit a specific business's mood. A warm, playful, or feminine-leaning business is a real and legitimate reason to reach for pink -- but land it as a genuinely warm, somewhat muted rose or blush (lower saturation, hue drifting toward 350-360/0-10 degrees, closer to a dusty rose or terracotta-pink than a saturated hot pink) rather than the saturated, cool-leaning magenta-pink this band describes. When a business's mood calls for pink, that muted-rose execution is the deliberate choice; a bright saturated hot pink is the reflexive one.`;

const AI_TELL_PHRASES_TEXT = `"In today's [industry/digital] landscape," "When it comes to X," "At its core," "It's worth noting that," "That being said," "Let's delve into," "This begs the question," "Whether you're a X or a Y" (false-choice openers), "Look no further," "Unlock the power/potential of," "Take it to the next level," "Seamlessly," "Elevate your," "Game-changing," "In conclusion" (as a paragraph opener), and "Moreover"/"Furthermore" used more than once on a page`;

function businessContextBlock(business) {
  if (!business) return '';
  return `\n\nThe designer has already selected a saved business profile for this funnel -- treat it as authoritative ground truth already on file. Do not ask about anything it already answers; only treat the conversation as an override if the user explicitly states something different. Saved business profile (JSON, includes a real product/service catalog in "products" if any): ${JSON.stringify(business)}`;
}

function productContextBlock(product) {
  if (!product) return '';
  return `\n\nThe designer wants this strategy to focus specifically on ONE product/service from the business's catalog, not the business generally -- ground every section in this offering, not a generic version of the whole business. Focus product/service (JSON): ${JSON.stringify(product)}`;
}

function productSetContextBlock(products) {
  if (!Array.isArray(products) || !products.length) return '';
  return `\n\nGenerate one brief for EACH of the following ${products.length} products/services from this business's catalog, in this exact order -- ground each brief in that specific product, not a generic version of the whole business. Products (JSON array): ${JSON.stringify(products)}`;
}

function setCoreContext(siblingBriefs) {
  if (!Array.isArray(siblingBriefs) || !siblingBriefs.length) return '';
  const core = siblingBriefs.map((b) => ({
    audience: b.audience,
    tone: b.messaging && b.messaging.tone,
    primaryAngle: b.messaging && b.messaging.primaryAngle
  }));
  return `\n\nThis product is one member of a coordinated strategy set for the same business -- the other products in the set already have briefs. Their shared brand core is FIXED and must NOT drift for this product: reuse the SAME audience.whoTheyAre / audience.corePain / audience.coreDesire, the SAME messaging.tone, and the SAME messaging.primaryAngle as the other set members below -- do not rewrite them in different words. Only vary what should differ per product: offer, price, objections, proofAssets, funnelType, and this product's specific messaging angle (angleName/angleDescription/keyMessages/copyStructure/copyApproach). Other set members' shared core (JSON): ${JSON.stringify(core)}`;
}

function strategyContextBlock(strategy) {
  if (!strategy) return '';
  return `\n\nThe designer has already chosen a full strategic brief for this funnel -- design the structure to serve it specifically, not a generic version of its archetype. Strategic brief (JSON): ${JSON.stringify(strategy)}`;
}

function ideaLine(idea, verbPhrase) {
  return idea
    ? `The designer's ${verbPhrase} funnel idea: "${idea}"`
    : `The designer did not describe a specific funnel idea -- infer the funnel concept from the business profile and the stated goal below (if any).`;
}

function goalBlock(goal) {
  if (!goal) return '';
  return `\n\nThe designer has explicitly stated the goal of this funnel: "${goal}". Treat this as the primary objective driving every part of the brief -- the funnelType, the offer's conversionGoal, the messaging angle, and which objections matter most should all be chosen in service of this specific stated goal, not inferred purely from the idea text alone.`;
}

function differentiatorBlock(business, strategy, differentiator) {
  const parts = [];
  if (strategy) {
    if (strategy.offer && strategy.offer.xFactor) parts.push(`X-factor differentiator: ${strategy.offer.xFactor}`);
    if (strategy.messaging && (strategy.messaging.angleName || strategy.messaging.angleDescription)) {
      parts.push(`Messaging angle: ${strategy.messaging.angleName || ''} -- ${strategy.messaging.angleDescription || ''}`);
    }
  } else if (business) {
    if (business.usps) parts.push(`Unique selling points: ${business.usps}`);
    if (business.description) parts.push(`Business description: ${business.description}`);
  }
  if (differentiator) parts.push(`Designer-provided differentiator/context: ${differentiator}`);
  if (!parts.length) return '';
  return `\n\nThe single most important grounding input for this funnel is what makes THIS business genuinely different -- never invent a generic version of "a business in this industry." Every structural and visual decision below must trace back to one of these specifics, not to category/industry defaults:\n${parts.join('\n')}`;
}


// Claude can decline a request on safety grounds. That is NOT an API failure: it comes back as a
// perfectly normal HTTP 200 whose stop_reason is "refusal", carrying no usable content. Left
// unhandled it slips past every `status !== 200` check below, yields no text block, and finally
// surfaces to the user as "the AI response only produced 0 usable sections" -- which blames the
// wrong thing and suggests a retry that will keep failing the same way.
function refusalMessage(respBody) {
  const details = (respBody && respBody.stop_details) || {};
  const category = details.category ? ` (category: ${details.category})` : '';
  const explanation = typeof details.explanation === 'string' && details.explanation.trim()
    ? ` ${details.explanation.trim()}`
    : '';
  return `Claude declined this request on safety grounds${category}, so no page was generated.${explanation} `
    + 'This is a refusal rather than a server error -- retrying as-is will refuse again. Rewording the '
    + 'business details, the differentiator text, or the strategy usually resolves it.';
}

/* Anthropic's own error text is written for developers ("invalid x-api-key"), and CodeCraft is
   about to be used by designers spending their own credits. Every failure a subscriber can
   actually act on gets a message naming the fix and where to do it. Anything unrecognised falls
   through with the original text rather than being flattened into a useless generic. */
const CONSOLE_BILLING_URL = 'https://console.anthropic.com/settings/billing';
const CONSOLE_KEYS_URL = 'https://console.anthropic.com/settings/keys';

function describeApiError(status, respBody) {
  const original = (respBody && respBody.error && respBody.error.message) || '';
  const type = (respBody && respBody.error && respBody.error.type) || '';

  // Credit exhaustion arrives as a 400, so check the message before falling back to status.
  if (/credit balance|insufficient.*credit|too low/i.test(original)) {
    return 'Your Anthropic account is out of credit, so the request could not run. Top up at '
      + CONSOLE_BILLING_URL + ' and try again.';
  }
  if (status === 401) {
    return 'Anthropic rejected your API key. Check it is correct and still active at '
      + CONSOLE_KEYS_URL + ', then update it in the Account tab.';
  }
  if (status === 403) {
    return 'Your API key does not have permission for this request. Check the key\'s scopes at '
      + CONSOLE_KEYS_URL + '.';
  }
  if (status === 404 && /model/i.test(original)) {
    return 'The selected model is not available to your API key. Pick a different model in the Account tab.';
  }
  if (status === 429) {
    return 'Anthropic is rate-limiting your key right now. Wait a minute and try again -- rate limits '
      + 'rise as your account\'s usage tier goes up.';
  }
  if (status === 529 || status >= 500) {
    return 'Anthropic\'s API is temporarily unavailable. This is on their side, not yours -- wait a '
      + 'moment and try again.';
  }
  if (type === 'invalid_request_error' && original) {
    return 'Anthropic rejected the request: ' + original;
  }
  return original || 'Anthropic API error (HTTP ' + status + ').';
}

/* Token usage was being thrown away entirely. On a bring-your-own-key product the running spend is
   the number users most need to see, so totals are accumulated here -- every call, whatever mode --
   rather than being reassembled client-side from whichever responses happened to carry it. */
const USAGE_PATH = path.join(DATA_DIR, 'usage.json');

function readUsage() {
  try {
    const parsed = JSON.parse(fs.readFileSync(USAGE_PATH, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (e) {
    return {};
  }
}

let usageTotals = readUsage();

function recordUsage(modelId, usage) {
  if (!usage) return;
  const input = Number(usage.input_tokens) || 0;
  const output = Number(usage.output_tokens) || 0;
  if (!input && !output) return;
  const t = usageTotals;
  if (!t.since) t.since = Date.now();
  t.calls = (t.calls || 0) + 1;
  t.inputTokens = (t.inputTokens || 0) + input;
  t.outputTokens = (t.outputTokens || 0) + output;
  t.byModel = t.byModel || {};
  const m = t.byModel[modelId] || { calls: 0, inputTokens: 0, outputTokens: 0 };
  m.calls += 1;
  m.inputTokens += input;
  m.outputTokens += output;
  t.byModel[modelId] = m;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(USAGE_PATH, JSON.stringify(t, null, 2));
  } catch (e) {
    // Usage accounting must never break a generation that already succeeded.
    console.error('Could not persist usage totals:', e.message);
  }
}

// CodeCraft sends no cache_control, so there are no cache tiers to price -- plain input/output.
function costFor(modelId, inputTokens, outputTokens) {
  const m = AVAILABLE_MODELS.find((x) => x.id === modelId);
  if (!m) return null;
  return (inputTokens / 1e6) * m.inputPerM + (outputTokens / 1e6) * m.outputPerM;
}

function isRefusal(respBody) {
  return !!(respBody && respBody.stop_reason === 'refusal');
}

function anthropicRequest(payload, overrideKey) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    let settled = false;
    let connectTimer = null;
    let overallTimer = null;

    const clearTimers = () => {
      if (connectTimer) { clearTimeout(connectTimer); connectTimer = null; }
      if (overallTimer) { clearTimeout(overallTimer); overallTimer = null; }
    };
    // Every path below funnels through these two so the promise settles exactly once and no timer
    // is left holding the event loop open.
    const settle = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimers();
      fn(value);
    };
    const fail = (message) => {
      settle(reject, new Error(message));
      req.destroy();
    };

    const req = https.request(
      {
        hostname: 'api.anthropic.com',
        path: '/v1/messages',
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': overrideKey || getApiKey(),
          'anthropic-version': '2023-06-01',
          'content-length': Buffer.byteLength(body)
        }
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('error', (e) => fail('Connection to the Anthropic API failed mid-response: ' + e.message));
        res.on('end', () => {
          let parsed;
          try {
            parsed = JSON.parse(data);
          } catch (e) {
            settle(reject, new Error('Invalid JSON response from Anthropic API'));
            return;
          }
          // Translate a refusal into a non-200 right here, once, so that all nine call sites'
          // existing error branches report it accurately without each needing its own check.
          if (res.statusCode === 200 && isRefusal(parsed)) {
            settle(resolve, { status: 422, body: { error: { message: refusalMessage(parsed) }, refusal: true } });
            return;
          }
          if (res.statusCode === 200) {
            recordUsage(payload && payload.model, parsed && parsed.usage);
            settle(resolve, { status: res.statusCode, body: parsed });
            return;
          }
          // Keep the provider's wording in the server log for debugging, hand the user the
          // actionable version. Rewritten once here so all nine call sites benefit.
          console.error('[anthropic ' + res.statusCode + ']', (parsed && parsed.error && parsed.error.message) || data.slice(0, 300));
          noteError('anthropic ' + res.statusCode, (parsed && parsed.error && parsed.error.message) || '');
          settle(resolve, {
            status: res.statusCode,
            body: { error: { message: describeApiError(res.statusCode, parsed), type: (parsed && parsed.error && parsed.error.type) || 'api_error' } }
          });
        });
      }
    );

    overallTimer = setTimeout(() => {
      fail(`The Anthropic API did not respond within ${Math.round(ANTHROPIC_TIMEOUT_MS / 1000)}s -- the request was cancelled. If this was a large funnel generation, retry or raise ANTHROPIC_TIMEOUT_MS.`);
    }, ANTHROPIC_TIMEOUT_MS);

    connectTimer = setTimeout(() => {
      fail(`Could not connect to api.anthropic.com within ${Math.round(ANTHROPIC_CONNECT_TIMEOUT_MS / 1000)}s -- check your network connection.`);
    }, ANTHROPIC_CONNECT_TIMEOUT_MS);
    // Once the socket is actually connected the short connect deadline has done its job; from here
    // on only the overall timeout applies.
    req.on('socket', (socket) => {
      if (socket.connecting) socket.once('connect', () => { if (connectTimer) { clearTimeout(connectTimer); connectTimer = null; } });
      else { clearTimeout(connectTimer); connectTimer = null; }
    });

    req.on('error', (e) => settle(reject, e));
    req.write(body);
    req.end();
  });
}

/* Mirrors the real interview closely enough to exercise the entire client flow under MOCK_AI=1:
   one question per turn, a brief that is already usable on turn one, and done:true on the fourth
   turn so the "ready to generate" state can be built and tested without spending anything. */
function mockFunnelInterviewResponse(transcript, business) {
  const turn = transcript.length;
  const name = (business && (business.name || business.businessName)) || 'this business';
  const questions = [
    `I can see ${name} on file already. What is the one job they get called out for most, and what does it usually cost the customer?`,
    'When someone goes looking for that, what has usually just happened to them?',
    'What stops people from booking once they have found you?',
    'That is plenty to work with. Hit Generate My Funnel whenever you are ready.'
  ];
  const idx = Math.min(turn, questions.length - 1);
  return {
    question: questions[idx],
    done: idx >= questions.length - 1,
    brief: `Mock brief for ${name}, rebuilt on turn ${turn}. In a real run the offer, the customer's moment, `
      + 'the objection and the proof would be distilled here as plain notes for the page generator.'
  };
}

/* Deliberately passes validateCommitment, so MOCK_AI exercises the whole path rather than the
   error branch. */
function mockDesignCommitmentResponse() {
  return {
    colorRoles: {
      canvas: '#f7f4ee', canvasAlt: '#1d2320', surface: '#ffffff', surfaceAlt: '#2c3430',
      ink: '#22282a', inkAlt: '#eee9df', accent: '#b4451f', accentInk: '#ffffff'
    },
    background: { treatment: 'rule_grid', drawnFrom: 'The ruled ledger paper this mock business keeps its records on.',
      where: 'The credibility section and the pricing section only.' },
    shapeLanguage: { radius: 'tight', shadow: 'soft_ambient', iconStyle: 'outline_svg', fill: 'solid' },
    components: [
      { kind: 'tick_list', where: 'the inclusions block under the offer' },
      { kind: 'icon_rows', where: 'the three-step how-it-works section' },
      { kind: 'faq_accordion', where: 'the objections section near the foot of the page' },
      { kind: 'headline_highlight', where: 'the decisive words in the hero headline' }
    ],
    signatureMove: 'mono_eyebrow',
    signatureRationale: 'A mock commitment used for offline testing, long enough to pass validation.',
    rejectedMoves: [
      { move: 'oversized_numerals', why: 'Nothing about this mock business turns on countable things.' },
      { move: 'outlined_type', why: 'Too loud for the quiet register this mock is pretending to have.' }
    ],
    typeScale: { displayPx: 84, bodyPx: 17, eyebrowPx: 12 },
    rhythm: [
      { tone: 'canvas', width: 'wide', density: 'airy' },
      { tone: 'canvasAlt', width: 'full_bleed', density: 'normal' },
      { tone: 'canvas', width: 'standard', density: 'normal' },
      { tone: 'canvasAlt', width: 'wide', density: 'tight' },
      { tone: 'canvas', width: 'narrow', density: 'airy' },
      { tone: 'accent', width: 'full_bleed', density: 'tight' },
      { tone: 'canvas', width: 'standard', density: 'normal' },
      { tone: 'canvasAlt', width: 'wide', density: 'normal' },
      { tone: 'canvas', width: 'standard', density: 'airy' },
      { tone: 'canvasAlt', width: 'full_bleed', density: 'normal' }
    ]
  };
}

function mockChatResponse(messages) {
  const turn = messages.filter((m) => m.role === 'user').length;
  const replies = [
    "Nice to meet you! What's your business called, and what industry are you in?",
    "Got it, thanks! What's the main product or service you want this funnel to sell, and what's the main goal -- leads, sales, or bookings?",
    "Great, that's plenty to work with. Feel free to add brand colors or a tone if you have one in mind, or just click Generate Funnel whenever you're ready."
  ];
  return {
    reply: replies[Math.min(turn - 1, replies.length - 1)] || replies[replies.length - 1],
    profile: {
      businessName: turn >= 1 ? 'Rivera Plumbing' : '',
      industry: turn >= 1 ? 'Plumbing services' : '',
      offer: turn >= 2 ? 'Emergency plumbing repair' : '',
      brandColors: turn >= 2 ? 'navy and gold' : '',
      goal: turn >= 2 ? 'more leads' : '',
      tone: turn >= 3 ? 'trustworthy, professional' : ''
    }
  };
}

function mockResearchResponse() {
  return {
    reply: "Mock research: competitors in this space tend to emphasize speed and 24/7 availability, and lean on customer testimonials with specific numbers (response time, years in business). Pricing is rarely shown up front -- most funnels push toward a quote/contact step instead. Customers commonly search using urgency language (\"emergency\", \"same day\", \"near me\"), so leading copy with responsiveness and trust signals should perform well.",
    sources: [
      { title: 'Example Industry Report', url: 'https://example.com/industry-report' },
      { title: 'Example Competitor Landing Page', url: 'https://example.com/competitor' }
    ]
  };
}

function strategyBriefFixture(key, title) {
  return {
    key,
    title,
    audience: {
      whoTheyAre: 'Homeowners searching for a plumber during an active problem.',
      corePain: 'Water damage is happening right now and they need someone reliable, fast.',
      coreDesire: 'A fast, trustworthy fix with no surprise costs.'
    },
    offer: {
      description: 'Emergency plumbing repair, dispatched same day.',
      price: 'Free estimate',
      priceTag: 'quote-first',
      xFactor: '24/7 dispatch with a real person answering, not a call center.',
      conversionGoal: 'Call or request a callback within the hour.'
    },
    objections: {
      primary: ['Will they actually show up fast?', 'Is this going to cost a fortune?'],
      proofAssets: [{ text: 'Customer testimonials' }, { text: 'Years-in-business badge' }]
    },
    traffic: {
      source: 'Local search and Google Maps listings',
      trustLevel: 'Medium',
      microWinEntryPoint: 'Free instant quote form'
    },
    messaging: {
      angleName: 'Speed & Trust',
      angleDescription: 'Leads with responsiveness and credibility to convert an urgent, anxious visitor.',
      primaryAngle: 'urgency',
      tone: 'reassuring',
      copyApproach: 'proof-driven',
      keyMessages: ['We answer 24/7.', 'Upfront pricing, no surprises.', 'Licensed and insured.'],
      copyStructure: 'PAS'
    },
    funnelType: {
      type: 'Lead Gen Funnel',
      reasoning: 'Urgent local-service buyers convert best off a fast, trust-building capture page.'
    }
  };
}

function mockStrategyResponse() {
  return {
    candidates: [
      strategyBriefFixture('fast-response-leadgen', 'Fast-Response Lead Capture'),
      strategyBriefFixture('trust-first-booking', 'Trust-First Booking Funnel'),
      strategyBriefFixture('flat-rate-product', 'Flat-Rate Product Offer')
    ],
    recommendedKey: 'fast-response-leadgen',
    recommendedReason: '[MOCK] This audience is skeptical and time-pressed, so a fast, low-commitment capture path removes the most friction before asking for anything bigger.'
  };
}

function mockStrategySetResponse(products) {
  const list = products.length ? products : [{ name: 'Starter Plan' }, { name: 'Pro Plan' }];
  return {
    items: list.map((p, i) => ({
      productName: p.name,
      brief: strategyBriefFixture('set-item-' + i, p.name + ' Strategy')
    }))
  };
}

function mockStrategySetItemResponse(product) {
  return { brief: strategyBriefFixture('set-item-regen', (product ? product.name : 'Product') + ' Strategy (Regenerated)') };
}

function mockGenerateResponse() {
  return {
    sections: [
      { type: 'navbar', state: { logoText: 'Rivera Plumbing' } },
      { type: 'hero', state: { heading: 'Fast, Reliable Plumbing You Can Trust', eyebrow: 'Rivera Plumbing' } },
      { type: 'list', state: { heading: 'Why Choose Us' } },
      { type: 'reviews', state: {} },
      { type: 'cta', state: { heading: 'Need a Plumber Today?' } },
      { type: 'footer', state: { brandText: 'Rivera Plumbing' } }
    ]
  };
}

function mockAiFunnelResponse() {
  return {
    fonts: ["'Inter', sans-serif"],
    sections: [
      {
        type: 'navbar',
        html: `<header class="af-mock-nav-7q2">
  <div class="af-mock-nav-7q2__inner">
    <span class="af-mock-nav-7q2__logo">Rivera Plumbing</span>
    <a class="af-mock-nav-7q2__cta" href="#">Book a Same-Day Fix</a>
  </div>
</header>`,
        css: `.af-mock-nav-7q2 { background: #0f1a14; padding: 16px 32px; }
.af-mock-nav-7q2__inner { display: flex; align-items: center; justify-content: space-between; max-width: 1100px; margin: 0 auto; }
.af-mock-nav-7q2__logo { color: #f4f1ea; font-family: 'Inter', sans-serif; font-weight: 700; font-size: 18px; }
.af-mock-nav-7q2__cta { background: #ff6b35; color: #14100c; font-family: 'Inter', sans-serif; font-weight: 600; padding: 10px 18px; border-radius: 6px; text-decoration: none; }`
      },
      {
        type: 'hero',
        html: `<section class="af-mock-hero-7q2">
  <div class="af-mock-hero-7q2__inner">
    <h1 class="af-mock-hero-7q2__heading">[AI DRAFT] One Call Fixes It Today</h1>
    <p class="af-mock-hero-7q2__sub">A same-day plumber who shows up on time, every time.</p>
    <a class="af-mock-hero-7q2__cta" href="#">Book a Same-Day Fix</a>
  </div>
</section>`,
        css: `.af-mock-hero-7q2 { background: #0f1a14; color: #f4f1ea; padding: 96px 32px; }
.af-mock-hero-7q2__inner { max-width: 640px; margin: 0 auto; text-align: center; }
.af-mock-hero-7q2__heading { font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 700; margin: 0 0 16px; }
.af-mock-hero-7q2__sub { font-family: 'Inter', sans-serif; font-size: 18px; color: #cfc9bc; margin: 0 0 28px; }
.af-mock-hero-7q2__cta { display: inline-block; background: #ff6b35; color: #14100c; font-family: 'Inter', sans-serif; font-weight: 600; padding: 14px 24px; border-radius: 6px; text-decoration: none; transition: transform 0.15s ease; }
.af-mock-hero-7q2__cta:hover { transform: translateY(-2px); }`
      },
      {
        type: 'proof-strip',
        html: `<section class="af-mock-proof-7q2">
  <div class="af-mock-proof-7q2__inner">
    <h2 class="af-mock-proof-7q2__heading">[AI DRAFT] Why Homeowners Call Rivera First</h2>
    <ul class="af-mock-proof-7q2__list">
      <li>Licensed, background-checked plumbers</li>
      <li>Upfront pricing before any work starts</li>
      <li>Same-day appointments, seven days a week</li>
    </ul>
  </div>
</section>`,
        css: `.af-mock-proof-7q2 { background: #f4f1ea; padding: 72px 32px; }
.af-mock-proof-7q2__inner { max-width: 720px; margin: 0 auto; }
.af-mock-proof-7q2__heading { font-family: 'Inter', sans-serif; font-size: 28px; color: #14100c; margin: 0 0 20px; }
.af-mock-proof-7q2__list { font-family: 'Inter', sans-serif; color: #3a352c; font-size: 16px; line-height: 1.8; padding-left: 20px; margin: 0; }`
      },
      {
        type: 'cta-band',
        html: `<section class="af-mock-cta-7q2">
  <div class="af-mock-cta-7q2__inner">
    <h2 class="af-mock-cta-7q2__heading">[AI DRAFT] Get a Same-Day Plumber</h2>
    <a class="af-mock-cta-7q2__button" href="#">Book a Same-Day Fix</a>
  </div>
</section>`,
        css: `.af-mock-cta-7q2 { background: #ff6b35; padding: 64px 32px; }
.af-mock-cta-7q2__inner { max-width: 560px; margin: 0 auto; text-align: center; }
.af-mock-cta-7q2__heading { font-family: 'Inter', sans-serif; font-size: 30px; color: #14100c; margin: 0 0 20px; }
.af-mock-cta-7q2__button { display: inline-block; background: #14100c; color: #f4f1ea; font-family: 'Inter', sans-serif; font-weight: 600; padding: 14px 28px; border-radius: 6px; text-decoration: none; }`
      },
      {
        type: 'footer',
        html: `<footer class="af-mock-footer-7q2">
  <div class="af-mock-footer-7q2__inner">Rivera Plumbing</div>
</footer>`,
        css: `.af-mock-footer-7q2 { background: #0f1a14; padding: 24px 32px; }
.af-mock-footer-7q2__inner { color: #cfc9bc; font-family: 'Inter', sans-serif; font-size: 14px; max-width: 1100px; margin: 0 auto; }`
      }
    ]
  };
}

function mockAiFunnelReviseResponse(sections, fonts) {
  return {
    critique: {
      philosophy: 4, hierarchy: 4, execution: 4, specificity: 3, restraint: 4, variety: 4,
      notes: '[MOCK_AI] No real critique run -- mock mode echoes the draft back unchanged.'
    },
    changesSummary: '[MOCK_AI] No real revision made in mock mode.',
    fonts: Array.isArray(fonts) ? fonts : [],
    sections: Array.isArray(sections) ? sections : []
  };
}

function mockPageSectionEditResponse(section, instruction) {
  return {
    html: section && typeof section.html === 'string' ? section.html : '<div>[mock section]</div>',
    css: section && typeof section.css === 'string' ? section.css : '',
    message: `[MOCK_AI] Applied: "${instruction}" (no real change made in mock mode).`
  };
}

/* Unlike the edit mock, this returns a real, valid, correctly scoped section rather than an echo --
   inserting a section is the thing being tested downstream, so the mock has to be insertable. */
function mockPageSectionAddResponse(description, scopeClass) {
  const cls = scopeClass || 'add-cc-mock';
  const safe = String(description || 'A new section')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return {
    type: 'mock-section',
    html: `<section class="${cls}"><div class="${cls}-inner">`
      + `<p class="${cls}-eyebrow">Mock section</p>`
      + `<h2 class="${cls}-title">${safe}</h2>`
      + `<p class="${cls}-body">This section was produced by MOCK_AI, so no Anthropic call was made `
      + 'and nothing was billed. It is here to prove the insert, undo and export paths work.</p>'
      + '</div></section>',
    css: `.${cls} { padding: 64px 24px; background: #f4f1ec; }\n`
      + `.${cls}-inner { max-width: 720px; margin: 0 auto; }\n`
      + `.${cls}-eyebrow { margin: 0 0 8px; font-size: 12px; letter-spacing: .08em; text-transform: uppercase; color: #6b7280; }\n`
      + `.${cls}-title { margin: 0 0 12px; font-size: 30px; line-height: 1.2; color: #16202b; }\n`
      + `.${cls}-body { margin: 0; font-size: 16px; line-height: 1.6; color: #3f4a56; }`,
    message: '[MOCK_AI] Added a placeholder section. No real generation was run.'
  };
}

async function runSectionDraft(systemPrompt, trailingUserMessage, messages, res, maxTokens = 8192) {
  const payload = {
    model: getModel(),
    max_tokens: maxTokens,
    system: systemPrompt,
    messages: messages.concat([{ role: 'user', content: trailingUserMessage }])
  };
  const { status, body: respBody } = await anthropicRequest(payload);
  if (status !== 200) {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
    return;
  }
  const textBlock = (respBody.content || []).find((b) => b.type === 'text');
  let jsonText = textBlock ? textBlock.text.trim() : '{}';
  jsonText = jsonText.replace(/^```(json)?/i, '').replace(/```$/, '').trim();
  const parsed = JSON.parse(jsonText);
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(parsed));
}

/* Shared by pageSectionEdit and pageSectionAdd. Both modes hand back one section that the
   designer then clicks in the canvas to attach real media, so the placeholder-slot contract has
   to be identical in both -- keeping one copy is what guarantees that. */
const MEDIA_SLOT_RULES = `If the request asks for a picture, photo, or image, insert a real \`<img>\` element -- never fake one with a colored box, gradient panel, or icon standing in for a photo (that is one of the most recognizable "AI page builder" tells and is banned in this app everywhere else). Give it a neutral placeholder \`src\` (a simple light-gray SVG data URI rectangle, e.g. \`data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='600'%3E%3Crect width='800' height='600' fill='%23e5e0d8'/%3E%3C/svg%3E\`, sized to roughly match the slot), the exact attribute \`data-ai-image-slot="true"\` (always this literal attribute and value -- it's what lets the designer click it afterward to upload a real photo), a descriptive \`alt\` naming what the photo should actually show, and normal responsive styling (e.g. \`width:100%;height:auto;object-fit:cover;border-radius\` to match the section's own style).

If the request asks for a video, do NOT insert a real \`<video>\` or \`<iframe>\` element yourself -- the designer adds that afterward by clicking a placeholder. Two options, pick whichever fits the request:
- A bounded video (a demo clip, a testimonial, most requests): a \`<div>\` carrying the exact attribute \`data-ai-video-slot="true"\`, sized as a responsive 16:9 box (\`aspect-ratio:16/9;width:100%;\` plus styling matching the section), with one short line of copy inside naming what the video will show.
- A full-bleed background video (only when the request explicitly asks for a video AS the section's background): give the section's root element \`position:relative;overflow:hidden;\`, then as its first children add a \`<div data-ai-video-bg-slot="true">\` styled \`position:absolute;inset:0;z-index:0;background:#0c0c0f;\`, a scrim \`<div>\` styled \`position:absolute;inset:0;z-index:1;pointer-events:none;background:linear-gradient(180deg, rgba(0,0,0,0.55), rgba(0,0,0,0.4));\`, then wrap the section's existing content in its own \`<div>\` styled \`position:relative;z-index:2;\` so it sits above both layers. This only ever accepts a direct video file or a YouTube link added afterward, never Vimeo or other embeds.

Either way, say clearly in your one-sentence message that this is a placeholder and the designer clicks it in the canvas to add the real image or video URL (e.g. "Added a video placeholder -- click it in the preview to add the real video URL.").`;

async function handleChat(req, res) {
  let body;
  try {
    body = JSON.parse(await readBody(req, 1024 * 1024));
  } catch (e) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Invalid request body: ' + e.message }));
    return;
  }

  const mode = body.mode === 'generate' ? 'generate'
    : body.mode === 'research' ? 'research'
    : body.mode === 'strategy' ? 'strategy'
    : body.mode === 'strategySet' ? 'strategySet'
    : body.mode === 'strategySetItem' ? 'strategySetItem'
    : body.mode === 'aiFunnel' ? 'aiFunnel'
    : body.mode === 'aiFunnelRevise' ? 'aiFunnelRevise'
    : body.mode === 'designCommitment' ? 'designCommitment'
    : body.mode === 'funnelInterview' ? 'funnelInterview'
    : body.mode === 'pageSectionEdit' ? 'pageSectionEdit'
    : body.mode === 'pageSectionAdd' ? 'pageSectionAdd'
    : 'chat';
  const messages = Array.isArray(body.messages) ? body.messages : [];
  const sectionTypes = Array.isArray(body.sectionTypes) ? body.sectionTypes : [];
  const defaults = body.defaults && typeof body.defaults === 'object' ? body.defaults : {};
  const fontOptions = Array.isArray(body.fontOptions) ? body.fontOptions.filter((f) => typeof f === 'string') : [];
  const profile = body.profile && typeof body.profile === 'object' ? body.profile : {};
  const business = body.business && typeof body.business === 'object' ? body.business : null;
  const idea = typeof body.idea === 'string' ? body.idea : '';
  const goal = typeof body.goal === 'string' ? body.goal : '';
  const differentiator = typeof body.differentiator === 'string' ? body.differentiator : '';
  const strategy = body.strategy && typeof body.strategy === 'object' ? body.strategy : null;
  const commitment = body.commitment && typeof body.commitment === 'object' ? body.commitment : null;
  /* The funnel interview arrives as question/answer pairs. Both ends are capped: the pair count
     bounds the prompt an interview can grow into, and the per-field slice stops a pasted wall of
     text from crowding out the business context underneath it. */
  const transcript = Array.isArray(body.transcript)
    ? body.transcript
        .filter((t) => t && typeof t.question === 'string' && typeof t.answer === 'string')
        .slice(0, 12)
        .map((t) => ({ question: t.question.slice(0, 1000), answer: t.answer.slice(0, 2000) }))
    : [];
  const product = body.product && typeof body.product === 'object' ? body.product : null;
  const products = Array.isArray(body.products) ? body.products.filter((p) => p && typeof p === 'object') : [];
  const setCore = Array.isArray(body.setCore) ? body.setCore.filter((b) => b && typeof b === 'object') : [];
  const structure = Array.isArray(body.structure)
    ? body.structure.filter((t) => sectionTypes.some((st) => st.key === t))
    : [];
  const section = body.section && typeof body.section === 'object' ? body.section : null;
  const instruction = typeof body.instruction === 'string' ? body.instruction : '';
  // pageSectionAdd inputs. pageCss is the whole page's CSS: it IS the design system the new section
  // has to match, so it is sent verbatim rather than summarised into "the palette is blue". The
  // scope class is assigned by the client, never invented by the model -- sections share one
  // document, so a duplicated class would leak styles across the page.
  const description = typeof body.description === 'string' ? body.description : '';
  const scopeClass = /^[A-Za-z][A-Za-z0-9_-]{0,60}$/.test(body.scopeClass) ? body.scopeClass : '';
  const pageCss = typeof body.pageCss === 'string' ? body.pageCss.slice(0, 120000) : '';
  const neighbourBefore = body.neighbourBefore && typeof body.neighbourBefore === 'object' ? body.neighbourBefore : null;
  const neighbourAfter = body.neighbourAfter && typeof body.neighbourAfter === 'object' ? body.neighbourAfter : null;
  const draftSections = Array.isArray(body.sections)
    ? body.sections.filter((s) => s && typeof s.type === 'string' && typeof s.html === 'string' && typeof s.css === 'string')
    : [];
  const draftFonts = Array.isArray(body.fonts) ? body.fonts.filter((f) => typeof f === 'string') : [];

  if (MOCK_AI) {
    const result = mode === 'generate' ? mockGenerateResponse()
      : mode === 'research' ? mockResearchResponse()
      : mode === 'strategy' ? mockStrategyResponse()
      : mode === 'strategySet' ? mockStrategySetResponse(products)
      : mode === 'strategySetItem' ? mockStrategySetItemResponse(product)
      : mode === 'aiFunnel' ? mockAiFunnelResponse()
      : mode === 'aiFunnelRevise' ? mockAiFunnelReviseResponse(draftSections, draftFonts)
      : mode === 'designCommitment' ? mockDesignCommitmentResponse()
      : mode === 'funnelInterview' ? mockFunnelInterviewResponse(transcript, business)
      : mode === 'pageSectionEdit' ? mockPageSectionEditResponse(section, instruction)
      : mode === 'pageSectionAdd' ? mockPageSectionAddResponse(description, scopeClass)
      : mockChatResponse(messages);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(result));
    return;
  }

  if (!getApiKey()) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      error: 'No Anthropic API key is configured. Open the Account tab and add your key to start generating.'
    }));
    return;
  }

  try {
    if (mode === 'chat') {
      const systemPrompt = (Object.keys(profile).length
        ? `${CHAT_SYSTEM_PROMPT}\n\nCurrently known profile (JSON, may have empty fields still to fill): ${JSON.stringify(profile)}`
        : CHAT_SYSTEM_PROMPT) + businessContextBlock(business);
      const payload = {
        model: getModel(),
        max_tokens: 1024,
        system: systemPrompt,
        output_config: { format: { type: 'json_schema', schema: CHAT_SCHEMA } },
        messages
      };
      const { status, body: respBody } = await anthropicRequest(payload);
      if (status !== 200) {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const textBlock = (respBody.content || []).find((b) => b.type === 'text');
      const parsed = textBlock ? JSON.parse(textBlock.text) : { reply: '', profile: {} };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(parsed));
      return;
    }

    if (mode === 'research') {
      const researchSystemPrompt = `You are a market-research assistant embedded in a landing-page design tool called CodeCraft, inside a workflow stage called "Funnel Copywriter." You help a web designer research their client's market before writing funnel copy -- competitors, pricing norms, customer pain points and language, industry trends, credible proof points, positioning angles.

You have a real web_search tool -- use it whenever a claim would benefit from current, real information (competitor names, pricing figures, industry statistics, recent trends, what similar businesses' landing pages emphasize). Do not rely on your own training knowledge alone for anything time-sensitive or specific -- search for it.

Have a natural conversation: ask what the designer wants researched if it's not obvious, run searches, and report findings back in a few clear paragraphs or a short bulleted list, in plain conversational prose (never JSON), citing what you found. Keep findings focused on what will sharpen funnel copy later: what pains/desires to speak to, what proof points are credible, what competitors emphasize, what tone fits this market. Do not draft actual section copy yet -- that happens in a later step of this workflow.${businessContextBlock(business)}`;

      const payload = {
        model: getModel(),
        max_tokens: 2048,
        system: researchSystemPrompt,
        tools: [{ type: 'web_search_20260209', name: 'web_search', max_uses: 5 }],
        messages
      };
      const { status, body: respBody } = await anthropicRequest(payload);
      if (status !== 200) {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const content = respBody.content || [];
      const reply = content.filter((b) => b.type === 'text').map((b) => b.text).join('\n\n');
      const sources = [];
      content.forEach((b) => {
        if (b.type === 'web_search_tool_result' && Array.isArray(b.content)) {
          b.content.forEach((r) => {
            if (r && r.url) sources.push({ title: r.title || r.url, url: r.url });
          });
        }
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ reply, sources }));
      return;
    }

    if (mode === 'strategy') {
      const strategySystemPrompt = `You are a funnel-strategy advisor for a landing-page design tool called CodeCraft. A web designer has described a funnel idea for their client. Propose 2 to 3 distinct, named strategic directions this funnel could take -- do NOT commit to one, and do NOT design section structure yet (that happens in a later step).

Recognizable funnel archetypes (use as reasoning anchors, adapt/rename/blend freely when the idea doesn't fit cleanly):
- Lead Generation (goal: leads/contact) -- capture-focused, proof-heavy
- Service Business (goal: bookings/calls) -- trust + credentials + booking CTA
- Product Sales (goal: sales) -- product detail, pricing, guarantee, urgency
- Webinar/Event (goal: signups) -- agenda, speaker credibility, single signup CTA

For EACH candidate, produce a complete strategic brief with these sections:
- key: a url-safe slug (e.g. "fast-response-leadgen")
- title: a short punchy name (2-5 words, specific to this business/idea, NOT just the archetype name verbatim)
- audience: whoTheyAre, corePain, coreDesire (1-2 sentences each, specific to this business, never generic boilerplate)
- offer: description, price (a short price-framing string, e.g. "Under $100" or "Free estimate"), priceTag (a short category tag, e.g. "low-ticket" or "quote-first"), xFactor (the concrete differentiator), conversionGoal (the specific action the visitor takes)
- objections: primary (1-3 likely objections, short strings), proofAssets (1-4 proof asset ideas as {text} objects, e.g. {"text": "Customer testimonials"} -- do not include any other fields on these objects)
- traffic: source (likely traffic source for this business), trustLevel (exactly "Low", "Medium", or "High"), microWinEntryPoint (a small early win before the main ask, or a string explaining there isn't one if the funnel goes direct to the main ask)
- messaging: angleName (a short named angle, e.g. "Proof-Led Credibility Play"), angleDescription (1-2 sentences explaining why this angle fits this audience), primaryAngle (a short tag, e.g. "proof" or "urgency"), tone (a short tag, e.g. "conversational"), copyApproach (a short tag, e.g. "data-driven"), keyMessages (3-5 short punchy message lines), copyStructure (a copywriting framework abbreviation, e.g. "FAB", "PAS", or "AIDA")
- funnelType: type (e.g. "Sales Funnel", "Lead Gen Funnel", "Webinar Funnel"), reasoning (1-2 sentences on why this funnel type fits)

Order candidates best-first. Ground every field in the specifics of the described idea and business profile -- never generic boilerplate.

After proposing the candidates, pick the single one you'd genuinely recommend and set "recommendedKey" to its exact "key" value (must match one of the candidates you just proposed). Reason about trust gap (how skeptical this traffic likely is), objection load (how many real objections stand between them and the ask), and commitment level (how big an ask the conversionGoal is) -- not just archetype fit. Set "recommendedReason" to one specific sentence (not generic praise) explaining why THIS candidate is the strongest starting point for this specific business and idea.

${ideaLine(idea, 'described')}${goalBlock(goal)}${businessContextBlock(business)}${productContextBlock(product)}`;

      const payload = {
        model: getModel(),
        max_tokens: 8192,
        system: strategySystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildStrategySchema() } },
        messages: [{ role: 'user', content: 'Propose the strategy candidates now.' }]
      };
      const { status, body: respBody } = await anthropicRequest(payload);
      if (status !== 200) {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const textBlock = (respBody.content || []).find((b) => b.type === 'text');
      const parsed = textBlock ? JSON.parse(textBlock.text) : { candidates: [] };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(parsed));
      return;
    }

    if (mode === 'strategySet') {
      if (products.length < 2) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Select at least 2 products to generate a strategy set.' }));
        return;
      }
      const strategySetSystemPrompt = `You are a funnel-strategy advisor for a landing-page design tool called CodeCraft. A web designer is building a COORDINATED set of funnel strategy briefs for MULTIPLE products from the SAME business, sharing one funnel idea. Produce exactly one full brief per product below, all sharing the same brand core.

HOLD CONSTANT across every brief in this set (must not drift between products):
- audience.whoTheyAre, audience.corePain, audience.coreDesire
- messaging.tone
- messaging.primaryAngle

VARY per product (must be genuinely different, grounded in that product's own price/description):
- offer (description, price, priceTag, xFactor, conversionGoal)
- objections (primary, proofAssets)
- funnelType (type, reasoning)
- messaging.angleName, angleDescription, keyMessages, copyStructure, copyApproach

For EACH product, produce a complete strategic brief with these sections:
- key: a url-safe slug (e.g. "fast-response-leadgen")
- title: a short punchy name (2-5 words, specific to this business/product, NOT just the archetype name verbatim)
- audience: whoTheyAre, corePain, coreDesire (1-2 sentences each, specific to this business, never generic boilerplate)
- offer: description, price (a short price-framing string, e.g. "Under $100" or "Free estimate"), priceTag (a short category tag, e.g. "low-ticket" or "quote-first"), xFactor (the concrete differentiator), conversionGoal (the specific action the visitor takes)
- objections: primary (1-3 likely objections, short strings), proofAssets (1-4 proof asset ideas as {text} objects, e.g. {"text": "Customer testimonials"} -- do not include any other fields on these objects)
- traffic: source (likely traffic source for this business), trustLevel (exactly "Low", "Medium", or "High"), microWinEntryPoint (a small early win before the main ask, or a string explaining there isn't one if the funnel goes direct to the main ask)
- messaging: angleName (a short named angle, e.g. "Proof-Led Credibility Play"), angleDescription (1-2 sentences explaining why this angle fits this audience), primaryAngle (a short tag, e.g. "proof" or "urgency"), tone (a short tag, e.g. "conversational"), copyApproach (a short tag, e.g. "data-driven"), keyMessages (3-5 short punchy message lines), copyStructure (a copywriting framework abbreviation, e.g. "FAB", "PAS", or "AIDA")
- funnelType: type (e.g. "Sales Funnel", "Lead Gen Funnel", "Webinar Funnel"), reasoning (1-2 sentences on why this funnel type fits)

Order items in the same order as the products are listed below. Ground every field in the specifics of the idea, business profile, and that specific product -- never generic boilerplate.

${ideaLine(idea, 'shared')}${goalBlock(goal)}${businessContextBlock(business)}${productSetContextBlock(products)}`;

      const payload = {
        model: getModel(),
        max_tokens: Math.max(8192, products.length * 3000 + 6000),
        system: strategySetSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildStrategySetSchema() } },
        messages: [{ role: 'user', content: 'Propose one strategy brief per product now, sharing the same brand core.' }]
      };
      const { status, body: respBody } = await anthropicRequest(payload);
      if (status !== 200) {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const textBlock = (respBody.content || []).find((b) => b.type === 'text');
      const parsed = textBlock ? JSON.parse(textBlock.text) : { items: [] };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(parsed));
      return;
    }

    if (mode === 'strategySetItem') {
      const strategySetItemSystemPrompt = `You are a funnel-strategy advisor for a landing-page design tool called CodeCraft. The designer is regenerating ONE product's brief within an already-generated coordinated strategy set for the same business -- the other products' briefs already exist and must not be contradicted.

Produce ONE complete strategic brief for the product below, following this same field-by-field guidance:
- key: a url-safe slug (e.g. "fast-response-leadgen")
- title: a short punchy name (2-5 words, specific to this business/product, NOT just the archetype name verbatim)
- audience: whoTheyAre, corePain, coreDesire (1-2 sentences each, specific to this business, never generic boilerplate)
- offer: description, price (a short price-framing string, e.g. "Under $100" or "Free estimate"), priceTag (a short category tag, e.g. "low-ticket" or "quote-first"), xFactor (the concrete differentiator), conversionGoal (the specific action the visitor takes)
- objections: primary (1-3 likely objections, short strings), proofAssets (1-4 proof asset ideas as {text} objects, e.g. {"text": "Customer testimonials"} -- do not include any other fields on these objects)
- traffic: source (likely traffic source for this business), trustLevel (exactly "Low", "Medium", or "High"), microWinEntryPoint (a small early win before the main ask, or a string explaining there isn't one if the funnel goes direct to the main ask)
- messaging: angleName (a short named angle, e.g. "Proof-Led Credibility Play"), angleDescription (1-2 sentences explaining why this angle fits this audience), primaryAngle (a short tag, e.g. "proof" or "urgency"), tone (a short tag, e.g. "conversational"), copyApproach (a short tag, e.g. "data-driven"), keyMessages (3-5 short punchy message lines), copyStructure (a copywriting framework abbreviation, e.g. "FAB", "PAS", or "AIDA")
- funnelType: type (e.g. "Sales Funnel", "Lead Gen Funnel", "Webinar Funnel"), reasoning (1-2 sentences on why this funnel type fits)
${setCoreContext(setCore)}

${ideaLine(idea, 'shared')}${goalBlock(goal)}${businessContextBlock(business)}${productContextBlock(product)}`;

      const payload = {
        model: getModel(),
        max_tokens: 8192,
        system: strategySetItemSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildStrategySetItemSchema() } },
        messages: [{ role: 'user', content: 'Propose the regenerated brief for this product now.' }]
      };
      const { status, body: respBody } = await anthropicRequest(payload);
      if (status !== 200) {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const textBlock = (respBody.content || []).find((b) => b.type === 'text');
      const parsed = textBlock ? JSON.parse(textBlock.text) : { brief: null };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(parsed));
      return;
    }

    // generate/copy modes: variable per-section "state" shape can't be expressed as a
    // strict json_schema (every object needs additionalProperties:false), so these
    // calls rely on prompted JSON + the client's merge-over-real-defaults step.
    const typeList = sectionTypes.map((t) => t.key).join(', ');
    const structureInstruction = structure.length
      ? `Generate content for EXACTLY these sections, in EXACTLY this order (a structure already approved by the designer -- do not add, remove, reorder, or substitute any section): ${JSON.stringify(structure)}. Output exactly ${structure.length} objects in "sections", with "type" values in precisely this sequence.`
      : `Pick 4 to 9 section types from this list, in a sensible order for a real landing page (usually: navbar first, footer last): ${typeList}.`;
    const productsBlock = business && business.products && business.products.length
      ? '\n\nUse the saved business profile\'s "products" array verbatim (real names/prices/descriptions, no invented placeholder products) for any pricing or product-style section. Use its guarantee/credibility/contact fields verbatim for any guarantee or footer-style section.'
      : '';

    if (mode === 'aiFunnel') {
      // Gate only the creation of a NEW funnel. Revising, editing, exporting and everything else
      // stay open once the trial is spent -- work already paid for (in Anthropic credit) is never
      // held hostage.
      const lic = licenseState();
      if (!lic.licensed && lic.trialRemaining <= 0) {
        res.writeHead(402, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          error: 'Your free trial is used up -- all ' + TRIAL_FUNNEL_LIMIT + ' funnels have been generated. '
            + 'Add your license key in the Account tab to keep generating. Everything you have already '
            + 'made stays editable and exportable.',
          trialExhausted: true
        }));
        return;
      }
      const aiFunnelStructureInstruction = `First decide which sections belong in this funnel, THEN draft their real HTML and CSS in the same pass. Recognizable funnel archetypes (illustrative reasoning anchors, NOT the only valid outputs -- blend or deviate freely when the business doesn't fit cleanly):
- Lead Generation (goal: leads/contact) -- capture-focused, proof-heavy
- Service Business (goal: bookings/calls) -- trust + credentials + booking CTA
- Product Sales (goal: sales) -- product detail, pricing, guarantee, urgency
- Webinar/Event (goal: signups) -- agenda, speaker credibility, single signup CTA

Section "type" is a short free-form label you invent for your own structure (e.g. "hero", "proof-strip", "pricing-comparison", "cta-band") -- there is no fixed list to choose from, invent whatever best names each section's actual role. Convention: a navbar-equivalent section first if used, a footer-equivalent section last if used. Usually 5-9 sections total. Repeats of a similar role are allowed only when genuinely useful (e.g. two distinct proof sections for different clusters), never just to pad the count.`;

      const aiFunnelSystemPrompt = `You are the "AI Funnel" stage of a landing-page design tool called CodeCraft -- a single, fully autonomous pass that invents section structure AND a bespoke visual identity AND drafts copy AND authors the real HTML/CSS all at once, with no fixed template library, component catalog, or field menu to pick from. This is the faster, more autonomous sibling of CodeCraft's other pipeline (which ranks pre-built structure/brand libraries and fills in fixed component fields) -- here, you invent and build everything yourself, by hand, as real code. The designer will review and edit what you produce, so favor strong, concrete, on-brand output over hedging or placeholder text.

Respond with ONLY raw JSON (no markdown fences, no commentary) matching exactly this shape:
{"fonts": ["<font-family CSS value used anywhere on the page>", ...], "sections": [{"type": "<short free-form label>", "html": "<raw HTML for this section only>", "css": "<raw CSS for this section only>"}, ...]}

${aiFunnelStructureInstruction}

${aiFunnelMarkupInstructionText()}

${aiFunnelDoctrineText(fontOptions)}

Write actual persuasive marketing copy and real, production-ready markup -- not placeholder text and not a token gesture at styling. Only output the JSON object, nothing else.${businessContextBlock(business)}${productsBlock}${strategyContextBlock(strategy)}${differentiatorBlock(business, strategy, differentiator)}${commitmentContractText(commitment)}`;

      const aiFunnelPayload = {
        model: getModel(),
        max_tokens: 64000,
        system: aiFunnelSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildAiFunnelSchema() } },
        messages: messages.concat([{ role: 'user', content: 'Design and draft this funnel now as raw JSON only.' }])
      };
      const { status: aiFunnelStatus, body: aiFunnelRespBody } = await anthropicRequest(aiFunnelPayload);
      if (aiFunnelStatus !== 200) {
        res.writeHead(aiFunnelStatus, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (aiFunnelRespBody && aiFunnelRespBody.error && aiFunnelRespBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const aiFunnelTextBlock = (aiFunnelRespBody.content || []).find((b) => b.type === 'text');
      const aiFunnelParsed = aiFunnelTextBlock ? JSON.parse(aiFunnelTextBlock.text) : { fonts: [], sections: [] };
      // Only burn a trial slot when a usable funnel actually came back -- a failed or empty
      // generation the user cannot use must not cost them one of their three.
      if (Array.isArray(aiFunnelParsed.sections) && aiFunnelParsed.sections.length >= 3) {
        noteTrialFunnel();
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(aiFunnelParsed));
      return;
    }

    if (mode === 'aiFunnelRevise') {
      if (!draftSections.length) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'A drafted funnel (fonts + sections) is required to run a self-critique pass.' }));
        return;
      }

      /* Hand the revise pass the contract violations we can actually measure, rather than hoping
         a general instruction to "fix what looks generic" happens to catch them. */
      const rhythmProblems = auditRhythm(draftSections, commitment)
        .concat(auditTypeCollisions(draftSections))
        .concat(auditComponents(draftSections, commitment))
        .concat(auditBackground(draftSections, commitment))
        .concat(auditWidths(draftSections));
      if (rhythmProblems.length) {
        console.log('Design audit found ' + rhythmProblems.length + ' contract violation(s) in the draft.');
      }
      const rhythmAuditBlock = rhythmProblems.length
        ? '\n\nCONTRACT VIOLATIONS ALREADY FOUND IN THIS DRAFT. These were measured, not guessed, by '
          + 'comparing the draft against the design contract below. Every one of them MUST be fixed in '
          + 'your revision, and fixing them matters more than any stylistic improvement you would '
          + 'otherwise make. Change only backgrounds, tone markers and whatever spacing the change '
          + 'requires -- do not rewrite copy to accommodate them:\n'
          + rhythmProblems.map((p) => '  - ' + p).join('\n')
          + '\nKeep the data-tone attribute on every section root and make it agree with the background '
          + 'that section actually paints.'
        : '';

      const aiFunnelReviseSystemPrompt = `You are running a self-critique-and-revise pass on a funnel page you (or a colleague) already drafted inside CodeCraft's "AI Funnel" tool. You are NOT designing a new page -- you are looking at an already-complete draft with fresh eyes and fixing whatever specifically reads as generic, templated, or "AI made this," while preserving everything that is already working. Most of a decent first draft is fine; your job is surgical revision, not a rewrite. Never change the section count, the section order, or the business grounding unless a section is so broken it must be rebuilt -- and even then, keep its role in the page the same.

Run this six-axis self-critique FIRST, silently, before deciding what to change (score each 1-5):
- Philosophy: is there a clear point of view, a reason this page looks the way it does -- or is it just a layout?
- Hierarchy: can a reader tell what's primary, secondary, tertiary within two seconds?
- Execution: are the details right (contrast, spacing consistency, focus states, hover states) or is there sloppiness even where the bones are right?
- Specificity: does this look like THIS business, or a generic page that could be anyone in the industry?
- Restraint: has everything not earning its place been removed, or is there decoration/redundancy left in?
- Variety: do multiple sections share the same structural shape when they shouldn't (three centered-stack sections in a row, the same badge shape everywhere, the same hover effect everywhere)?

Any axis scoring below 4 needs a real fix in your revision, not just a lower number in the critique object. Report your six scores and a short note on the weakest axis in the "critique" object of your response, and a plain-English 2-4 sentence summary of what you actually changed (or "no changes needed" if the draft already scored well everywhere) in "changesSummary".

${aiFunnelMarkupInstructionText()}

The complete current draft, as JSON (each section's html/css already follows the self-scoping rule above -- keep every section's existing root class name unchanged when you keep that section, so nothing breaks; only introduce a new class name for a section you rebuild from scratch):
${JSON.stringify({ fonts: draftFonts, sections: draftSections })}${rhythmAuditBlock}

Judge the draft above against this same doctrine used to generate it -- the specific, checkable rules below are exactly the kind of thing a fresh critique pass should be catching (palette clichés, structural AI-fingerprints, motion/contrast discipline, etc.):

${aiFunnelDoctrineText(fontOptions)}

Respond with ONLY raw JSON (no markdown fences, no commentary) matching exactly this shape:
{"critique": {"philosophy": <1-5>, "hierarchy": <1-5>, "execution": <1-5>, "specificity": <1-5>, "restraint": <1-5>, "variety": <1-5>, "notes": "<short note on the weakest axis and why>"}, "changesSummary": "<2-4 sentences, plain English, written to the designer>", "fonts": ["<every font-family value actually used after your revision>"], "sections": [{"type": "<unchanged unless you rebuilt this section>", "html": "<this section's complete html after your revision>", "css": "<this section's complete css after your revision>"}]}
Output exactly one section object per section in the current draft above, in the same order, even for sections you left completely unchanged (echo their html/css back verbatim in that case).${businessContextBlock(business)}${productsBlock}${strategyContextBlock(strategy)}${differentiatorBlock(business, strategy, differentiator)}${commitmentContractText(commitment)}`;

      const aiFunnelRevisePayload = {
        model: getModel(),
        max_tokens: 64000,
        system: aiFunnelReviseSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildAiFunnelReviseSchema() } },
        messages: [{ role: 'user', content: 'Run the self-critique now, then output the revised funnel as raw JSON only.' }]
      };
      const { status: aiFunnelReviseStatus, body: aiFunnelReviseRespBody } = await anthropicRequest(aiFunnelRevisePayload);
      if (aiFunnelReviseStatus !== 200) {
        res.writeHead(aiFunnelReviseStatus, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (aiFunnelReviseRespBody && aiFunnelReviseRespBody.error && aiFunnelReviseRespBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const aiFunnelReviseTextBlock = (aiFunnelReviseRespBody.content || []).find((b) => b.type === 'text');
      const aiFunnelReviseParsed = aiFunnelReviseTextBlock
        ? JSON.parse(aiFunnelReviseTextBlock.text)
        : { critique: null, changesSummary: 'No response.', fonts: draftFonts, sections: draftSections };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(aiFunnelReviseParsed));
      return;
    }

    if (mode === 'designCommitment') {
      if (!business) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Pick a business first.' }));
        return;
      }

      /* Gated like the funnel itself and the interview: this is part of creating a NEW page, and
         leaving it open would be a free AI call for anyone whose trial is spent. It deliberately
         does NOT call noteTrialFunnel() -- one Generate click is one trial funnel, not two. */
      const commitLic = licenseState();
      if (!commitLic.licensed && commitLic.trialRemaining <= 0) {
        res.writeHead(402, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          error: 'Your free trial is used up -- all ' + TRIAL_FUNNEL_LIMIT + ' funnels have been generated. '
            + 'Add your license key in the Account tab to keep generating. Everything you have already '
            + 'made stays editable and exportable.',
          trialExhausted: true
        }));
        return;
      }
      const commitmentSystemPrompt = `You are deciding how one landing page will LOOK, before anybody writes its structure or its copy. This is the only decision you are making. Do not describe sections, do not write copy, do not plan the page.

The reason this is a separate step is that a call which also invents structure and writes words will quietly average every visual decision into something safe and forgettable. You cannot do that here, because choosing is the only thing you have been asked to do. Commit.

Decide four things.

1. COLOURS BY JOB. Not a palette, a set of assignments. Every one of these gets a specific hex value:
   canvas: the dominant page background.
   canvasAlt: the contrasting background for sections that break the rhythm. This must be FAR from canvas in brightness -- one clearly light and one clearly dark. Two shades of the same tint is the single most common way a page ends up looking flat, and it will be rejected.
   surface: what a card, panel or quote block sits on when it is on canvas. It must differ from canvas enough to be seen without a border.
   surfaceAlt: the same, for cards sitting on canvasAlt.
   ink: body text on canvas. inkAlt: body text on canvasAlt. Both must clear WCAG AA, 4.5:1.
   accent: the single saturated colour, used for actions and emphasis. accentInk: text placed on the accent, also 4.5:1.
   Draw the identity from this business's real world. Avoid the tired defaults: ${CLICHE_PALETTE_TEXT}
   Two traps are specific to bright and light palettes, and they are where this stage actually fails rather than merely disappoints. Both are arithmetic, so decide them deliberately instead of discovering them afterwards.
   First, the near-white canvas. If you choose a canvas above roughly #f8f8f8, a white card sitting on it is invisible and the whole page flattens. You have two honest ways out and you must pick one before writing the values: drop the canvas far enough that a white or near-white surface genuinely reads against it -- a warm cream, a tinted stone, a pale wash of the accent's own hue -- or keep the very light canvas and make the surface the DARKER of the pair, a tinted panel rather than white. What does not work is a near-white canvas with a white surface and a hairline border holding them apart.
   Second, the saturated mid-tone accent. Bright orange, yellow, lime, mid-red, sky blue and most pinks cannot carry white text at the 4.5:1 needed to be readable -- this is the single most common way a cheerful palette fails. When your accent is one of those, set accentInk to a near-black drawn from the page's own ink rather than to white. Dark text on a bright accent is not a compromise; it is what a well-made bright palette actually looks like. Reserve white accentInk for genuinely deep accents: navy, forest, burgundy, a true deep red.
   None of this is an argument for going dark. A children's dentist, a bakery or a nursery should still come out bright -- these two rules exist so that a bright page is BUILT correctly rather than abandoned for a safer dark one when the numbers do not work.

   One more default worth naming, because it is the one that gets reached for without being chosen: a light warm off-white canvas. It is right often enough that it has stopped being a decision. Use it only if this business's own world genuinely is papery and warm. A garage, a foundry, a record shop, a late-night bar, a tattoo studio, a barbell gym in a railway arch: none of those live on off-white, and a page that opens on it has already softened them into something they are not. The dominant background is the single largest visual decision here. Make it deliberately. If the honest answer is that this business really is warm and papery, then off-white is correct and you should choose it with confidence -- what is not acceptable is arriving there without having considered anything else.

2. A SECTION RHYTHM: ten entries, applied in order to whatever sections get invented later. Each entry sets a background tone (canvas, canvasAlt, or accent), a container width (full_bleed, wide, standard, narrow) and a spacing density (airy, normal, tight). Rules that will be checked: never three in a row on the same tone; at least a third of entries must leave canvas; at most ONE entry may use accent as a background, because an accent used everywhere stops being an accent. Vary the widths -- a page where every section is the same width reads as a list.

3. A TYPE SCALE: displayPx between 56 and 140, bodyPx between 15 and 19, eyebrowPx between 10 and 13. Display must be at least four times body. Pick a real size, not the middle of the range.

4. ONE SIGNATURE MOVE from exactly this list, and a reason it suits THIS business:
${SIGNATURE_MOVES.map((m) => '   ' + m + ': ' + SIGNATURE_MOVE_TEXT[m] + '\n      ' + (SIGNATURE_MOVE_FIT[m] || '')).join('\n')}
   One gesture repeated with conviction is what makes a page memorable. A generic reason means you have not really chosen, so argue it from something true about this specific business.
   Then decide what is BEHIND the content. Right now every background this generator produces is a flat colour fill -- not as a choice, but because nothing ever asked. The rhythm above already sets which COLOUR each section sits on; this decides what, if anything, is drawn on it.
${BACKGROUND_TREATMENTS.map((b) => '   ' + b + ': ' + BACKGROUND_TEXT[b]).join('\n')}
   Two rules make the difference between a treatment and wallpaper. It must be drawn from THIS business's real world -- an engineering firm earns a drawing-board grid, a bakery earns a flour-dusted wash, a dentist for children earns something from its own room -- and it must appear on only two or three sections, never all of them. Say plainly in "drawnFrom" what in this business it comes from, and in "where" which sections carry it.
   If you choose a gradient, it interpolates between two colours already committed above and stays close: canvas into canvasAlt, or a colour into a deepened version of itself. A gradient between two unrelated hues, and the purple-into-blue wash in particular, is the single most recognisable mark of a page nobody designed.
   Choosing "flat" is allowed and is sometimes right, but it is also what this generator does when it is not thinking, so choose it only if the page is genuinely stronger bare.

   Then commit to a SHAPE LANGUAGE and a COMPONENT SET, which are decided here for the same reason the colours are: left to be settled while writing the page, they collapse to the plainest option available every time.
   Corner language, pick one: ${RADIUS_LANGUAGES.map((r) => r + ' (' + RADIUS_TEXT[r] + ')').join(' | ')}
   Shadow language, pick one: ${SHADOW_LANGUAGES.map((r) => r + ' (' + SHADOW_TEXT[r] + ')').join(' | ')}
   Icon style, pick one: ${ICON_STYLES.map((r) => r + ' (' + ICON_STYLE_TEXT[r] + ')').join(' | ')}
   Fill language, pick one -- how buttons, cards and key panels are filled. Every page this generator has produced fills them with flat colour, not because gradients are disallowed but because nobody ever chose: ${FILL_LANGUAGES.map((r) => r + ' (' + FILL_TEXT[r] + ')').join(' | ')}
   "solid" is the one to check hardest here, for the same reason off-white was: it is never wrong enough to notice, so it gets taken by default. Before settling on it, say what a gradient or an outline would have done to this page that solid does not. If the answer is that solid is genuinely truer to the business -- a foundry, a solicitor, a letterpress studio -- keep it and keep it confidently. But a consumer-facing business selling something optional and pleasurable, or a digital product whose competitors all use depth, is usually poorer for a flat button than a considered one. The choice here is not "is a gradient tasteful" but "what does this business's own call to action want to look like when someone is deciding whether to press it".
   Be honest about the last two. A page with no shadows and no icons is the safest thing you can produce and it is what gets produced when nobody decides, so choose "none" and "typographic" only when this specific business genuinely reads better bare -- a stonemason, a law firm, a letterpress studio -- and not as a way of avoiding the work. Softness, depth and icons are not slop; using them identically on every business is. Match them to the trade's own visual culture: a children's dentist and a scaffolding firm should not arrive at the same corners.

   Then choose AT LEAST FOUR DIFFERENT components from this catalogue and say exactly where each one goes in this page. These are the working parts of a page that sells something, as opposed to a page that is merely well set: a visitor scanning for whether this is for them reads ticks, badges, figures and faces long before they read prose.
${COMPONENT_KINDS.map((k) => '   ' + k + ': ' + COMPONENT_TEXT[k]).join('\n')}
   Choose them from what this page has to prove, not from what is easiest to draw. A page whose real obstacle is disbelief needs faces and figures; a page whose obstacle is confusion needs ticks, steps and an accordion; a page whose obstacle is price needs a pricing box and a callout. Name a real location for each, such as "in the objections section, replacing the flat question grid".

   Two of these are easy to justify for almost ANY business, and for that reason alone they get chosen far more often than they fit: oversized_numerals, because every business has some number lying about, and mono_eyebrow, because every heading can take a small label above it. That does not make either wrong -- when a business genuinely turns on a number, or genuinely is technical and spec-driven, they are the correct answer and you should choose them without hesitation. It does mean they are the two you must check hardest. For those two specifically, before settling, say plainly what would be lost if you used the next-best move instead. If nothing much would be lost, you chose out of caution rather than fit, and the next-best move is the real answer.
   You must also name TWO moves from the list that you considered and turned down, with a real reason for each. Not filler: a reason that shows you understood what that move would have done to this particular page. Choosing without rejecting anything is how every page ends up looking the same.

Respond with ONLY raw JSON matching this shape, no markdown fences and no commentary:
{"colorRoles":{"canvas":"#rrggbb","canvasAlt":"#rrggbb","surface":"#rrggbb","surfaceAlt":"#rrggbb","ink":"#rrggbb","inkAlt":"#rrggbb","accent":"#rrggbb","accentInk":"#rrggbb"},"signatureMove":"one_of_the_list","signatureRationale":"why this move suits this business","background":{"treatment":"one_of_the_list","drawnFrom":"what in this business it comes from","where":"which sections carry it"},"shapeLanguage":{"radius":"one_of_the_list","shadow":"one_of_the_list","iconStyle":"one_of_the_list","fill":"one_of_the_list"},"components":[{"kind":"one_of_the_catalogue","where":"exactly where in this page it goes"}],"rejectedMoves":[{"move":"one_of_the_list","why":"what it would have done to this page and why that is wrong here"},{"move":"one_of_the_list","why":"..."}],"typeScale":{"displayPx":0,"bodyPx":0,"eyebrowPx":0},"rhythm":[{"tone":"canvas","width":"wide","density":"airy"}]}${businessContextBlock(business)}${strategyContextBlock(strategy)}${differentiatorBlock(business, strategy, differentiator)}`;

      let attemptNote = '';
      let parsed = null;
      let problems = [];
      // One retry, and the retry is TOLD what failed. Asking again without saying why mostly
      // produces the same answer.
      for (let attempt = 0; attempt < 2; attempt++) {
        const payload = {
          // Raised from 2048 when rejectedMoves was added: two rejections with real reasons pushed
          // the output past the limit and the JSON came back truncated, which surfaced as the
          // useless message "the response was not valid JSON".
          model: getModel(),
          max_tokens: 4096,
          system: commitmentSystemPrompt,
          output_config: { format: { type: 'json_schema', schema: buildDesignCommitmentSchema() } },
          messages: [{ role: 'user', content: 'Commit to the look now. Raw JSON only.' + attemptNote }]
        };
        const { status, body: respBody } = await anthropicRequest(payload);
        if (status !== 200) {
          res.writeHead(status, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: (respBody && respBody.error && respBody.error.message) || 'Anthropic API error' }));
          return;
        }
        const textBlock = (respBody.content || []).find((b) => b.type === 'text');
        try { parsed = textBlock ? JSON.parse(textBlock.text) : null; } catch (e) { parsed = null; }
        problems = parsed ? validateCommitment(parsed) : ['The response was not valid JSON.'];
        if (!problems.length) break;
        attemptNote = '\n\nYour previous answer was rejected for these reasons. Fix every one of them:\n- '
          + problems.join('\n- ');
      }

      if (problems.length) {
        // Better to build the page without a contract than to build it against a broken one.
        res.writeHead(422, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Could not settle on a design that passes the contrast and rhythm checks.', problems }));
        return;
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(parsed));
      return;
    }

    if (mode === 'funnelInterview') {
      // The interview only exists to feed a generation, so it is gated exactly like aiFunnel is.
      // Left open, a designer whose trial is spent could run interview turns forever, paying
      // Anthropic each time for a brief that no longer has anything to generate.
      const interviewLic = licenseState();
      if (!interviewLic.licensed && interviewLic.trialRemaining <= 0) {
        res.writeHead(402, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          error: 'Your free trial is used up -- all ' + TRIAL_FUNNEL_LIMIT + ' funnels have been generated. '
            + 'Add your license key in the Account tab to start a new funnel brief. Everything you have '
            + 'already made stays editable and exportable.',
          trialExhausted: true
        }));
        return;
      }
      if (!business) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Pick a business first -- the interview opens on what is already on file for them.' }));
        return;
      }
      if (!strategy) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Pick a strategy first -- the interview reads it to work out what it still needs to ask.' }));
        return;
      }

      const funnelInterviewSystemPrompt = `You are the funnel strategist inside CodeCraft, a landing-page tool used by designers building funnels for real client businesses. You are interviewing the designer to draw out the few concrete things that will make this client's page specific instead of generic.

You are an expert at direct-response funnel building. You know a page converts on specifics: the real offer and what it costs, the actual customer and the moment they start looking, the objection that stops them, the proof that answers it, and the single action the page asks for. Vague industry filler is exactly what you are here to prevent.

HOW TO RUN THE INTERVIEW
- Ask exactly ONE question per turn. Never stack two questions together, and never number them.
- Your FIRST question must be built from the business and strategy details below. Show you have read them: name the business and what you already know about it, then ask for the one thing those details do not tell you. Never open with a generic "tell me about your business", and never ask for anything already answered below.
- Keep every question short and in plain English, the way you would say it out loud to someone across a desk. No preamble, no jargon, no lists.
- Follow what the designer actually says. When an answer is vague ("we do good work"), press once for the concrete version ("what do they do that the shop down the road does not?").
- Cover what a page genuinely needs: the real offer and its price framing, the specific customer and when they start looking, the objection that stops the sale, the proof that answers it, and the action the page should ask for. Skip anything the details below already answer.
- Stop when you have enough to make the page specific to this business. That is usually 3 to 5 questions, and never more than 6. When you stop, set "done" to true and make "question" a short closing line telling the designer they are ready to generate.
- If the details below ALREADY answer everything a specific page needs -- a filled-in profile plus a strategy that names the offer, the audience, the objections and the conversion goal -- do not manufacture a question just to look thorough. Set "done" to true on the opening turn and make "question" a short line naming what you already have and saying they can generate now. This is uncommon, so only do it when nothing material is actually missing.

THE BRIEF
Rebuild "brief" from scratch on every turn, including the very first one. The designer can hit Generate at any point, so the brief must always stand on its own and never read as a fragment waiting to be finished.
Write it as direct notes to the page generator about THIS business: the real offer, the customer, the objection, the proof, the action. Third person, plain sentences, no headings and no bullet characters, a short paragraph or a few plain lines.
Use only what the designer has told you or what appears in the details below. Never invent facts, names, quotes, statistics, review counts or testimonials. If the designer has not said anything useful yet, base the brief on the business details below and keep it short.

Never use an em dash or an en dash anywhere in what you write. Use a period, a comma, or a regular hyphen instead.

Respond with ONLY raw JSON (no markdown fences, no commentary) matching exactly this shape:
{"question": "<your single next question, or a short closing line when you are done>", "done": <true or false>, "brief": "<the running brief, always complete and usable>"}${businessContextBlock(business)}${strategyContextBlock(strategy)}${interviewTranscriptBlock(transcript)}`;

      const funnelInterviewPayload = {
        model: getModel(),
        max_tokens: 2048,
        system: funnelInterviewSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildFunnelInterviewSchema() } },
        messages: [{
          role: 'user',
          content: transcript.length
            ? 'Ask your next question now, or close the interview if you have enough. Raw JSON only.'
            : 'Open the interview now. Ask your first question, or close it immediately if the details already cover everything. Raw JSON only.'
        }]
      };
      const { status: funnelInterviewStatus, body: funnelInterviewRespBody } = await anthropicRequest(funnelInterviewPayload);
      if (funnelInterviewStatus !== 200) {
        res.writeHead(funnelInterviewStatus, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (funnelInterviewRespBody && funnelInterviewRespBody.error && funnelInterviewRespBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const funnelInterviewTextBlock = (funnelInterviewRespBody.content || []).find((b) => b.type === 'text');
      const funnelInterviewParsed = funnelInterviewTextBlock
        ? JSON.parse(funnelInterviewTextBlock.text)
        : { question: '', done: true, brief: '' };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(funnelInterviewParsed));
      return;
    }

    if (mode === 'pageSectionEdit') {
      if (!section || typeof section.html !== 'string' || typeof section.css !== 'string') {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'A section with html/css is required.' }));
        return;
      }
      if (!instruction.trim()) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'An instruction is required.' }));
        return;
      }

      const pageSectionEditSystemPrompt = `You are revising ONE existing section of an already-built landing page inside a tool called CodeCraft, based on a designer's specific instruction. You are not designing a new page -- only apply the requested change to this one section, preserving everything else about its structure, styling, and content unless the instruction clearly implies changing it too.

This section's root element already has its own unique CSS class that scopes every one of its selectors (the page concatenates many sections into one shared document, so this class is the only thing preventing this section's styles from leaking into others). Keep that exact class name unchanged in both the html and the css you return -- do not rename it, and do not introduce a bare "html", "body", "*", or ":root" selector. If you add a @keyframes rule, prefix its name with that same class name.

Current section type: "${section.type || 'section'}"
Current section html:
${section.html}

Current section css:
${section.css}

Designer's instruction: "${instruction}"

Apply the instruction precisely. Writing style still applies: clarity over cleverness, active voice, no hedging words, no exclamation points, and never use an em dash (—) or a punctuation en dash (–) anywhere in any copy you write or keep -- use a period, comma, or regular hyphen instead. Never fabricate specific proof (customer names, quotes, stats, review counts) that wasn't already present in the section.

${MEDIA_SLOT_RULES}

Respond with ONLY raw JSON (no markdown fences, no commentary) matching exactly this shape:
{"html": "<the section's complete updated html>", "css": "<the section's complete updated css>", "message": "<one short sentence, written directly to the designer in first person, confirming what you changed>"}${businessContextBlock(business)}`;

      const pageSectionEditPayload = {
        model: getModel(),
        max_tokens: 8192,
        system: pageSectionEditSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildPageSectionEditSchema() } },
        messages: [{ role: 'user', content: 'Apply the requested change now and respond with raw JSON only.' }]
      };
      const { status: pageSectionEditStatus, body: pageSectionEditRespBody } = await anthropicRequest(pageSectionEditPayload);
      if (pageSectionEditStatus !== 200) {
        res.writeHead(pageSectionEditStatus, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (pageSectionEditRespBody && pageSectionEditRespBody.error && pageSectionEditRespBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const pageSectionEditTextBlock = (pageSectionEditRespBody.content || []).find((b) => b.type === 'text');
      const pageSectionEditParsed = pageSectionEditTextBlock ? JSON.parse(pageSectionEditTextBlock.text) : { html: section.html, css: section.css, message: 'No change made.' };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(pageSectionEditParsed));
      return;
    }

    if (mode === 'pageSectionAdd') {
      if (!description.trim()) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'A description of the section is required.' }));
        return;
      }
      if (!scopeClass) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'A scope class is required.' }));
        return;
      }

      const neighbourBlock = (label, n) => (n && typeof n.html === 'string'
        ? `\n\nThe section immediately ${label} this one (type "${n.type || 'section'}"), for structural context only -- do NOT copy its content:\n${String(n.html).slice(0, 6000)}`
        : `\n\nThere is no section ${label} this one: it goes at the very ${label === 'before' ? 'top' : 'bottom'} of the page.`);

      const pageSectionAddSystemPrompt = `You are writing ONE NEW section to be inserted into an already-built landing page inside a tool called CodeCraft. A designer has described what is missing. Write that section so it looks like it was always part of this page.

The single most important requirement is that it does not look bolted on. The page's existing CSS is below -- that IS the design system. Read the palette, type scale, spacing rhythm, border radii, and section padding out of it and reuse them. Do not introduce a new accent colour, a new font stack, or a different spacing scale. If every existing section pads 64px vertically, so does this one.

Scope every selector you write under the exact class "${scopeClass}" and put that class on the section's root element. Do not rename it, do not invent your own, and do not emit a bare "html", "body", "*", or ":root" selector -- all sections are concatenated into one document, so an unscoped rule silently restyles the whole page. If you add a @keyframes rule, prefix its name with "${scopeClass}" too. Every helper class you invent should start with "${scopeClass}-".

The designer asked for: "${description}"

Write real copy for this specific business, not lorem ipsum and not placeholder headings. Clarity over cleverness, active voice, no hedging words, no exclamation points, and never use an em dash or a punctuation en dash anywhere in any copy you write -- use a period, comma, or regular hyphen instead.

Never fabricate proof. Do not invent customer names, quotes, review counts, star ratings, statistics, awards, or media mentions. If the designer asked for testimonials or reviews, build the layout with clearly marked placeholder quotes (for example "Quote goes here" with "Customer name, role" beneath) so the designer replaces them with real ones -- an invented testimonial under a real client's name is their legal problem and their reputation.

${MEDIA_SLOT_RULES}

The page's existing CSS (the design system to match):
${pageCss || '(none supplied)'}${neighbourBlock('before', neighbourBefore)}${neighbourBlock('after', neighbourAfter)}

Respond with ONLY raw JSON (no markdown fences, no commentary) matching exactly this shape:
{"type": "<a short lowercase-hyphenated name for this kind of section, e.g. process-steps or photo-gallery>", "html": "<the section's complete html>", "css": "<the section's complete css>", "message": "<one short sentence, written directly to the designer in first person, saying what you added>"}${businessContextBlock(business)}`;

      const pageSectionAddPayload = {
        model: getModel(),
        max_tokens: 8192,
        system: pageSectionAddSystemPrompt,
        output_config: { format: { type: 'json_schema', schema: buildPageSectionAddSchema() } },
        messages: [{ role: 'user', content: 'Write the new section now and respond with raw JSON only.' }]
      };
      const { status: pageSectionAddStatus, body: pageSectionAddRespBody } = await anthropicRequest(pageSectionAddPayload);
      if (pageSectionAddStatus !== 200) {
        res.writeHead(pageSectionAddStatus, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: (pageSectionAddRespBody && pageSectionAddRespBody.error && pageSectionAddRespBody.error.message) || 'Anthropic API error' }));
        return;
      }
      const pageSectionAddTextBlock = (pageSectionAddRespBody.content || []).find((b) => b.type === 'text');
      if (!pageSectionAddTextBlock) {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Anthropic returned no section to add.' }));
        return;
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(JSON.parse(pageSectionAddTextBlock.text)));
      return;
    }

    const systemPrompt = `You are a funnel-generation engine for a landing-page design tool called CodeCraft. Given a conversation with a web designer about their client's business, produce ONE complete landing page funnel.

Respond with ONLY raw JSON (no markdown fences, no commentary) matching exactly this shape:
{"sections": [{"type": "<section type key>", "state": { ...fields... }}, ...]}

${structureInstruction}

For each section's "state", populate REAL field names and REAL content for the business discussed in the conversation -- do not invent field names. Here is the exact default state shape (with real field names) for every available section type, as JSON -- match these field names exactly, only include fields that exist on that type:
${JSON.stringify(defaults)}

Write actual marketing copy tailored to the business discussed in the conversation, not placeholder text. Only output the JSON object, nothing else.${businessContextBlock(business)}${productsBlock}`;

    await runSectionDraft(systemPrompt, 'Generate the funnel now as raw JSON only.', messages, res);
  } catch (e) {
    res.writeHead(502, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Failed to reach or parse response from Anthropic API: ' + e.message }));
  }
}

/* ---------- Image Storage: per-business uploaded images, real files on disk ---------- */
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const IMAGE_MIME_EXT = {
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/gif': '.gif',
  'image/webp': '.webp'
};
const MAX_IMAGE_BYTES = 8 * 1024 * 1024; // 8MB decoded

function isSafeBusinessId(id) {
  return typeof id === 'string' && /^[A-Za-z0-9_-]+$/.test(id);
}

function businessUploadsDir(businessId) {
  return path.join(UPLOADS_DIR, businessId);
}

function readManifest(businessId) {
  const manifestPath = path.join(businessUploadsDir(businessId), 'manifest.json');
  try {
    return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (e) {
    return [];
  }
}

function writeManifest(businessId, list) {
  const dir = businessUploadsDir(businessId);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'manifest.json'), JSON.stringify(list, null, 2));
}

function imageRecordToClient(businessId, rec) {
  return {
    id: rec.id,
    filename: rec.filename,
    url: `/uploads/${businessId}/${rec.id}${rec.ext}`,
    uploadedAt: rec.uploadedAt,
    sizeBytes: rec.sizeBytes
  };
}

async function handleImagesList(req, res) {
  let raw;
  try {
    raw = await readBody(req, 1024 * 1024);
  } catch (e) {
    endWithBodyError(req, res, e);
    return;
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }
  const businessId = body.businessId;
  if (!isSafeBusinessId(businessId)) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Invalid businessId' }));
    return;
  }
  const images = readManifest(businessId).map((rec) => imageRecordToClient(businessId, rec));
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ images }));
}

async function handleImagesUpload(req, res) {
  let raw;
  try {
    raw = await readBody(req, 12 * 1024 * 1024);
  } catch (e) {
    endWithBodyError(req, res, e, 'File too large (max 8MB).');
    return;
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }
  const businessId = body.businessId;
  const filename = typeof body.filename === 'string' ? body.filename : 'upload';
  const mimeType = typeof body.mimeType === 'string' ? body.mimeType : '';
  const dataBase64 = typeof body.dataBase64 === 'string' ? body.dataBase64 : '';
  if (!isSafeBusinessId(businessId)) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Invalid businessId' }));
    return;
  }
  const ext = IMAGE_MIME_EXT[mimeType];
  if (!ext) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Unsupported file type -- use PNG, JPEG, GIF, or WebP.' }));
    return;
  }
  let buffer;
  try {
    buffer = Buffer.from(dataBase64, 'base64');
  } catch (e) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Could not decode file data.' }));
    return;
  }
  if (!buffer.length || buffer.length > MAX_IMAGE_BYTES) {
    res.writeHead(413, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'File too large (max 8MB).' }));
    return;
  }
  const id = 'img-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  const dir = businessUploadsDir(businessId);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, id + ext), buffer);
  const rec = { id, filename, ext, mimeType, uploadedAt: Date.now(), sizeBytes: buffer.length };
  const manifest = readManifest(businessId);
  manifest.push(rec);
  writeManifest(businessId, manifest);
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ image: imageRecordToClient(businessId, rec) }));
}

async function handleImagesDelete(req, res) {
  let raw;
  try {
    raw = await readBody(req, 1024 * 1024);
  } catch (e) {
    endWithBodyError(req, res, e);
    return;
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }
  const businessId = body.businessId;
  const imageId = body.imageId;
  if (!isSafeBusinessId(businessId) || typeof imageId !== 'string') {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Invalid request' }));
    return;
  }
  const manifest = readManifest(businessId);
  const idx = manifest.findIndex((rec) => rec.id === imageId);
  if (idx !== -1) {
    const rec = manifest[idx];
    try { fs.unlinkSync(path.join(businessUploadsDir(businessId), rec.id + rec.ext)); } catch (e) { /* already gone */ }
    manifest.splice(idx, 1);
    writeManifest(businessId, manifest);
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: true }));
}

async function handleUsageGet(req, res) {
  const t = usageTotals;
  const byModel = Object.keys(t.byModel || {}).map((id) => {
    const m = t.byModel[id];
    return {
      model: id,
      calls: m.calls,
      inputTokens: m.inputTokens,
      outputTokens: m.outputTokens,
      cost: costFor(id, m.inputTokens, m.outputTokens)
    };
  });
  const total = byModel.reduce((sum, m) => sum + (m.cost || 0), 0);
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    since: t.since || null,
    calls: t.calls || 0,
    inputTokens: t.inputTokens || 0,
    outputTokens: t.outputTokens || 0,
    byModel,
    estimatedCost: total,
    // Stated plainly so nobody mistakes this for an invoice.
    note: 'Estimated from list prices and the token counts Anthropic returned. Your real bill is in the Anthropic Console.'
  }));
}

/* Everything a user builds -- businesses, strategies, funnels, saved pages -- lives only in the
   browser's localStorage. That is one cleared site-data away from gone, and the in-app Export
   button depends on a browser download that some environments block outright. This writes a
   timestamped copy server-side instead.

   Deliberately narrow: the caller never supplies a path or filename, the body must parse as JSON,
   and it lands under data/backups/, which sits outside serveStatic's allowlist and so is not
   reachable over HTTP. */
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const MAX_BACKUP_BYTES = 4 * 1024 * 1024;
// Backups fire automatically after every generation, so without a cap they would grow without
// bound (~95KB each). Keeping the most recent 20 covers any realistic "undo the last few hours"
// without quietly eating disk.
const MAX_BACKUPS = 20;

function listBackups() {
  try {
    return fs.readdirSync(BACKUP_DIR)
      .filter((f) => /^project-.*\.json$/.test(f))
      .map((f) => {
        const st = fs.statSync(path.join(BACKUP_DIR, f));
        return { file: f, bytes: st.size, at: st.mtimeMs };
      })
      .sort((a, b) => b.at - a.at);
  } catch (e) {
    return [];
  }
}

function pruneBackups() {
  const all = listBackups();
  all.slice(MAX_BACKUPS).forEach((b) => {
    try { fs.unlinkSync(path.join(BACKUP_DIR, b.file)); } catch (e) { /* best effort */ }
  });
}

async function handleDiagnosticsGet(req, res) {
  const key = getApiKey();
  const lic = licenseState();
  const t = usageTotals;
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    supportEmail: SUPPORT_EMAIL,
    app: { version: APP_VERSION, node: process.version, platform: process.platform + ' ' + process.arch },
    config: {
      model: getModel(),
      keySource: getKeySource(),
      keyFingerprint: keyFingerprint(key),
      mockAi: MOCK_AI,
      timeoutMs: ANTHROPIC_TIMEOUT_MS
    },
    license: { licensed: lic.licensed, trialUsed: lic.trialUsed, trialLimit: lic.trialLimit },
    usage: {
      calls: t.calls || 0,
      inputTokens: t.inputTokens || 0,
      outputTokens: t.outputTokens || 0,
      estimatedCost: Object.keys(t.byModel || {}).reduce(
        (sum, id) => sum + (costFor(id, t.byModel[id].inputTokens, t.byModel[id].outputTokens) || 0), 0)
    },
    backups: listBackups().length,
    recentErrors: recentErrors
  }));
}

async function handleLicenseGet(req, res) {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(licenseState()));
}

async function handleLicenseSave(req, res) {
  let raw;
  try {
    raw = await readBody(req, 64 * 1024);
  } catch (e) {
    endWithBodyError(req, res, e);
    return;
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }

  const key = typeof body.key === 'string' ? body.key.trim() : '';

  if (key === '') {
    // Explicit removal, e.g. moving the licence to another machine.
    const next = Object.assign({}, storedSettings);
    delete next.license;
    try { writeSettings(next); } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Could not remove the license: ' + e.message }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(Object.assign({ ok: true }, licenseState())));
    return;
  }

  if (!verifyLicense(key)) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'That license key is not valid. Check it was pasted in full -- keys are one long line with no spaces.' }));
    return;
  }

  try {
    writeSettings(Object.assign({}, storedSettings, { license: key }));
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Could not save the license: ' + e.message }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(Object.assign({ ok: true }, licenseState())));
}

async function handleProjectBackup(req, res) {
  let raw;
  try {
    raw = await readBody(req, MAX_BACKUP_BYTES);
  } catch (e) {
    endWithBodyError(req, res, e, 'Project is too large to back up (max 4MB).');
    return;
  }
  try {
    JSON.parse(raw);
  } catch (e) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Backup body must be valid project JSON.' }));
    return;
  }
  // Filename is server-generated; nothing from the request reaches the path.
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const file = path.join(BACKUP_DIR, 'project-' + stamp + '.json');
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    fs.writeFileSync(file, raw);
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Could not write backup: ' + e.message }));
    return;
  }
  pruneBackups();
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: true, file: path.relative(ROOT, file).split(path.sep).join('/'), bytes: raw.length }));
}

/* The other half of backing up. Without this, restoring means knowing that backups live in a
   gitignored folder and steering a file picker to it -- which makes the backup theatre for
   exactly the user who most needs it.

   Only files matching the generated backup name are readable, and the name is matched against
   the directory listing rather than joined into a path, so nothing user-supplied ever reaches
   the filesystem. */
async function handleProjectBackupRead(req, res) {
  const requested = decodeURIComponent(req.url.split('?')[0].replace('/api/project/backups/', ''));
  const known = listBackups().find((b) => b.file === requested);
  if (!known) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'No such backup.' }));
    return;
  }
  let raw;
  try {
    raw = fs.readFileSync(path.join(BACKUP_DIR, known.file), 'utf8');
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Could not read that backup: ' + e.message }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(raw);
}

async function handleProjectBackupsList(req, res) {
  const all = listBackups();
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    count: all.length,
    kept: MAX_BACKUPS,
    latest: all[0] || null,
    totalBytes: all.reduce((n, b) => n + b.bytes, 0),
    dir: path.relative(ROOT, BACKUP_DIR).split(path.sep).join('/')
  }));
}

async function handleUsageReset(req, res) {
  usageTotals = { since: Date.now() };
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(USAGE_PATH, JSON.stringify(usageTotals, null, 2));
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Could not reset usage: ' + e.message }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: true }));
}

async function handleSettingsTest(req, res) {
  let raw;
  try {
    raw = await readBody(req, 64 * 1024);
  } catch (e) {
    endWithBodyError(req, res, e);
    return;
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }

  // Test a candidate key before it is saved, or the saved one when none is supplied.
  const candidate = typeof body.apiKey === 'string' && body.apiKey.trim() ? body.apiKey.trim() : '';
  const key = candidate || getApiKey();
  const model = (typeof body.model === 'string' && AVAILABLE_MODELS.some((m) => m.id === body.model))
    ? body.model
    : getModel();

  if (!key) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: false, error: 'No API key to test. Enter one first.' }));
    return;
  }

  // Smallest call that still proves the key AND that this key can reach this model.
  const { status, body: respBody } = await anthropicRequest(
    { model, max_tokens: 16, messages: [{ role: 'user', content: 'hi' }] },
    key
  );

  if (status === 200) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, model, message: 'Key works, and it has access to ' + model + '.' }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    ok: false,
    model,
    error: (respBody && respBody.error && respBody.error.message) || 'Could not verify the key.'
  }));
}

async function handleSettingsGet(req, res) {
  const key = getApiKey();
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    hasKey: !!key,
    maskedKey: maskKey(key),
    keySource: getKeySource(),
    model: getModel(),
    defaultModel: DEFAULT_MODEL,
    models: AVAILABLE_MODELS,
    mockAi: MOCK_AI
  }));
}

async function handleSettingsSave(req, res) {
  let raw;
  try {
    raw = await readBody(req, 64 * 1024);
  } catch (e) {
    endWithBodyError(req, res, e);
    return;
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }

  const next = Object.assign({}, storedSettings);

  if (typeof body.apiKey === 'string') {
    const trimmed = body.apiKey.trim();
    if (trimmed === '') {
      // Explicit clear -- fall back to the environment key, if there is one.
      delete next.apiKey;
    } else if (!/^sk-ant-\S+$/.test(trimmed)) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'That does not look like an Anthropic API key -- they start with "sk-ant-".' }));
      return;
    } else {
      next.apiKey = trimmed;
    }
  }

  if (typeof body.model === 'string' && body.model) {
    if (!AVAILABLE_MODELS.some((m) => m.id === body.model)) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unknown model: ' + body.model }));
      return;
    }
    next.model = body.model;
  }

  try {
    writeSettings(next);
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Could not save settings: ' + e.message }));
    return;
  }

  const key = getApiKey();
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    ok: true,
    hasKey: !!key,
    maskedKey: maskKey(key),
    keySource: getKeySource(),
    model: getModel()
  }));
}

// Handlers are async and invoked fire-and-forget, so a rejection has nowhere to go. Funnel every
// one through a single catch that answers 500 rather than letting it kill the process.
function run(handler, req, res) {
  Promise.resolve()
    .then(() => handler(req, res))
    .catch((e) => {
      console.error(`[${req.method} ${req.url}] handler failed:`, (e && e.stack) || e);
      noteError(req.method + ' ' + req.url, (e && e.message) || String(e));
      if (res.headersSent || res.destroyed) return;
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Internal server error: ' + ((e && e.message) || 'unknown') }));
    });
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/api/diagnostics') {
    run(handleDiagnosticsGet, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/update/apply') {
    run(handleUpdateApply, req, res);
    return;
  }
  if (req.method === 'GET' && req.url === '/api/update/check') {
    run(handleUpdateCheck, req, res);
    return;
  }
  if (req.method === 'GET' && req.url === '/api/license') {
    run(handleLicenseGet, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/license') {
    run(handleLicenseSave, req, res);
    return;
  }
  if (req.method === 'GET' && req.url.startsWith('/api/project/backups/')) {
    run(handleProjectBackupRead, req, res);
    return;
  }
  if (req.method === 'GET' && req.url === '/api/project/backups') {
    run(handleProjectBackupsList, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/project/backup') {
    run(handleProjectBackup, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/usage/reset') {
    run(handleUsageReset, req, res);
    return;
  }
  if (req.method === 'GET' && req.url === '/api/usage') {
    run(handleUsageGet, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/settings/test') {
    run(handleSettingsTest, req, res);
    return;
  }
  if (req.method === 'GET' && req.url === '/api/settings') {
    run(handleSettingsGet, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/settings') {
    run(handleSettingsSave, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/chat') {
    run(handleChat, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/images/list') {
    run(handleImagesList, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/images/upload') {
    run(handleImagesUpload, req, res);
    return;
  }
  if (req.method === 'POST' && req.url === '/api/images/delete') {
    run(handleImagesDelete, req, res);
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405);
    res.end('Method not allowed');
    return;
  }
  serveStatic(req, res);
});

// Last-resort net. Anything landing here is still a bug worth fixing, but a single bad request
// should never take the dev server down with it.
process.on('unhandledRejection', (reason) => {
  console.error('Unhandled promise rejection (server kept alive):', (reason && reason.stack) || reason);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception (server kept alive):', (err && err.stack) || err);
});

// Startup failures are not survivable -- if the port is taken there is no listener, and keeping the
// process alive would leave a zombie that looks running but serves nothing. Exit loudly instead.
server.on('error', (e) => {
  if (e && e.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use -- another CodeCraft server is probably still running. Stop it, or set PORT to a free port.`);
  } else {
    console.error('Server error:', (e && e.stack) || e);
  }
  process.exit(1);
});

server.listen(PORT, () => {
  console.log('');
  console.log('  CodeCraft is running.');
  console.log('');
  console.log(`  Open this in your browser:   http://localhost:${PORT}`);
  console.log('');
  console.log('  Leave this window open. It is the app -- closing it stops CodeCraft.');
  console.log('');
  console.log('  Your work is saved in:  ' + DATA_DIR);
  console.log('  That folder is outside the app, so updating never touches it.');
  if (!getApiKey() && !MOCK_AI) {
    console.log('');
    console.log('  No API key yet. Add your Anthropic key in the Account tab before generating.');
  }
});
